import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'motion/react';
import { Shield, Sparkles } from 'lucide-react';
import { PortfolioProvider, usePortfolio } from './context/PortfolioContext';
import { Project } from './types/portfolio';

// Public Portfolio Components
import { Loader } from './components/Loader';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { BrandWall } from './components/BrandWall';
import { About } from './components/About';
import { Services } from './components/Services';
import { Portfolio } from './components/Portfolio';
import { BeforeAfterSlider } from './components/BeforeAfterSlider';
import { Showreel } from './components/Showreel';
import { Skills } from './components/Skills';
import { Process } from './components/Process';
import { WhyMe } from './components/WhyMe';
import { Testimonials } from './components/Testimonials';
import { Contact } from './components/Contact';
import { FinalCTA } from './components/FinalCTA';
import { Footer } from './components/Footer';
import { ProjectModal } from './components/ProjectModal';
import { VideoPlayerModal } from './components/VideoPlayerModal';
import { Toast } from './components/Toast';

// Admin CMS Components
import { AdminDashboard } from './components/admin/AdminDashboard';
import { AdminLoginModal } from './components/admin/AdminLoginModal';

function PortfolioInner() {
  const { data, isAdminOpen, setIsAdminOpen, isAuthenticated } = usePortfolio();

  const [isLoading, setIsLoading] = useState(true);
  const [activeSection, setActiveSection] = useState('home');
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [isShowreelOpen, setIsShowreelOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [preselectedService, setPreselectedService] = useState<string | undefined>(undefined);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  // Keyboard shortcut (Ctrl+Shift+A or Cmd+Shift+A) to open admin
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'A' || e.key === 'a')) {
        e.preventDefault();
        handleOpenAdmin();
      }
    };

    // Check if URL has ?admin=true or #admin
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('admin') === 'true' || window.location.hash === '#admin') {
      handleOpenAdmin();
    }

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isAuthenticated]);

  // Section observer to update active navbar state on scroll
  useEffect(() => {
    if (isAdminOpen) return;

    const sections = [
      'home',
      'about',
      'services',
      'portfolio',
      'grading-comparison',
      'showreel',
      'skills',
      'process',
      'why-me',
      'testimonials',
      'contact'
    ];

    const handleScroll = () => {
      const scrollPosition = window.scrollY + 250;
      for (const sectionId of sections) {
        const el = document.getElementById(sectionId);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [isAdminOpen]);

  const handleNavigate = (sectionId: string) => {
    if (isAdminOpen) {
      setIsAdminOpen(false);
    }
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      const navOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - navOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const handleSelectService = (serviceTitle: string) => {
    setPreselectedService(serviceTitle);
    handleNavigate('contact');
    showToast(`Inquiring about ${serviceTitle}`);
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  const handleOpenAdmin = () => {
    if (isAuthenticated) {
      setIsAdminOpen(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      setIsLoginModalOpen(true);
    }
  };

  const handleLoginSuccess = () => {
    setIsLoginModalOpen(false);
    setIsAdminOpen(true);
    showToast('Welcome to Tawhid Studio CMS Dashboard!');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // If in Admin Dashboard mode and authenticated
  if (isAdminOpen && isAuthenticated) {
    return (
      <>
        <AdminDashboard onShowToast={showToast} />
        <Toast message={toastMessage} onClose={() => setToastMessage(null)} />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-[#07080b] text-[#edf0f5] flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      
      {/* Cinematic Reveal Loader */}
      <AnimatePresence>
        {isLoading && <Loader onComplete={() => setIsLoading(false)} />}
      </AnimatePresence>

      {/* Fixed Elevated Navbar */}
      <Navbar
        activeSection={activeSection}
        onNavigate={handleNavigate}
        onOpenAdmin={handleOpenAdmin}
      />

      {/* Main Content Area */}
      <main className="flex-grow">
        {/* 1. Hero Section */}
        <Hero
          onOpenShowreel={() => setIsShowreelOpen(true)}
          onNavigate={handleNavigate}
        />

        {/* 2. Client Trust Strip */}
        <BrandWall />

        {/* 3. About Tawhid & Animated Metrics */}
        <About onNavigate={handleNavigate} />

        {/* 4. Core Services & Deliverables */}
        <Services onSelectService={handleSelectService} />

        {/* 5. Selected Work Showcase & Case Studies */}
        <Portfolio
          onSelectProject={(project) => setSelectedProject(project)}
          onOpenShowreel={() => setIsShowreelOpen(true)}
        />

        {/* 6. Interactive Raw vs. Master Grade Comparison */}
        <BeforeAfterSlider />

        {/* 7. Dedicated Showreel Showcase */}
        <Showreel onOpenShowreel={() => setIsShowreelOpen(true)} />

        {/* 8. Skills & Production Software */}
        <Skills />

        {/* 9. 4-Step Production Workflow */}
        <Process />

        {/* 10. Why Work With Me */}
        <WhyMe />

        {/* 11. Client Testimonials & Reviews */}
        <Testimonials />

        {/* 12. Direct Inquiry Suite & Brief Form */}
        <Contact
          onShowToast={showToast}
          preselectedService={preselectedService}
        />

        {/* 13. High-Impact Closing CTA */}
        <FinalCTA onNavigate={handleNavigate} />
      </main>

      {/* 14. Comprehensive Editorial Footer */}
      <Footer
        onNavigate={handleNavigate}
        onOpenAdmin={handleOpenAdmin}
      />

      {/* Floating Admin Trigger Button (Discreet in bottom-right) */}
      <div className="fixed bottom-5 right-5 z-30">
        <button
          onClick={handleOpenAdmin}
          className="group flex items-center gap-2 px-3.5 py-2 rounded-full bg-[#0a0d14]/90 hover:bg-cyan-500/20 text-neutral-300 hover:text-cyan-300 border border-white/10 hover:border-cyan-500/40 backdrop-blur-md shadow-2xl transition-all duration-300 cursor-pointer text-xs font-mono"
          title="Open Admin Dashboard (Ctrl + Shift + A)"
        >
          <Shield className="w-3.5 h-3.5 text-cyan-400 group-hover:scale-110 transition-transform" />
          <span className="hidden sm:inline">Admin CMS</span>
        </button>
      </div>

      {/* Case Study Modal */}
      <ProjectModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
        onSelectProject={(project) => setSelectedProject(project)}
        allProjects={data.projects}
        onOpenShowreel={() => {
          setSelectedProject(null);
          setIsShowreelOpen(true);
        }}
      />

      {/* 4K Cinematic Showreel Interactive Player */}
      <VideoPlayerModal
        isOpen={isShowreelOpen}
        onClose={() => setIsShowreelOpen(false)}
      />

      {/* Admin Security PIN Login Modal */}
      <AdminLoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        onSuccess={handleLoginSuccess}
      />

      {/* Notification Toast */}
      <Toast
        message={toastMessage}
        onClose={() => setToastMessage(null)}
      />

    </div>
  );
}

export function App() {
  return (
    <PortfolioProvider>
      <PortfolioInner />
    </PortfolioProvider>
  );
}

export default App;
