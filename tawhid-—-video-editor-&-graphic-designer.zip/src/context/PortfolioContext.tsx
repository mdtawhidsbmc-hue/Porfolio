import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  PortfolioConfig, 
  Project, 
  Service, 
  Testimonial, 
  SkillCategory, 
  StatItem, 
  ShowreelConfig, 
  BeforeAfterSample, 
  BrandClient, 
  SocialLink,
  ProcessStep,
  WhyMePillar,
  InquiryMessage 
} from '../types/portfolio';
import { portfolioData as initialPortfolioData } from '../data/portfolioData';

interface PortfolioContextType {
  data: PortfolioConfig;
  updatePersonal: (fields: Partial<PortfolioConfig['personal']>) => void;
  updateStats: (stats: StatItem[]) => void;
  addProject: (project: Project) => void;
  editProject: (id: string, updated: Partial<Project>) => void;
  deleteProject: (id: string) => void;
  addService: (service: Service) => void;
  editService: (id: string, updated: Partial<Service>) => void;
  deleteService: (id: string) => void;
  addTestimonial: (testimonial: Testimonial) => void;
  editTestimonial: (id: string, updated: Partial<Testimonial>) => void;
  deleteTestimonial: (id: string) => void;
  updateSkills: (skills: SkillCategory[]) => void;
  updateShowreel: (showreel: Partial<ShowreelConfig>) => void;
  updateBeforeAfterSamples: (samples: BeforeAfterSample[]) => void;
  updateBrands: (brands: BrandClient[]) => void;
  updateSocials: (socials: SocialLink[]) => void;
  updateProcess: (process: ProcessStep[]) => void;
  updateWhyMe: (whyMe: WhyMePillar[]) => void;
  resetToDefaults: () => void;
  exportJSON: () => string;
  importJSON: (jsonStr: string) => boolean;
  
  // Inquiries
  inquiries: InquiryMessage[];
  addInquiry: (inquiry: {
    name: string;
    email: string;
    projectType: string;
    budget: string;
    timeline: string;
    message: string;
  }) => void;
  deleteInquiry: (id: string) => void;
  markInquiryRead: (id: string, read?: boolean) => void;
  updateInquiryStatus: (id: string, status: 'new' | 'contacted' | 'archived') => void;
  
  // Admin UI State & Auth
  isAdminOpen: boolean;
  setIsAdminOpen: (open: boolean) => void;
  isAuthenticated: boolean;
  loginAdmin: (pin: string) => boolean;
  logoutAdmin: () => void;
  adminPin: string;
  updateAdminPin: (newPin: string) => void;
}

const STORAGE_KEY = 'tawhid_portfolio_data_v2';
const INQUIRIES_KEY = 'tawhid_portfolio_inquiries_v2';
const ADMIN_PIN_KEY = 'tawhid_portfolio_admin_pin';

const defaultInquiries: InquiryMessage[] = [
  {
    id: 'inq-1',
    name: 'Sarah Jenkins',
    email: 'sarah@creatorhub.co',
    projectType: 'Video Editing',
    budget: '$1,500 - $3,000',
    timeline: 'Within 2 Weeks',
    message: 'Hey Tawhid! Loved your 2026 showreel. We are launching a 10-part YouTube documentary series and need cinematic pacing with sound design.',
    date: 'Yesterday at 3:45 PM',
    read: false,
    status: 'new'
  },
  {
    id: 'inq-2',
    name: 'Marcus Vance',
    email: 'marcus@aurorastudios.design',
    projectType: 'Graphic Design',
    budget: '$500 - $1,500',
    timeline: 'Within 1 Month',
    message: 'Looking for a consistent designer to create YouTube thumbnails and social media carousels for our marketing agency clients.',
    date: '2 days ago',
    read: true,
    status: 'contacted'
  }
];

const PortfolioContext = createContext<PortfolioContextType | undefined>(undefined);

export const PortfolioProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 1. Data state
  const [data, setData] = useState<PortfolioConfig>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        // Ensure all required fields exist
        return {
          ...initialPortfolioData,
          ...parsed,
          personal: { ...initialPortfolioData.personal, ...parsed.personal },
          stats: parsed.stats || initialPortfolioData.stats,
          services: parsed.services || initialPortfolioData.services,
          projects: parsed.projects || initialPortfolioData.projects,
          skills: parsed.skills || initialPortfolioData.skills,
          testimonials: parsed.testimonials || initialPortfolioData.testimonials,
          showreel: { ...initialPortfolioData.showreel, ...parsed.showreel },
          beforeAfterSamples: parsed.beforeAfterSamples || initialPortfolioData.beforeAfterSamples,
          process: parsed.process || initialPortfolioData.process,
          whyMe: parsed.whyMe || initialPortfolioData.whyMe,
          brands: parsed.brands || initialPortfolioData.brands,
          socials: parsed.socials || initialPortfolioData.socials,
        };
      }
    } catch (e) {
      console.error('Failed to load portfolio data from localStorage:', e);
    }
    return initialPortfolioData;
  });

  // 2. Inquiries state
  const [inquiries, setInquiries] = useState<InquiryMessage[]>(() => {
    try {
      const saved = localStorage.getItem(INQUIRIES_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load inquiries from localStorage:', e);
    }
    return defaultInquiries;
  });

  // 3. Admin credentials & auth
  const [adminPin, setAdminPin] = useState<string>(() => {
    return localStorage.getItem(ADMIN_PIN_KEY) || '1234';
  });
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem('tawhid_admin_auth') === 'true';
  });
  const [isAdminOpen, setIsAdminOpen] = useState<boolean>(false);

  // Sync data to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (e) {
      console.error('Failed to save portfolio data to localStorage:', e);
    }
  }, [data]);

  // Sync inquiries to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(INQUIRIES_KEY, JSON.stringify(inquiries));
    } catch (e) {
      console.error('Failed to save inquiries to localStorage:', e);
    }
  }, [inquiries]);

  // Methods for Personal Info
  const updatePersonal = (fields: Partial<PortfolioConfig['personal']>) => {
    setData(prev => ({
      ...prev,
      personal: {
        ...prev.personal,
        ...fields
      }
    }));
  };

  // Stats
  const updateStats = (newStats: StatItem[]) => {
    setData(prev => ({ ...prev, stats: newStats }));
  };

  // Projects
  const addProject = (project: Project) => {
    setData(prev => ({
      ...prev,
      projects: [project, ...prev.projects]
    }));
  };

  const editProject = (id: string, updated: Partial<Project>) => {
    setData(prev => ({
      ...prev,
      projects: prev.projects.map(p => p.id === id ? { ...p, ...updated } : p)
    }));
  };

  const deleteProject = (id: string) => {
    setData(prev => ({
      ...prev,
      projects: prev.projects.filter(p => p.id !== id)
    }));
  };

  // Services
  const addService = (service: Service) => {
    setData(prev => ({
      ...prev,
      services: [...prev.services, service]
    }));
  };

  const editService = (id: string, updated: Partial<Service>) => {
    setData(prev => ({
      ...prev,
      services: prev.services.map(s => s.id === id ? { ...s, ...updated } : s)
    }));
  };

  const deleteService = (id: string) => {
    setData(prev => ({
      ...prev,
      services: prev.services.filter(s => s.id !== id)
    }));
  };

  // Testimonials
  const addTestimonial = (testimonial: Testimonial) => {
    setData(prev => ({
      ...prev,
      testimonials: [testimonial, ...prev.testimonials]
    }));
  };

  const editTestimonial = (id: string, updated: Partial<Testimonial>) => {
    setData(prev => ({
      ...prev,
      testimonials: prev.testimonials.map(t => t.id === id ? { ...t, ...updated } : t)
    }));
  };

  const deleteTestimonial = (id: string) => {
    setData(prev => ({
      ...prev,
      testimonials: prev.testimonials.filter(t => t.id !== id)
    }));
  };

  // Skills
  const updateSkills = (skills: SkillCategory[]) => {
    setData(prev => ({ ...prev, skills }));
  };

  // Showreel
  const updateShowreel = (showreel: Partial<ShowreelConfig>) => {
    setData(prev => ({
      ...prev,
      showreel: { ...prev.showreel, ...showreel }
    }));
  };

  // Before / After
  const updateBeforeAfterSamples = (beforeAfterSamples: BeforeAfterSample[]) => {
    setData(prev => ({ ...prev, beforeAfterSamples }));
  };

  // Brands
  const updateBrands = (brands: BrandClient[]) => {
    setData(prev => ({ ...prev, brands }));
  };

  // Socials
  const updateSocials = (socials: SocialLink[]) => {
    setData(prev => ({ ...prev, socials }));
  };

  // Process Steps
  const updateProcess = (process: ProcessStep[]) => {
    setData(prev => ({ ...prev, process }));
  };

  // Why Me Pillars
  const updateWhyMe = (whyMe: WhyMePillar[]) => {
    setData(prev => ({ ...prev, whyMe }));
  };

  // Reset to code defaults
  const resetToDefaults = () => {
    localStorage.removeItem(STORAGE_KEY);
    setData(initialPortfolioData);
  };

  // Export JSON
  const exportJSON = () => {
    return JSON.stringify(data, null, 2);
  };

  // Import JSON
  const importJSON = (jsonStr: string): boolean => {
    try {
      const parsed = JSON.parse(jsonStr);
      if (parsed && parsed.personal && parsed.projects) {
        setData({
          ...initialPortfolioData,
          ...parsed,
          personal: { ...initialPortfolioData.personal, ...parsed.personal }
        });
        return true;
      }
      return false;
    } catch (e) {
      console.error('Invalid JSON imported:', e);
      return false;
    }
  };

  // Inquiries methods
  const addInquiry = (inquiry: {
    name: string;
    email: string;
    projectType: string;
    budget: string;
    timeline: string;
    message: string;
  }) => {
    const newInq: InquiryMessage = {
      id: `inq-${Date.now()}`,
      ...inquiry,
      date: 'Just now',
      read: false,
      status: 'new'
    };
    setInquiries(prev => [newInq, ...prev]);
  };

  const deleteInquiry = (id: string) => {
    setInquiries(prev => prev.filter(inq => inq.id !== id));
  };

  const markInquiryRead = (id: string, read: boolean = true) => {
    setInquiries(prev => prev.map(inq => inq.id === id ? { ...inq, read } : inq));
  };

  const updateInquiryStatus = (id: string, status: 'new' | 'contacted' | 'archived') => {
    setInquiries(prev => prev.map(inq => inq.id === id ? { ...inq, status } : inq));
  };

  // Auth methods
  const loginAdmin = (pin: string): boolean => {
    if (pin.trim() === adminPin) {
      setIsAuthenticated(true);
      sessionStorage.setItem('tawhid_admin_auth', 'true');
      return true;
    }
    return false;
  };

  const logoutAdmin = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('tawhid_admin_auth');
  };

  const updateAdminPin = (newPin: string) => {
    setAdminPin(newPin);
    localStorage.setItem(ADMIN_PIN_KEY, newPin);
  };

  return (
    <PortfolioContext.Provider
      value={{
        data,
        updatePersonal,
        updateStats,
        addProject,
        editProject,
        deleteProject,
        addService,
        editService,
        deleteService,
        addTestimonial,
        editTestimonial,
        deleteTestimonial,
        updateSkills,
        updateShowreel,
        updateBeforeAfterSamples,
        updateBrands,
        updateSocials,
        updateProcess,
        updateWhyMe,
        resetToDefaults,
        exportJSON,
        importJSON,
        inquiries,
        addInquiry,
        deleteInquiry,
        markInquiryRead,
        updateInquiryStatus,
        isAdminOpen,
        setIsAdminOpen,
        isAuthenticated,
        loginAdmin,
        logoutAdmin,
        adminPin,
        updateAdminPin
      }}
    >
      {children}
    </PortfolioContext.Provider>
  );
};

export const usePortfolio = () => {
  const context = useContext(PortfolioContext);
  if (!context) {
    throw new Error('usePortfolio must be used within a PortfolioProvider');
  }
  return context;
};
