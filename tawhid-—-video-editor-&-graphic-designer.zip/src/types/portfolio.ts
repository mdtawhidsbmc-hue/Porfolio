export type ProjectCategory = 
  | 'All' 
  | 'Video Editing' 
  | 'Graphic Design' 
  | 'Social Media' 
  | 'Branding' 
  | 'Motion Graphics' 
  | 'Thumbnail Design';

export interface ProjectStat {
  label: string;
  value: string;
}

export interface Project {
  id: string;
  title: string;
  category: ProjectCategory;
  shortDescription: string;
  thumbnail: string;
  videoUrl?: string;
  featured?: boolean;
  aspectRatio?: 'video' | 'square' | 'portrait';
  fullDescription: string;
  toolsUsed: string[];
  challenge: string;
  solution: string;
  finalResult: string;
  client?: string;
  deliverables?: string[];
  stats?: ProjectStat[];
}

export interface Service {
  id: string;
  number: string;
  title: string;
  description: string;
  iconName: string;
  deliverables: string[];
}

export interface SkillItem {
  name: string;
  level: 'Advanced' | 'Professional' | 'Intermediate';
  percentage: number;
  icon?: string;
}

export interface SkillCategory {
  category: string;
  description: string;
  skills: SkillItem[];
}

export interface ProcessStep {
  step: string;
  title: string;
  description: string;
  deliverables: string[];
}

export interface Testimonial {
  id: string;
  quote: string;
  clientName: string;
  role: string;
  companyOrChannel: string;
  avatar?: string;
  projectType: string;
  rating?: number;
}

export interface BrandClient {
  id: string;
  name: string;
  tagline: string;
}

export interface WhyMePillar {
  title: string;
  description: string;
  iconName: string;
}

export interface SocialLink {
  platform: string;
  url: string;
  iconName: string;
  username: string;
}

export interface StatItem {
  value: number;
  suffix: string;
  label: string;
  sublabel: string;
}

export interface BeforeAfterSample {
  id: string;
  title: string;
  category: string;
  description: string;
  beforeImage: string;
  afterImage: string;
  beforeLabel: string;
  afterLabel: string;
  specs: string;
}

export interface ShowreelConfig {
  title: string;
  subheading: string;
  description: string;
  previewImage: string;
  videoDuration: string;
  embedOrVideoUrl: string;
  chapters: { title: string; time: string }[];
}

export interface PortfolioConfig {
  personal: {
    name: string;
    role: string;
    tagline: string;
    heroHeading: string;
    heroSubtext: string;
    aboutHeading: string;
    aboutBio1: string;
    aboutBio2: string;
    location: string;
    status: string;
    email: string;
    phone: string;
    whatsapp: string;
    experienceYears: string;
    heroBadge?: string;
    ctaHeading?: string;
    ctaSubtext?: string;
    aboutHighlights?: { title: string; description: string }[];
  };
  stats: StatItem[];
  services: Service[];
  projects: Project[];
  skills: SkillCategory[];
  process: ProcessStep[];
  whyMe: WhyMePillar[];
  testimonials: Testimonial[];
  brands: BrandClient[];
  socials: SocialLink[];
  showreel: ShowreelConfig;
  beforeAfterSamples: BeforeAfterSample[];
}

export interface InquiryMessage {
  id: string;
  name: string;
  email: string;
  projectType: string;
  budget: string;
  timeline: string;
  message: string;
  date: string;
  read: boolean;
  status: 'new' | 'contacted' | 'archived';
}

