import { PortfolioConfig } from '../types/portfolio';

export const portfolioData: PortfolioConfig = {
  personal: {
    name: "Tawhid",
    role: "Video Editor & Graphic Designer",
    tagline: "Turning ideas into powerful visuals.",
    heroHeading: "I Turn Ideas Into\nPowerful Visual Stories.",
    heroSubtext: "I'm Tawhid, a Video Editor & Graphic Designer creating cinematic videos, eye-catching graphics, and visual experiences that help brands and creators stand out.",
    aboutHeading: "Behind The Visuals",
    aboutBio1: "Hi, I'm Tawhid — a passionate Video Editor and Graphic Designer focused on turning ideas into engaging visual content.",
    aboutBio2: "I combine creativity, storytelling, composition, motion, typography, and design to create visuals that don't just look good — they communicate.",
    location: "Dhaka, Bangladesh • Worldwide Remote",
    status: "Available for New Projects",
    email: "contact.tawhid.creative@gmail.com",
    phone: "+880 1700-000000",
    whatsapp: "+8801700000000",
    experienceYears: "2+",
  },

  stats: [
    {
      value: 50,
      suffix: "+",
      label: "Projects Completed",
      sublabel: "Across video, graphics & motion"
    },
    {
      value: 30,
      suffix: "+",
      label: "Happy Clients",
      sublabel: "Creators, brands & agencies"
    },
    {
      value: 2,
      suffix: "+",
      label: "Years Experience",
      sublabel: "Delivering visual excellence"
    },
    {
      value: 10,
      suffix: "+",
      label: "Creative Skills",
      sublabel: "End-to-end production tools"
    }
  ],

  services: [
    {
      id: "video-editing",
      number: "01",
      title: "Video Editing",
      description: "Cinematic edits, social media videos, YouTube content, promotional videos, reels, short-form content, and visual storytelling.",
      iconName: "Film",
      deliverables: ["4K Cinematic Cut", "Sound Design & Mix", "Color Grading", "Multi-Camera Sync", "Pacing & Narrative Flow"]
    },
    {
      id: "graphic-design",
      number: "02",
      title: "Graphic Design",
      description: "Modern social media graphics, posters, banners, thumbnails, promotional designs, and creative visual content.",
      iconName: "Palette",
      deliverables: ["Editorial Layouts", "Event & Campaign Posters", "Digital Advertising Kits", "Vector Illustrations", "Print & Web Assets"]
    },
    {
      id: "social-media",
      number: "03",
      title: "Social Media Content",
      description: "Scroll-stopping content designed specifically for Instagram, Facebook, YouTube, Pinterest, and other social platforms.",
      iconName: "Share2",
      deliverables: ["Viral Short-form Reels", "Carousel Post Sets", "Story Templates", "Platform-Optimized Formats", "Engagement Hooks"]
    },
    {
      id: "thumbnail-design",
      number: "04",
      title: "Thumbnail Design",
      description: "High-click, attention-grabbing thumbnails designed to improve visual impact, click-through rate, and viewer engagement.",
      iconName: "Sparkles",
      deliverables: ["High CTR Composition", "Color Accent & Lighting Pop", "3D Typography", "Facial Expression Enhancement", "A/B Testing Variants"]
    },
    {
      id: "brand-visuals",
      number: "05",
      title: "Brand Visuals",
      description: "Consistent visual systems, promotional materials, brand graphics, and creative assets that reinforce identity.",
      iconName: "Layers",
      deliverables: ["Brand Identity Guidelines", "Social Media Kits", "Typography & Color Palettes", "Marketing Collateral", "Deck & Presentation Design"]
    },
    {
      id: "motion-graphics",
      number: "06",
      title: "Motion Graphics",
      description: "Dynamic typography, transitions, logo animation, promotional motion graphics, and visual effects that breathe life into static concepts.",
      iconName: "Zap",
      deliverables: ["Kinetic Typography", "Logo Stings & Intros", "HUD & UI Overlays", "Smooth Lottie Animations", "VFX & Compositing"]
    }
  ],

  projects: [
    {
      id: "cinematic-brand-film",
      title: "Cinematic Commercial & Brand Film",
      category: "Video Editing",
      shortDescription: "A high-octane commercial brand film utilizing custom sound design, cinematic pacing, and deep teal-orange color grading.",
      thumbnail: "https://images.unsplash.com/photo-1536240478700-b869070f9279?q=80&w=1200&auto=format&fit=crop",
      aspectRatio: "video",
      featured: true,
      fullDescription: "Produced and edited a visually compelling promotional film capturing brand energy through seamless cuts, speed ramps, and atmospheric audio layering.",
      toolsUsed: ["Premiere Pro", "DaVinci Resolve", "After Effects", "Audition"],
      challenge: "The raw footage lacked consistent lighting across interior/exterior shots and had minimal natural sound cues, requiring extensive post-processing.",
      solution: "Implemented precision color grading with DaVinci Resolve to establish a coherent cinematic look, layered over 25 custom Foley audio tracks, and used rhythmic beat matching to drive emotional momentum.",
      finalResult: "Delivered a 90-second hero film that boosted campaign conversion by 42% across digital platforms.",
      client: "Urban Pulse Lifestyle",
      deliverables: ["16:9 Hero Commercial", "9:16 Social Cutdowns", "Color LUT Package", "Custom SFX Mix"],
      stats: [
        { label: "Pacing", value: "High Energy" },
        { label: "Format", value: "4K DCI" },
        { label: "Turnaround", value: "4 Days" }
      ]
    },
    {
      id: "social-media-campaign",
      title: "Social Media Campaign Visuals",
      category: "Graphic Design",
      shortDescription: "A multi-platform visual identity and graphic campaign crafted with bold typography and high-contrast composition.",
      thumbnail: "https://images.unsplash.com/photo-1561070791-2526d30994b5?q=80&w=1200&auto=format&fit=crop",
      aspectRatio: "square",
      featured: true,
      fullDescription: "Created a cohesive 12-piece digital graphic suite for an international product launch across Instagram, LinkedIn, and billboard mockups.",
      toolsUsed: ["Photoshop", "Illustrator", "Figma"],
      challenge: "The client needed a distinct aesthetic that stood out in crowded social media feeds without looking overly busy.",
      solution: "Employed a stark editorial layout with custom distorted kinetic typography, metallic gradient overlays, and clear call-to-action hierarchies.",
      finalResult: "The campaign generated over 150K impressions in the first week with a 3.8x higher engagement rate than previous quarters.",
      client: "NeoDesign Studios",
      deliverables: ["12x Social Posts", "6x Carousel Decks", "Animated GIF Teasers", "Story Highlights Kit"],
      stats: [
        { label: "Reach", value: "150K+" },
        { label: "Engagement", value: "+380%" },
        { label: "Deliverables", value: "18 Assets" }
      ]
    },
    {
      id: "youtube-thumbnail-collection",
      title: "High CTR YouTube Thumbnails",
      category: "Thumbnail Design",
      shortDescription: "Eye-catching, high-contrast YouTube thumbnail collection engineered to maximize click-through rate and curiosity.",
      thumbnail: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=1200&auto=format&fit=crop",
      aspectRatio: "video",
      featured: true,
      fullDescription: "Designed custom thumbnail packages for high-growth YouTube creators featuring custom rim lighting, expression cutout enhancements, and readable 3-word titles.",
      toolsUsed: ["Photoshop", "Lightroom", "Blender"],
      challenge: "Viewers on mobile scan thumbnails in less than 0.3 seconds; visual hierarchy had to communicate the story instantly.",
      solution: "Separated foreground subjects with custom hand-painted glow edges, balanced background blur with depth of field, and utilized warm-cool color contrast.",
      finalResult: "Average CTR jumped from 4.2% to 11.6% across 8 consecutive video releases.",
      client: "Tech & Creator Channel",
      deliverables: ["10x Master Thumbnails", "A/B Testing Variants", "Reusable Layered PSD Templates"],
      stats: [
        { label: "Avg CTR", value: "11.6%" },
        { label: "Views", value: "1.2M+" },
        { label: "Format", value: "1080p Ultra-Sharp" }
      ]
    },
    {
      id: "product-promo-video",
      title: "Next-Gen Product Promo Showcase",
      category: "Video Editing",
      shortDescription: "Sleek and polished product showcase video with seamless 3D object tracking, match cuts, and kinetic typography.",
      thumbnail: "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?q=80&w=1200&auto=format&fit=crop",
      aspectRatio: "video",
      featured: true,
      fullDescription: "An immersive commercial video showcasing hardware features through macro camera moves, dynamic screen replacements, and synchronized electronic soundscapes.",
      toolsUsed: ["Premiere Pro", "After Effects", "Mocha Pro", "DaVinci Resolve"],
      challenge: "Highlighting microscopic product details smoothly while keeping the runtime under 45 seconds.",
      solution: "Created dynamic zoom-through transitions between product components and matched bass drops to mechanical feature reveals.",
      finalResult: "Selected as the flagship showcase video on the client's homepage and landing pages.",
      client: "Aura Audio Gear",
      deliverables: ["45s Master Cut", "30s TV Spot", "15s Vertical Shorts", "Clean Master Video"],
      stats: [
        { label: "Resolution", value: "4K UHD" },
        { label: "Sound", value: "Spatial Stereo" },
        { label: "Retention", value: "88%" }
      ]
    },
    {
      id: "brand-identity-visuals",
      title: "Brand Identity & Visual System",
      category: "Branding",
      shortDescription: "Complete visual identity system including logo design, typography guidelines, and digital brand collateral.",
      thumbnail: "https://images.unsplash.com/photo-1600132806370-bf17e65e942f?q=80&w=1200&auto=format&fit=crop",
      aspectRatio: "square",
      featured: false,
      fullDescription: "Developed a minimalist, contemporary brand identity for an emerging creative production studio, emphasizing clean geometry and dark-mode elegance.",
      toolsUsed: ["Illustrator", "Photoshop", "InDesign", "Figma"],
      challenge: "Building an adaptable system that looks equally premium on printed stationery, mobile apps, and video watermark bugs.",
      solution: "Designed a clean typographic logo with an iconic geometric monogram, accompanied by a flexible 8-column layout grid.",
      finalResult: "Full brand deck delivered with comprehensive digital asset packages ready for deployment.",
      client: "Vortex Creative Studio",
      deliverables: ["Primary & Secondary Logo", "Brand Style Guide (32 Pages)", "Iconography Set", "Social Media Kit"],
      stats: [
        { label: "Pages", value: "32-pg Guide" },
        { label: "Formats", value: "Vector & Web" },
        { label: "Assets", value: "40+ Files" }
      ]
    },
    {
      id: "motion-graphics-reel",
      title: "Dynamic Motion Graphics & HUD VFX",
      category: "Motion Graphics",
      shortDescription: "High-impact kinetic typography, 2D/3D shape morphs, seamless camera moves, and futuristic HUD elements.",
      thumbnail: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=1200&auto=format&fit=crop",
      aspectRatio: "video",
      featured: false,
      fullDescription: "A fast-paced showcase of motion design techniques, featuring kinetic typography, 3D element compositing, and glitch transitions.",
      toolsUsed: ["After Effects", "Cinema 4D", "Illustrator", "Trapcode Suite"],
      challenge: "Creating complex motion pathways while preserving clarity of information.",
      solution: "Utilized easing curves and optical weight balancing to ensure text remains legible even during swift kinetic transitions.",
      finalResult: "Used by the client to headline their annual tech conference keynote presentation.",
      client: "CyberSummit Tech",
      deliverables: ["Opener Sequence", "Speaker Intro Templates", "Lower Thirds Pack", "Looping Backgrounds"],
      stats: [
        { label: "Framerate", value: "60 FPS" },
        { label: "Transitions", value: "Seamless" },
        { label: "Style", value: "Cyber Dark" }
      ]
    },
    {
      id: "social-media-reels-pack",
      title: "Viral Short-Form Content Suite",
      category: "Social Media",
      shortDescription: "A bundle of 10 retention-optimized vertical videos featuring punchy sound effects, animated subtitles, and rapid pacing.",
      thumbnail: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=1200&auto=format&fit=crop",
      aspectRatio: "portrait",
      featured: false,
      fullDescription: "Designed for modern social algorithms with 0-3 second hook optimization, color pop filters, and animated key elements.",
      toolsUsed: ["Premiere Pro", "CapCut", "After Effects", "Photoshop"],
      challenge: "Capturing attention in the first 2 seconds on TikTok and Instagram Reels.",
      solution: "Created dynamic zoom-ins, visual curiosity gaps, sound drop markers, and bold emoji typography.",
      finalResult: "Total combined reel views surpassed 750K within 30 days.",
      client: "Creator Network",
      deliverables: ["10x Vertical Reels (9:16)", "Caption SRT Files", "Thumbnail Covers", "Audio Stem Mixes"],
      stats: [
        { label: "Views", value: "750K+" },
        { label: "Completion", value: "64%" },
        { label: "Shares", value: "14.5K" }
      ]
    }
  ],

  beforeAfterSamples: [
    {
      id: "sample-color-grading",
      title: "Cinematic DaVinci Color Grading",
      category: "Color Correction & LUT Grading",
      description: "Transforming flat, low-contrast S-Log3 / D-Log RAW footage into rich cinematic depth with balanced skin tones and moody teal & amber highlights.",
      beforeImage: "https://images.unsplash.com/photo-1536240478700-b869070f9279?q=80&w=1200&auto=format&fit=crop&sat=-100&con=-20",
      afterImage: "https://images.unsplash.com/photo-1536240478700-b869070f9279?q=80&w=1200&auto=format&fit=crop",
      beforeLabel: "Flat RAW Profile",
      afterLabel: "Final Graded Master",
      specs: "DaVinci Resolve • 12-Node Pipeline • Rec.709 Master"
    },
    {
      id: "sample-thumbnail-retouch",
      title: "High-CTR Visual Retouch & Pop",
      category: "Thumbnail & Graphic Design",
      description: "Elevating raw photography with subject cutout separation, edge lighting glow, localized contrast boosting, and high-impact atmospheric lighting.",
      beforeImage: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=1200&auto=format&fit=crop&sat=-60&bri=-20",
      afterImage: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=1200&auto=format&fit=crop",
      beforeLabel: "Unprocessed Raw",
      afterLabel: "High-Impact Graphic",
      specs: "Photoshop • Custom Lighting • 3-Layer Rim Glow"
    }
  ],

  skills: [
    {
      category: "Video Editing",
      description: "Industry-standard NLEs and post-production software for high-end cinematic workflow.",
      skills: [
        { name: "Premiere Pro", level: "Advanced", percentage: 95 },
        { name: "After Effects", level: "Advanced", percentage: 90 },
        { name: "DaVinci Resolve", level: "Professional", percentage: 85 },
        { name: "CapCut", level: "Advanced", percentage: 95 }
      ]
    },
    {
      category: "Graphic Design",
      description: "Visual composition, typography, image manipulation, and UI graphics.",
      skills: [
        { name: "Photoshop", level: "Advanced", percentage: 95 },
        { name: "Illustrator", level: "Professional", percentage: 88 },
        { name: "Canva", level: "Advanced", percentage: 92 },
        { name: "Figma", level: "Professional", percentage: 85 }
      ]
    },
    {
      category: "Creative Skills",
      description: "Core creative competencies that elevate visual quality and storytelling.",
      skills: [
        { name: "Color Grading", level: "Advanced", percentage: 92 },
        { name: "Motion Graphics", level: "Professional", percentage: 88 },
        { name: "Typography", level: "Advanced", percentage: 94 },
        { name: "Visual Storytelling", level: "Advanced", percentage: 96 },
        { name: "Thumbnail Design", level: "Advanced", percentage: 98 },
        { name: "Social Media Design", level: "Advanced", percentage: 95 }
      ]
    }
  ],

  process: [
    {
      step: "01",
      title: "Discover",
      description: "Understand the brand, audience, goal, and creative direction. We discuss references, tone of voice, visual hooks, and exact specifications.",
      deliverables: ["Creative Brief", "Style Alignment", "Target Audience Assessment"]
    },
    {
      step: "02",
      title: "Plan",
      description: "Develop concepts, references, storyboard, moodboard, and visual direction. Establish pacing, music selection, and color palettes.",
      deliverables: ["Moodboards", "Rough Storyboard", "Asset Checklist & Audio Tracks"]
    },
    {
      step: "03",
      title: "Create",
      description: "Edit, design, animate, color grade, and refine the project. Assemble the narrative structure with precision sound design and visual polish.",
      deliverables: ["First Cut / Initial Design Mockups", "Motion Elements & SFX", "Color Pass"]
    },
    {
      step: "04",
      title: "Deliver",
      description: "Final quality check, revisions, platform optimization, and delivery in pristine 4K/UHD and web-ready formats.",
      deliverables: ["Final High-Res Exports", "Platform-Specific Cutdowns", "Source Assets / Archive"]
    }
  ],

  whyMe: [
    {
      title: "Creative Thinking",
      description: "I don't just assemble footage or place text; I focus on ideas, emotional resonance, storytelling, and maximum visual impact.",
      iconName: "Lightbulb"
    },
    {
      title: "Attention to Detail",
      description: "Every single frame, micro-transition, typography choice, optical alignment, and audio frequency is deliberately crafted.",
      iconName: "Target"
    },
    {
      title: "Modern Visual Style",
      description: "I stay ahead of design trends to create clean, contemporary, aesthetic, and platform-ready content that hooks today's audiences.",
      iconName: "TrendingUp"
    },
    {
      title: "Client-Focused",
      description: "I prioritize prompt communication, strict deadline adherence, constructive revision cycles, and aligning with your ultimate business goals.",
      iconName: "HeartHandshake"
    }
  ],

  testimonials: [
    {
      id: "test-01",
      quote: "Tawhid transformed our raw footage into a polished cinematic video. The final result was far better than we expected, and our audience reaction was phenomenal.",
      clientName: "Alex Rivera",
      role: "Creative Director",
      companyOrChannel: "Aura Creative Media",
      projectType: "Commercial Video Editing",
      rating: 5
    },
    {
      id: "test-02",
      quote: "The thumbnail designs Tawhid created boosted our channel's CTR from 4% to nearly 12%. His understanding of color pop, composition, and visual hooks is world-class.",
      clientName: "David Chen",
      role: "Content Creator (500K+ Subs)",
      companyOrChannel: "TechFrontier Media",
      projectType: "Thumbnail Design & Social Assets",
      rating: 5
    },
    {
      id: "test-03",
      quote: "Fast turnaround, incredible motion graphics, and zero friction during revision rounds. Tawhid is our go-to creative partner for all brand campaigns.",
      clientName: "Elena Rostova",
      role: "Marketing Head",
      companyOrChannel: "Vortex Digital",
      projectType: "Brand Identity & Motion Graphics",
      rating: 5
    }
  ],

  brands: [
    { id: "b1", name: "Brand 01", tagline: "Creative Studio" },
    { id: "b2", name: "Brand 02", tagline: "Digital Media" },
    { id: "b3", name: "Brand 03", tagline: "Creator Network" },
    { id: "b4", name: "Brand 04", tagline: "Tech Ventures" },
    { id: "b5", name: "Brand 05", tagline: "Apparel & Lifestyle" }
  ],

  socials: [
    { platform: "Instagram", url: "https://instagram.com", iconName: "Instagram", username: "@tawhid.creative" },
    { platform: "YouTube", url: "https://youtube.com", iconName: "Youtube", username: "Tawhid Edits" },
    { platform: "Behance", url: "https://behance.net", iconName: "Globe", username: "tawhid-designs" },
    { platform: "Dribbble", url: "https://dribbble.com", iconName: "Dribbble", username: "tawhid" },
    { platform: "LinkedIn", url: "https://linkedin.com", iconName: "Linkedin", username: "Tawhid Designer" },
    { platform: "Facebook", url: "https://facebook.com", iconName: "Facebook", username: "Tawhid Visuals" }
  ],

  showreel: {
    title: "Watch The Showreel",
    subheading: "2026 Director's Cut & Creative Showcase",
    description: "A quick look at my editing style, motion, storytelling, and creative direction across commercial films, social media campaigns, and motion graphics.",
    previewImage: "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?q=80&w=1600&auto=format&fit=crop",
    videoDuration: "01:45",
    embedOrVideoUrl: "https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?autoplay=1",
    chapters: [
      { title: "01: Brand Film & Commercial Cuts", time: "00:00 - 00:35" },
      { title: "02: Social Reels & Kinetic Edits", time: "00:35 - 01:05" },
      { title: "03: Motion Graphics & HUD VFX", time: "01:05 - 01:25" },
      { title: "04: DaVinci Color Grading Showcase", time: "01:25 - 01:45" }
    ]
  }
};
