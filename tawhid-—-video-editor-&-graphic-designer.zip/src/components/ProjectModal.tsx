import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Play, ArrowRight, ArrowLeft, CheckCircle2, Wrench, AlertCircle, Sparkles, ExternalLink } from 'lucide-react';
import { Project } from '../types/portfolio';

interface ProjectModalProps {
  project: Project | null;
  onClose: () => void;
  onSelectProject: (project: Project) => void;
  allProjects: Project[];
  onOpenShowreel: () => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({
  project,
  onClose,
  onSelectProject,
  allProjects,
  onOpenShowreel,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (!project) return;
      
      const currentIndex = allProjects.findIndex((p) => p.id === project.id);
      if (e.key === 'ArrowRight') {
        const nextProject = allProjects[(currentIndex + 1) % allProjects.length];
        onSelectProject(nextProject);
      } else if (e.key === 'ArrowLeft') {
        const prevProject = allProjects[(currentIndex - 1 + allProjects.length) % allProjects.length];
        onSelectProject(prevProject);
      }
    };

    if (project) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = 'auto';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [project, onClose, onSelectProject, allProjects]);

  if (!project) return null;

  const currentIndex = allProjects.findIndex((p) => p.id === project.id);
  const prevProject = allProjects[(currentIndex - 1 + allProjects.length) % allProjects.length];
  const nextProject = allProjects[(currentIndex + 1) % allProjects.length];

  return (
    <AnimatePresence>
      <div 
        className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-xl"
        role="dialog"
        aria-modal="true"
        aria-labelledby="project-modal-title"
      >
        {/* Backdrop click */}
        <div className="fixed inset-0" onClick={onClose} />

        {/* Modal Container */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.25 }}
          className="relative w-full max-w-4xl max-h-[92vh] overflow-y-auto rounded-2xl bg-[#0b0d13] border border-white/15 shadow-2xl shadow-cyan-950/60 z-10 custom-scrollbar"
        >
          {/* Close Button */}
          <button
            id="close-project-modal-btn"
            onClick={onClose}
            className="absolute top-4 right-4 z-20 p-2.5 rounded-full bg-black/70 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-white/10 transition-colors focus:outline-none cursor-pointer"
            aria-label="Close Project Modal"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Hero Media Preview */}
          <div className="relative aspect-video sm:aspect-[21/9] w-full bg-neutral-950 overflow-hidden border-b border-white/10">
            <img
              src={project.thumbnail}
              alt={project.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0b0d13] via-transparent to-black/40" />

            {/* Play Overlay if video project */}
            {(project.category === 'Video Editing' || project.category === 'Motion Graphics') && (
              <div className="absolute inset-0 flex items-center justify-center">
                <button
                  onClick={onOpenShowreel}
                  className="px-5 py-3 rounded-full bg-cyan-400 text-black font-bold text-xs tracking-wider uppercase flex items-center gap-2 shadow-xl hover:bg-cyan-300 hover:scale-105 active:scale-95 transition-all cursor-pointer whitespace-nowrap"
                >
                  <Play className="w-4 h-4 fill-black" />
                  <span>Preview In Showreel</span>
                </button>
              </div>
            )}

            {/* Badges */}
            <div className="absolute bottom-4 left-4 sm:left-6 flex flex-wrap gap-2">
              <span className="px-3 py-1 rounded-md bg-cyan-500/20 border border-cyan-400/40 text-cyan-300 text-xs font-mono font-medium">
                {project.category}
              </span>
              {project.client && (
                <span className="px-3 py-1 rounded-md bg-white/10 backdrop-blur-md text-white text-xs font-mono">
                  Client: {project.client}
                </span>
              )}
            </div>
          </div>

          {/* Project Details Content */}
          <div className="p-6 sm:p-8 space-y-8">
            
            {/* Title & Overview */}
            <div>
              <h3 id="project-modal-title" className="text-2xl sm:text-3xl font-display font-extrabold text-white mb-3">
                {project.title}
              </h3>
              <p className="text-base text-neutral-300 leading-relaxed font-light">
                {project.fullDescription}
              </p>
            </div>

            {/* Project Quick Stats */}
            {project.stats && project.stats.length > 0 && (
              <div className="grid grid-cols-3 gap-3 p-4 rounded-xl bg-white/[0.02] border border-white/10">
                {project.stats.map((s, idx) => (
                  <div key={idx} className="text-center">
                    <p className="text-xs text-neutral-400 font-mono">{s.label}</p>
                    <p className="text-base sm:text-lg font-display font-bold text-cyan-300">{s.value}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Tools Used Strip */}
            <div>
              <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-neutral-400 mb-3">
                <Wrench className="w-4 h-4 text-cyan-400" />
                <span>Production Tools Used:</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {project.toolsUsed.map((tool, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-1 rounded-lg bg-neutral-900 border border-white/10 text-xs font-mono text-neutral-200"
                  >
                    {tool}
                  </span>
                ))}
              </div>
            </div>

            {/* Challenge & Solution Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="p-5 rounded-xl bg-rose-500/5 border border-rose-500/15">
                <div className="flex items-center gap-2 text-rose-400 text-xs font-mono uppercase tracking-wider mb-2">
                  <AlertCircle className="w-4 h-4" />
                  <span>The Challenge</span>
                </div>
                <p className="text-xs sm:text-sm text-neutral-300 font-light leading-relaxed">
                  {project.challenge}
                </p>
              </div>

              <div className="p-5 rounded-xl bg-cyan-500/5 border border-cyan-500/20">
                <div className="flex items-center gap-2 text-cyan-300 text-xs font-mono uppercase tracking-wider mb-2">
                  <Sparkles className="w-4 h-4" />
                  <span>The Solution</span>
                </div>
                <p className="text-xs sm:text-sm text-neutral-300 font-light leading-relaxed">
                  {project.solution}
                </p>
              </div>
            </div>

            {/* Key Deliverables */}
            {project.deliverables && (
              <div>
                <h4 className="text-xs font-mono uppercase tracking-wider text-neutral-400 mb-3">
                  Delivered Assets:
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {project.deliverables.map((deliv, idx) => (
                    <div key={idx} className="flex items-center gap-2 p-2.5 rounded-lg bg-white/[0.02] border border-white/5 text-xs text-neutral-200">
                      <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0" />
                      <span>{deliv}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Final Impact Result */}
            <div className="p-4 rounded-xl bg-white/[0.03] border border-white/10">
              <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 block mb-1">
                Final Result & Outcome:
              </span>
              <p className="text-sm text-neutral-200 font-light">
                {project.finalResult}
              </p>
            </div>

            {/* Navigation Buttons Between Projects */}
            <div className="pt-6 border-t border-white/10 flex items-center justify-between">
              <button
                onClick={() => onSelectProject(prevProject)}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#141724] hover:bg-[#1f2438] text-xs font-mono text-neutral-300 hover:text-white transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span className="hidden sm:inline">Previous: {prevProject.title}</span>
                <span className="sm:hidden">Previous</span>
              </button>

              <button
                onClick={() => onSelectProject(nextProject)}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#141724] hover:bg-[#1f2438] text-xs font-mono text-neutral-300 hover:text-white transition-colors cursor-pointer"
              >
                <span className="hidden sm:inline">Next: {nextProject.title}</span>
                <span className="sm:hidden">Next</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
