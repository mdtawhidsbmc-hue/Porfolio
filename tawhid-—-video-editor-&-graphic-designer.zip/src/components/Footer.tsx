import React from 'react';
import { ArrowUp, Heart, Sparkles, Film, Palette, Shield } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

interface FooterProps {
  onNavigate: (sectionId: string) => void;
  onOpenAdmin?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenAdmin }) => {
  const { data } = usePortfolio();
  const { personal, socials } = data;

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#050608] border-t border-white/10 pt-16 pb-12 text-neutral-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-white/5">
          
          {/* Brand & Monogram */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 via-sky-500 to-blue-600 flex items-center justify-center font-display font-extrabold text-black text-xl shadow-lg shadow-cyan-500/20">
                T
              </div>
              <div>
                <h3 className="font-display font-bold text-lg text-white">
                  {personal.name}
                </h3>
                <p className="text-xs text-cyan-400 font-mono">
                  {personal.role}
                </p>
              </div>
            </div>
            <p className="text-xs sm:text-sm text-neutral-400 font-light leading-relaxed max-w-sm">
              Turning ideas into powerful visual stories. High-impact video editing, graphic design, social media content, and branding.
            </p>
          </div>

          {/* Quick Links */}
          <div className="md:col-span-3 space-y-3">
            <p className="text-xs font-mono uppercase tracking-widest text-white">
              Navigation
            </p>
            <ul className="space-y-2 text-xs font-mono">
              <li>
                <button onClick={() => onNavigate('home')} className="hover:text-cyan-300 transition-colors cursor-pointer">
                  01. Home
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('about')} className="hover:text-cyan-300 transition-colors cursor-pointer">
                  02. About Tawhid
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('services')} className="hover:text-cyan-300 transition-colors cursor-pointer">
                  03. Services
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('portfolio')} className="hover:text-cyan-300 transition-colors cursor-pointer">
                  04. Selected Work
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('grading-comparison')} className="hover:text-cyan-300 transition-colors cursor-pointer">
                  05. Grading Comparison
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('showreel')} className="hover:text-cyan-300 transition-colors cursor-pointer">
                  06. Showreel
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('contact')} className="hover:text-cyan-300 transition-colors cursor-pointer">
                  07. Contact & Hire
                </button>
              </li>
            </ul>
          </div>

          {/* Connect & Socials */}
          <div className="md:col-span-4 space-y-3">
            <p className="text-xs font-mono uppercase tracking-widest text-white">
              Connect Online
            </p>
            <div className="flex flex-wrap gap-2">
              {socials.map((s) => (
                <a
                  key={s.platform}
                  href={s.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-lg bg-white/[0.03] hover:bg-white/10 border border-white/5 text-xs text-neutral-300 hover:text-white transition-colors"
                >
                  {s.platform}
                </a>
              ))}
            </div>

            <div className="pt-2 text-xs font-mono text-neutral-400">
              <p>Email: {personal.email}</p>
              <p>Location: {personal.location}</p>
            </div>
          </div>

        </div>

        {/* Bottom copyright & Scroll to Top */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-neutral-400">
          <div className="flex items-center gap-3">
            <p>© {new Date().getFullYear()} {personal.name}. All Rights Reserved.</p>
            {onOpenAdmin && (
              <>
                <span>•</span>
                <button
                  onClick={onOpenAdmin}
                  className="hover:text-cyan-400 text-neutral-400 flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <Shield className="w-3 h-3 text-cyan-400" />
                  <span>Admin Dashboard</span>
                </button>
              </>
            )}
          </div>
          
          <button
            id="footer-scroll-top-btn"
            onClick={scrollToTop}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/[0.04] hover:bg-white/10 text-neutral-300 hover:text-white transition-colors cursor-pointer"
          >
            <span>Back to top</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </footer>
  );
};
