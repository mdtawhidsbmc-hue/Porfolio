import React from 'react';
import { motion } from 'motion/react';
import { Quote, Star, MessageSquare, CheckCircle } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

export const Testimonials: React.FC = () => {
  const { data } = usePortfolio();
  const { testimonials } = data;

  return (
    <section id="testimonials" className="relative py-24 lg:py-32 bg-[#07080b] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 sm:mb-20">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-mono uppercase tracking-widest mb-4">
            <MessageSquare className="w-3.5 h-3.5" />
            <span>CLIENT TESTIMONIALS</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-extrabold text-white tracking-tight mb-4">
            What Clients Say
          </h2>
          <p className="text-sm sm:text-base text-neutral-300 font-light max-w-xl mx-auto">
            Feedback from content creators, brand managers, and agency founders who trusted Tawhid with their visual productions.
          </p>
        </div>

        {/* Testimonials Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((test, idx) => (
            <motion.div
              key={test.id}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className="p-7 rounded-2xl bg-[#0e111a] border border-white/10 flex flex-col justify-between hover:border-cyan-500/30 transition-colors relative group"
            >
              <div>
                {/* Rating Stars & Quote Icon */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-1 text-amber-400">
                    {[...Array(test.rating || 5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400" />
                    ))}
                  </div>
                  <Quote className="w-6 h-6 text-cyan-500/40" />
                </div>

                {/* Quote Body */}
                <p className="text-sm text-neutral-200 leading-relaxed font-light italic mb-6">
                  "{test.quote}"
                </p>
              </div>

              {/* Client Info */}
              <div className="pt-5 border-t border-white/5 flex items-center justify-between">
                <div>
                  <h4 className="font-display font-bold text-white text-sm">
                    {test.clientName}
                  </h4>
                  <p className="text-xs text-neutral-400 font-light">
                    {test.role} • {test.companyOrChannel}
                  </p>
                  <span className="inline-block mt-1 text-[10px] font-mono text-cyan-400">
                    {test.projectType}
                  </span>
                </div>
                <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <CheckCircle className="w-3.5 h-3.5" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
};
