import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, ArrowRight, MessageSquare, ShieldCheck } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

interface FinalCTAProps {
  onNavigate: (sectionId: string) => void;
}

export const FinalCTA: React.FC<FinalCTAProps> = ({ onNavigate }) => {
  const { data } = usePortfolio();
  const { personal } = data;

  return (
    <section className="relative py-20 lg:py-28 bg-[#07080b] border-t border-white/5 overflow-hidden">
      
      {/* Background ambient lighting */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[350px] bg-cyan-500/10 rounded-full blur-[140px]" />
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        
        <div className="p-8 sm:p-12 lg:p-16 rounded-3xl bg-gradient-to-b from-[#0e111a] to-[#090b10] border border-cyan-500/30 shadow-2xl shadow-cyan-950/40 relative overflow-hidden">
          
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-mono uppercase tracking-widest mb-6">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>ACCEPTING NEW CLIENTS & PROJECTS</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-extrabold text-white tracking-tight mb-6 max-w-3xl mx-auto leading-tight">
            {personal.ctaHeading || "Ready To Create Visuals That Get Noticed?"}
          </h2>

          <p className="text-sm sm:text-base text-neutral-300 font-light max-w-xl mx-auto mb-10 leading-relaxed">
            {personal.ctaSubtext || "Let's collaborate on your next YouTube video, brand commercial, social media campaign, or graphic design package."}
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4">
            <button
              id="final-cta-start-project-btn"
              onClick={() => onNavigate('contact')}
              className="px-8 py-4 rounded-xl bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 text-black font-bold text-xs tracking-wider uppercase flex items-center gap-2 shadow-xl shadow-cyan-500/30 hover:shadow-cyan-400/50 hover:scale-105 active:scale-95 transition-all duration-300 cursor-pointer whitespace-nowrap"
            >
              <span>Get In Touch Today</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <a
              id="final-cta-whatsapp-btn"
              href={`https://wa.me/${personal.whatsapp.replace(/[^0-9]/g, '')}?text=Hi%20Tawhid,%20let's%20discuss%20a%20new%20project.`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-4 rounded-xl bg-[#141724] hover:bg-[#1f2438] text-white border border-white/10 font-semibold text-xs tracking-wider uppercase flex items-center gap-2 transition-colors whitespace-nowrap"
            >
              <MessageSquare className="w-4 h-4 text-emerald-400" />
              <span>WhatsApp Chat</span>
            </a>
          </div>

          <div className="mt-8 pt-8 border-t border-white/5 flex flex-wrap items-center justify-center gap-6 text-xs font-mono text-neutral-400">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              <span>Fast Turnaround</span>
            </div>
            <span>•</span>
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              <span>Frame-Accurate Quality</span>
            </div>
            <span>•</span>
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              <span>Full Commercial Licensing</span>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
