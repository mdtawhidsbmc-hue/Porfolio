import React, { useState, useEffect, useRef } from 'react';
import { motion, useInView } from 'motion/react';
import { Sparkles, Video, Layers, CheckCircle2, Award, Zap, Compass, ArrowRight } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

// Animated Counter Subcomponent
const StatCounter: React.FC<{ target: number; suffix: string }> = ({ target, suffix }) => {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-50px' });

  useEffect(() => {
    if (!isInView) return;
    let start = 0;
    const duration = 1400; // ms
    const stepTime = 30;
    const steps = duration / stepTime;
    const increment = target / steps;

    const timer = setInterval(() => {
      start += increment;
      if (start >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(start));
      }
    }, stepTime);

    return () => clearInterval(timer);
  }, [isInView, target]);

  return (
    <span ref={ref} className="font-display font-extrabold text-3xl sm:text-4xl lg:text-5xl text-white">
      {count}{suffix}
    </span>
  );
};

interface AboutProps {
  onNavigate: (sectionId: string) => void;
}

export const About: React.FC<AboutProps> = ({ onNavigate }) => {
  const { data } = usePortfolio();
  const { personal, stats } = data;

  const highlights = personal.aboutHighlights && personal.aboutHighlights.length > 0 
    ? personal.aboutHighlights 
    : [
        {
          title: "Visual Storyteller",
          description: "Crafting narratives through pacing, rhythm, soundscapes, and color grading that evoke emotion and hold attention."
        },
        {
          title: "Conversion-Focused",
          description: "Designing graphic assets, thumbnails, and video hooks specifically tailored to optimize click-throughs and retention."
        },
        {
          title: "Fast & Reliable",
          description: "Consistent on-time project deliveries with transparent communication and rapid iterative polish."
        }
      ];

  return (
    <section id="about" className="relative py-24 lg:py-32 bg-[#07080b] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 sm:mb-20">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-mono uppercase tracking-widest mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            <span>ABOUT TAWHID</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-extrabold text-white tracking-tight">
            {personal.aboutHeading}
          </h2>
          <div className="w-16 h-1 bg-gradient-to-r from-cyan-400 to-blue-500 mx-auto mt-4 rounded-full" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Portrait & Creative Badge Card */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden bg-neutral-900 border border-white/10 p-2 shadow-2xl group">
              <div className="relative aspect-[4/5] rounded-xl overflow-hidden bg-neutral-950">
                <img
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=1000&auto=format&fit=crop"
                  alt="Tawhid - Video Editor and Creative Graphic Designer"
                  className="w-full h-full object-cover grayscale-[25%] contrast-110 group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700"
                  loading="lazy"
                />
                
                {/* Cinematic gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#07080b] via-transparent to-black/30" />

                {/* Identity Tag */}
                <div className="absolute bottom-4 left-4 right-4 p-3.5 rounded-xl bg-black/80 backdrop-blur-md border border-white/10">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-display font-bold text-white text-base">Tawhid</p>
                      <p className="text-xs text-cyan-300 font-mono">Video Editor & Graphic Designer</p>
                    </div>
                    <div className="w-8 h-8 rounded-full bg-cyan-500/20 text-cyan-300 flex items-center justify-center font-mono text-xs font-bold">
                      26'
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Subtle glow behind card */}
            <div className="absolute -inset-4 bg-cyan-500/10 rounded-3xl blur-2xl -z-10 pointer-events-none" />
          </div>

          {/* Bio & Highlights */}
          <div className="lg:col-span-7 space-y-8">
            <div className="space-y-4">
              <p className="text-lg sm:text-xl text-white font-medium leading-relaxed">
                {personal.aboutBio1}
              </p>
              <p className="text-base text-neutral-300 font-light leading-relaxed">
                {personal.aboutBio2}
              </p>
            </div>

            {/* Value Pillars list */}
            <div className="space-y-4">
              {highlights.map((item, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl bg-white/[0.02] border border-white/5 hover:border-white/10 transition-colors flex items-start gap-3.5"
                >
                  <div className="mt-0.5 w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-300 flex items-center justify-center flex-shrink-0">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-white text-sm mb-1">{item.title}</h3>
                    <p className="text-xs sm:text-sm text-neutral-400 font-light leading-relaxed">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Action Buttons */}
            <div className="pt-2 flex flex-wrap items-center gap-4">
              <button
                id="about-cta-work-btn"
                onClick={() => onNavigate('contact')}
                className="px-6 py-3.5 rounded-xl bg-cyan-500 text-black font-bold text-xs tracking-wider uppercase flex items-center gap-2 shadow-lg shadow-cyan-500/20 hover:bg-cyan-400 hover:scale-105 active:scale-95 transition-all cursor-pointer whitespace-nowrap"
              >
                <span>Hire Tawhid For Your Project</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                id="about-view-services-btn"
                onClick={() => onNavigate('services')}
                className="px-6 py-3.5 rounded-xl bg-[#11131c] hover:bg-[#1a1e2c] text-white border border-white/10 font-semibold text-xs tracking-wider uppercase transition-colors cursor-pointer whitespace-nowrap"
              >
                <span>Explore Services</span>
              </button>
            </div>
          </div>

        </div>

        {/* Stats Strip */}
        <div className="mt-20 pt-16 border-t border-white/10">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
            {stats.map((stat, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className="p-6 rounded-2xl bg-[#0e111a] border border-white/5 text-center flex flex-col items-center justify-center hover:border-cyan-500/30 transition-all group"
              >
                <div className="mb-2">
                  <StatCounter target={stat.value} suffix={stat.suffix} />
                </div>
                <p className="font-display font-bold text-sm text-neutral-200 group-hover:text-cyan-300 transition-colors mb-1">
                  {stat.label}
                </p>
                <p className="text-[11px] font-mono text-neutral-400 font-light">
                  {stat.sublabel}
                </p>
              </motion.div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
