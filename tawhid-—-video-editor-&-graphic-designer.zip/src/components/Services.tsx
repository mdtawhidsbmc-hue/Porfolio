import React from 'react';
import { motion } from 'motion/react';
import { Film, Palette, Share2, Sparkles, Layers, Zap, ArrowRight, Check } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

interface ServicesProps {
  onSelectService: (serviceName: string) => void;
}

export const Services: React.FC<ServicesProps> = ({ onSelectService }) => {
  const { data } = usePortfolio();
  const { services } = data;

  const getServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'Film':
        return <Film className="w-6 h-6 text-cyan-400" />;
      case 'Palette':
        return <Palette className="w-6 h-6 text-cyan-400" />;
      case 'Share2':
        return <Share2 className="w-6 h-6 text-cyan-400" />;
      case 'Sparkles':
        return <Sparkles className="w-6 h-6 text-cyan-400" />;
      case 'Layers':
        return <Layers className="w-6 h-6 text-cyan-400" />;
      case 'Zap':
        return <Zap className="w-6 h-6 text-cyan-400" />;
      default:
        return <Film className="w-6 h-6 text-cyan-400" />;
    }
  };

  return (
    <section id="services" className="relative py-24 lg:py-32 bg-[#090b10] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 sm:mb-20 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-mono uppercase tracking-widest mb-3">
              <Zap className="w-3.5 h-3.5" />
              <span>SERVICES & EXPERTISE</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-extrabold text-white tracking-tight">
              What I Do
            </h2>
          </div>
          <p className="text-sm sm:text-base text-neutral-400 max-w-md font-light">
            Comprehensive creative production services engineered to elevate your brand presence and captivate modern digital audiences.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.08 }}
              className="group relative rounded-2xl bg-[#0e111a] border border-white/10 hover:border-cyan-500/40 p-7 flex flex-col justify-between transition-all duration-300 hover:shadow-xl hover:shadow-cyan-950/30 hover:-translate-y-1"
            >
              {/* Card Top */}
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div className="w-12 h-12 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center group-hover:bg-cyan-500/20 group-hover:border-cyan-400/50 transition-colors">
                    {getServiceIcon(service.iconName)}
                  </div>
                  <span className="font-mono text-xs font-bold text-neutral-400 group-hover:text-cyan-400 transition-colors">
                    {service.number}
                  </span>
                </div>

                <h3 className="text-xl font-display font-bold text-white mb-3 group-hover:text-cyan-300 transition-colors">
                  {service.title}
                </h3>

                <p className="text-sm text-neutral-300 leading-relaxed mb-6 font-light">
                  {service.description}
                </p>
              </div>

              {/* Card Bottom Deliverables */}
              <div className="pt-5 border-t border-white/5">
                <p className="text-[11px] font-mono uppercase tracking-wider text-neutral-400 mb-2.5">
                  Key Deliverables:
                </p>
                <div className="flex flex-wrap gap-1.5 mb-6">
                  {service.deliverables.map((item, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 rounded-md bg-white/[0.03] border border-white/5 text-[11px] text-neutral-300 font-mono"
                    >
                      {item}
                    </span>
                  ))}
                </div>

                {/* Inquiry Link */}
                <button
                  id={`service-inquire-btn-${service.id}`}
                  onClick={() => onSelectService(service.title)}
                  className="w-full py-2.5 rounded-xl bg-[#141724] hover:bg-cyan-500 text-neutral-300 hover:text-black font-semibold text-xs tracking-wider uppercase flex items-center justify-center gap-2 transition-all cursor-pointer whitespace-nowrap"
                >
                  <span>Inquire About {service.title}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
};
