import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Film } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

interface LoaderProps {
  onComplete: () => void;
}

export const Loader: React.FC<LoaderProps> = ({ onComplete }) => {
  const { data } = usePortfolio();
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(onComplete, 350);
          return 100;
        }
        const diff = Math.floor(Math.random() * 20) + 10;
        return Math.min(100, prev + diff);
      });
    }, 100);

    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      className="fixed inset-0 z-50 bg-[#07080b] flex flex-col items-center justify-center p-6 text-white"
    >
      <div className="w-full max-w-sm flex flex-col items-center text-center space-y-6">
        {/* Monogram */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.4 }}
          className="relative w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-400 via-sky-500 to-blue-600 flex items-center justify-center font-display font-extrabold text-2xl text-black shadow-2xl shadow-cyan-500/30"
        >
          <span>T</span>
          <span className="absolute -inset-1 rounded-2xl border border-cyan-400/40 animate-pulse pointer-events-none" />
        </motion.div>

        {/* Title & Tagline */}
        <div className="space-y-1">
          <h2 className="text-xl font-display font-bold tracking-widest uppercase text-white">
            {data.personal.name}
          </h2>
          <p className="text-xs font-mono text-cyan-400 tracking-wider">
            {data.personal.role.toUpperCase()}
          </p>
        </div>

        {/* Progress Bar */}
        <div className="w-full space-y-2">
          <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full"
              style={{ width: `${progress}%` }}
              transition={{ ease: 'easeOut' }}
            />
          </div>
          <div className="flex items-center justify-between text-[11px] font-mono text-neutral-400">
            <span>INITIALIZING REEL</span>
            <span>{progress}%</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
