import React from 'react';
import { motion } from 'motion/react';
import { Play, Film, Sparkles, Clock, MonitorPlay, Zap, ArrowRight } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

interface ShowreelProps {
  onOpenShowreel: () => void;
}

export const Showreel: React.FC<ShowreelProps> = ({ onOpenShowreel }) => {
  const { data } = usePortfolio();
  const { showreel } = data;

  return (
    <section id="showreel" className="relative py-24 lg:py-32 bg-[#07080b] border-t border-white/5 overflow-hidden">
      
      {/* Background ambient lighting */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-cyan-500/10 rounded-full blur-[140px]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-mono uppercase tracking-widest mb-4">
            <Film className="w-3.5 h-3.5" />
            <span>CINEMATIC SHOWCASE</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-extrabold text-white tracking-tight mb-4">
            {showreel.title}
          </h2>
          <p className="text-sm sm:text-base text-neutral-300 font-light max-w-xl mx-auto">
            {showreel.description}
          </p>
        </div>

        {/* Cinematic Video Box */}
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 30 }}
          whileInView={{ opacity: 1, scale: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="relative max-w-5xl mx-auto rounded-2xl p-2 sm:p-3 bg-gradient-to-b from-cyan-500/20 via-white/5 to-white/5 border border-cyan-500/30 shadow-2xl shadow-cyan-950/40 group"
        >
          <div 
            onClick={onOpenShowreel}
            className="relative aspect-video rounded-xl overflow-hidden bg-neutral-950 cursor-pointer"
          >
            {/* Showreel Preview Image */}
            <img
              src={showreel.previewImage}
              alt="Tawhid Cinematic Video Editing Showreel"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 brightness-90 group-hover:brightness-100"
              loading="lazy"
            />

            {/* Dark Vignette Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-black/40" />

            {/* Top Info Bar */}
            <div className="absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-none">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-md bg-black/70 backdrop-blur-md border border-white/10 text-xs font-mono text-cyan-300">
                  DIRECTOR'S CUT
                </span>
                <span className="hidden sm:inline px-3 py-1 rounded-md bg-black/70 backdrop-blur-md border border-white/10 text-xs font-mono text-white">
                  4K 60FPS MASTER
                </span>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-md bg-cyan-500/20 backdrop-blur-md border border-cyan-400/40 text-xs font-mono text-white">
                <Clock className="w-3.5 h-3.5 text-cyan-400" />
                <span>{showreel.videoDuration}</span>
              </div>
            </div>

            {/* Centered Play Button with Pulsing Wave */}
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
              <div className="relative flex items-center justify-center">
                <div className="absolute -inset-4 rounded-full bg-cyan-400/20 animate-ping pointer-events-none" />
                <button
                  id="showreel-play-main-btn"
                  onClick={onOpenShowreel}
                  className="w-20 sm:w-24 h-20 sm:h-24 rounded-full bg-cyan-400 text-black flex items-center justify-center shadow-2xl shadow-cyan-400/50 group-hover:scale-110 active:scale-95 transition-all duration-300 cursor-pointer"
                  aria-label="Play Showreel"
                >
                  <Play className="w-9 h-9 sm:w-10 sm:h-10 ml-1.5 fill-black text-black" />
                </button>
              </div>

              <span className="px-4 py-1.5 rounded-full bg-black/70 backdrop-blur-md border border-white/10 text-xs font-mono text-neutral-200 tracking-wider uppercase group-hover:text-cyan-300 group-hover:border-cyan-400/30 transition-colors">
                Click to launch interactive player
              </span>
            </div>

            {/* Bottom Metadata Strip */}
            <div className="absolute bottom-4 left-4 right-4 p-3 rounded-lg bg-black/75 backdrop-blur-md border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-display font-semibold text-white">
                  Featuring: Commercial Cuts • Social Reels • Kinetic Motion • DaVinci Color
                </span>
              </div>

              <div className="text-[11px] font-mono text-cyan-300">
                PRORES 422 HQ • REC.709
              </div>
            </div>

          </div>
        </motion.div>

      </div>
    </section>
  );
};
