import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Eye, ArrowUpRight, Play, Film, Palette, Layers } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';
import { Project, ProjectCategory } from '../types/portfolio';

interface PortfolioProps {
  onSelectProject: (project: Project) => void;
  onOpenShowreel: () => void;
}

export const Portfolio: React.FC<PortfolioProps> = ({ onSelectProject, onOpenShowreel }) => {
  const { data } = usePortfolio();
  const { projects } = data;
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = [
    'All',
    'Video Editing',
    'Graphic Design',
    'Social Media',
    'Branding',
    'Motion Graphics',
    'Thumbnail Design'
  ];

  const filteredProjects = selectedCategory === 'All'
    ? projects
    : projects.filter((p) => p.category === selectedCategory);

  return (
    <section id="portfolio" className="relative py-24 lg:py-32 bg-[#07080b] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-mono uppercase tracking-widest mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            <span>PORTFOLIO SHOWCASE</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-extrabold text-white tracking-tight mb-4">
            Selected Work
          </h2>
          <p className="text-sm sm:text-base text-neutral-300 font-light max-w-xl mx-auto">
            A curated collection of commercial cuts, brand identities, and high-CTR social content.
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
          {categories.map((cat) => {
            const isActive = selectedCategory === cat;
            const count = cat === 'All' 
              ? projects.length 
              : projects.filter(p => p.category === cat).length;
            
            if (count === 0 && cat !== 'All') return null;

            return (
              <button
                key={cat}
                id={`filter-btn-${cat.toLowerCase().replace(/\s+/g, '-')}`}
                onClick={() => setSelectedCategory(cat)}
                className={`relative px-4 py-2 rounded-xl text-xs font-mono uppercase tracking-wider transition-all duration-200 flex items-center gap-2 cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-cyan-500 text-black font-bold shadow-lg shadow-cyan-500/25 scale-105'
                    : 'bg-[#11131c] hover:bg-[#1b2030] text-neutral-300 hover:text-white border border-white/10'
                }`}
              >
                <span>{cat}</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                  isActive ? 'bg-black/20 text-black font-bold' : 'bg-white/10 text-neutral-400'
                }`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Projects Grid */}
        <motion.div 
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8"
        >
          <AnimatePresence mode="popLayout">
            {filteredProjects.map((project) => (
              <motion.div
                key={project.id}
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.35 }}
                className="group relative rounded-2xl bg-[#0e111a] border border-white/10 hover:border-cyan-500/50 overflow-hidden flex flex-col justify-between transition-all duration-300 hover:shadow-2xl hover:shadow-cyan-950/40"
              >
                {/* Media Thumbnail Container */}
                <div 
                  className="relative aspect-video w-full overflow-hidden bg-neutral-950 cursor-pointer"
                  onClick={() => onSelectProject(project)}
                >
                  <img
                    src={project.thumbnail}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 brightness-95 group-hover:brightness-100"
                    loading="lazy"
                  />

                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0e111a] via-transparent to-black/30 opacity-85 group-hover:opacity-60 transition-opacity" />

                  {/* Category Pill */}
                  <div className="absolute top-3.5 left-3.5">
                    <span className="px-2.5 py-1 rounded-md bg-black/70 backdrop-blur-md border border-white/10 text-[11px] font-mono text-cyan-300 font-medium">
                      {project.category}
                    </span>
                  </div>

                  {/* Hover Quick Action Indicator */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40 backdrop-blur-[2px]">
                    <div className="px-4 py-2 rounded-full bg-cyan-400 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-xl transform translate-y-2 group-hover:translate-y-0 transition-transform">
                      <Eye className="w-3.5 h-3.5" />
                      <span>View Case Study</span>
                    </div>
                  </div>
                </div>

                {/* Card Content Body */}
                <div className="p-6 flex flex-col flex-grow justify-between">
                  <div>
                    <h3 
                      onClick={() => onSelectProject(project)}
                      className="text-lg font-display font-bold text-white group-hover:text-cyan-300 transition-colors mb-2 cursor-pointer"
                    >
                      {project.title}
                    </h3>
                    <p className="text-xs text-neutral-300 font-light line-clamp-2 leading-relaxed mb-4">
                      {project.shortDescription}
                    </p>
                  </div>

                  {/* Tools Strip & Modal Trigger */}
                  <div className="pt-4 border-t border-white/5 flex items-center justify-between">
                    <div className="flex flex-wrap gap-1">
                      {project.toolsUsed.slice(0, 3).map((tool, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-0.5 rounded bg-white/[0.04] text-[10px] font-mono text-neutral-300"
                        >
                          {tool}
                        </span>
                      ))}
                    </div>

                    <button
                      onClick={() => onSelectProject(project)}
                      className="text-xs font-mono text-cyan-400 group-hover:text-white flex items-center gap-1 cursor-pointer transition-colors"
                      aria-label={`Open details for ${project.title}`}
                    >
                      <span>Explore</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

      </div>
    </section>
  );
};
