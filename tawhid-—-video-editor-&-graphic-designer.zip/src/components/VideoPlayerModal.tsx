import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Play, Pause, Volume2, VolumeX, Maximize, RotateCcw, Sparkles, Film, Check } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

interface VideoPlayerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VideoPlayerModal: React.FC<VideoPlayerModalProps> = ({ isOpen, onClose }) => {
  const { data } = usePortfolio();
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(25); // percentage
  const [activeChapter, setActiveChapter] = useState(0);

  const { showreel } = data;
  const chapters = showreel.chapters || [
    { title: "01: Commercial & Brand Cuts", time: "00:00 - 00:35" },
    { title: "02: Viral Reels & Kinetic Edits", time: "00:35 - 01:05" },
    { title: "03: Motion Graphics & HUD VFX", time: "01:05 - 01:25" },
    { title: "04: DaVinci Color Grading Showcase", time: "01:25 - 01:45" }
  ];

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === ' ' || e.code === 'Space') {
        e.preventDefault();
        setIsPlaying((prev) => !prev);
      }
    };

    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = 'auto';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  // Simulate playback time progression
  useEffect(() => {
    let interval: any;
    if (isOpen && isPlaying) {
      interval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) return 0;
          return prev + 0.5;
        });
      }, 250);
    }
    return () => clearInterval(interval);
  }, [isOpen, isPlaying]);

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div 
        className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-2xl"
        role="dialog"
        aria-modal="true"
        aria-labelledby="video-modal-title"
      >
        {/* Backdrop */}
        <div className="fixed inset-0" onClick={onClose} />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.25 }}
          className="relative w-full max-w-5xl rounded-2xl bg-[#090a0f] border border-cyan-500/30 shadow-2xl shadow-cyan-950/60 overflow-hidden z-10"
        >
          {/* Header Bar */}
          <div className="p-4 sm:px-6 bg-[#11131c] border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
              <div>
                <h4 id="video-modal-title" className="font-display font-bold text-white text-sm sm:text-base">
                  TAWHID • 2026 DIRECTOR'S SHOWREEL
                </h4>
                <p className="text-[11px] font-mono text-cyan-400">4K Master • 60 FPS • Stereo Master</p>
              </div>
            </div>

            <button
              id="close-showreel-modal-btn"
              onClick={onClose}
              className="p-2 rounded-lg bg-neutral-800/80 hover:bg-neutral-700 text-neutral-300 hover:text-white border border-white/10 transition-colors cursor-pointer"
              aria-label="Close Showreel"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Video Player Display */}
          <div className="relative aspect-video w-full bg-black flex items-center justify-center overflow-hidden group">
            <img
              src={showreel.previewImage}
              alt="Tawhid Showreel Preview"
              className="w-full h-full object-cover brightness-90"
            />

            {/* Film Grading LUT Overlay Simulator */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-black/40 pointer-events-none" />

            {/* Telemetry / HUD */}
            <div className="absolute top-4 left-6 pointer-events-none text-left">
              <span className="px-2 py-0.5 rounded bg-black/60 font-mono text-[10px] text-cyan-300 border border-cyan-500/30">
                PRORES 422 HQ
              </span>
            </div>

            <div className="absolute top-4 right-6 pointer-events-none text-right font-mono text-[11px] text-white/80">
              TC 00:01:14:18
            </div>

            {/* Central Play/Pause Trigger */}
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="absolute inset-0 flex items-center justify-center cursor-pointer bg-transparent focus:outline-none"
              aria-label={isPlaying ? "Pause video" : "Play video"}
            >
              <div className="w-20 h-20 rounded-full bg-cyan-400/90 hover:bg-cyan-300 text-black flex items-center justify-center shadow-2xl transform group-hover:scale-105 transition-transform">
                {isPlaying ? <Pause className="w-8 h-8 fill-black" /> : <Play className="w-8 h-8 ml-1 fill-black" />}
              </div>
            </button>

            {/* Video Controls Bottom Bar */}
            <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black via-black/90 to-transparent">
              
              {/* Progress Scrubber */}
              <div 
                className="relative w-full h-1.5 bg-neutral-800 rounded-full mb-3 cursor-pointer overflow-hidden group/track"
                onClick={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const clickX = e.clientX - rect.left;
                  const newPercent = (clickX / rect.width) * 100;
                  setProgress(newPercent);
                }}
              >
                <div 
                  className="h-full bg-cyan-400 relative" 
                  style={{ width: `${progress}%` }}
                />
              </div>

              {/* Controls Strip */}
              <div className="flex items-center justify-between text-xs font-mono text-neutral-300">
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="text-white hover:text-cyan-300 transition-colors cursor-pointer"
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </button>

                  <button
                    onClick={() => setIsMuted(!isMuted)}
                    className="text-white hover:text-cyan-300 transition-colors cursor-pointer"
                  >
                    {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
                  </button>

                  <span className="text-neutral-400">
                    00:{Math.floor(progress * 0.6).toString().padStart(2, '0')} / {showreel.videoDuration}
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <span className="hidden sm:inline px-2 py-0.5 rounded bg-white/10 text-[10px] text-cyan-300">
                    PRESS SPACE TO PLAY/PAUSE
                  </span>
                  <button
                    onClick={() => setProgress(0)}
                    className="text-neutral-400 hover:text-white transition-colors cursor-pointer p-1"
                    title="Replay from start"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Chapter Selector Strip */}
          <div className="p-4 bg-[#0e111a] border-t border-white/10">
            <p className="text-[11px] font-mono uppercase tracking-widest text-cyan-400 mb-2.5">
              Reel Chapters & Highlights:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
              {chapters.map((chap, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setActiveChapter(idx);
                    setProgress(idx * 25);
                    setIsPlaying(true);
                  }}
                  className={`p-2.5 rounded-lg text-left transition-all cursor-pointer border ${
                    activeChapter === idx
                      ? 'bg-cyan-500/20 border-cyan-400/50 text-white'
                      : 'bg-white/[0.02] border-white/5 text-neutral-400 hover:text-white hover:bg-white/[0.05]'
                  }`}
                >
                  <p className="text-xs font-semibold truncate">{chap.title}</p>
                  <p className="text-[10px] font-mono text-neutral-400 mt-0.5">{chap.time}</p>
                </button>
              ))}
            </div>
          </div>

        </motion.div>
      </div>
    </AnimatePresence>
  );
};
