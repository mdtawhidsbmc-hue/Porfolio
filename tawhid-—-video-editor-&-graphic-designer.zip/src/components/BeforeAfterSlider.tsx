import React, { useState, useRef, useCallback } from 'react';
import { motion } from 'motion/react';
import { Sparkles, MoveHorizontal, Sliders, ShieldCheck, Film, Layers } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';
import { BeforeAfterSample } from '../types/portfolio';

export const BeforeAfterSlider: React.FC = () => {
  const { data } = usePortfolio();
  const { beforeAfterSamples } = data;
  const [activeSampleIndex, setActiveSampleIndex] = useState(0);
  const [sliderPos, setSliderPos] = useState(50); // percentage 0 - 100
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const activeSample: BeforeAfterSample = beforeAfterSamples[activeSampleIndex] || beforeAfterSamples[0];

  const handleMove = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const width = rect.width;
    const clampedPercent = Math.max(0, Math.min(100, (x / width) * 100));
    setSliderPos(clampedPercent);
  }, []);

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length > 0) {
      handleMove(e.touches[0].clientX);
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      handleMove(e.clientX);
    }
  };

  return (
    <section id="grading-comparison" className="relative py-24 lg:py-32 bg-[#090b10] border-t border-white/5 overflow-hidden">
      
      {/* Background Ambient Glow */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-cyan-500/10 rounded-full blur-[140px]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-mono uppercase tracking-widest mb-4">
            <Sliders className="w-3.5 h-3.5" />
            <span>POST-PRODUCTION & COLOR GRADING</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-extrabold text-white tracking-tight mb-4">
            Raw Footage vs. Master Grade
          </h2>
          <p className="text-sm sm:text-base text-neutral-300 font-light max-w-2xl mx-auto">
            Drag the interactive slider to see how flat camera profiles and raw assets are transformed into cinematic, color-balanced visual experiences.
          </p>
        </div>

        {/* Sample Selection Buttons */}
        <div className="flex flex-wrap justify-center gap-2.5 mb-8">
          {beforeAfterSamples.map((sample, idx) => (
            <button
              key={sample.id}
              onClick={() => {
                setActiveSampleIndex(idx);
                setSliderPos(50);
              }}
              className={`px-4 py-2 rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-200 cursor-pointer ${
                activeSampleIndex === idx
                  ? 'bg-cyan-500 text-black font-bold shadow-lg shadow-cyan-500/25'
                  : 'bg-[#11131c] hover:bg-[#1a1e2b] text-neutral-300 hover:text-white border border-white/10'
              }`}
            >
              {sample.title}
            </button>
          ))}
        </div>

        {/* Interactive Comparison Stage */}
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="relative max-w-5xl mx-auto rounded-2xl bg-neutral-900 border border-white/10 p-2 sm:p-3 shadow-2xl shadow-cyan-950/40"
        >
          {/* Main Slider Canvas */}
          <div
            ref={containerRef}
            onMouseDown={() => setIsDragging(true)}
            onMouseUp={() => setIsDragging(false)}
            onMouseLeave={() => setIsDragging(false)}
            onMouseMove={handleMouseMove}
            onTouchMove={handleTouchMove}
            className="relative aspect-video w-full rounded-xl overflow-hidden cursor-ew-resize select-none bg-black"
          >
            {/* After / Graded Image (Full Background) */}
            <img
              src={activeSample.afterImage}
              alt={`${activeSample.title} - ${activeSample.afterLabel}`}
              className="absolute inset-0 w-full h-full object-cover pointer-events-none"
              loading="lazy"
            />

            {/* Before / Raw Image (Clipped by slider percentage) */}
            <div
              className="absolute inset-y-0 left-0 overflow-hidden pointer-events-none"
              style={{ width: `${sliderPos}%` }}
            >
              <div className="relative h-full" style={{ width: containerRef.current ? `${containerRef.current.clientWidth}px` : '100%' }}>
                <img
                  src={activeSample.beforeImage}
                  alt={`${activeSample.title} - ${activeSample.beforeLabel}`}
                  className="absolute inset-0 w-full h-full object-cover max-w-none"
                  style={{ width: containerRef.current ? `${containerRef.current.clientWidth}px` : '100vw' }}
                  loading="lazy"
                />
              </div>
            </div>

            {/* Draggable Divider Line & Knob */}
            <div
              className="absolute top-0 bottom-0 w-1 bg-cyan-400 shadow-2xl shadow-cyan-400 pointer-events-none"
              style={{ left: `${sliderPos}%` }}
            >
              <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-10 h-10 rounded-full bg-cyan-400 text-black flex items-center justify-center shadow-xl shadow-cyan-500/50 border-2 border-white">
                <MoveHorizontal className="w-5 h-5" />
              </div>
            </div>

            {/* Left Pill (Before Label) */}
            <div className="absolute top-4 left-4 pointer-events-none">
              <span className="px-3 py-1.5 rounded-lg bg-black/80 backdrop-blur-md border border-white/10 text-xs font-mono text-neutral-300 font-medium shadow-md">
                {activeSample.beforeLabel}
              </span>
            </div>

            {/* Right Pill (After Label) */}
            <div className="absolute top-4 right-4 pointer-events-none">
              <span className="px-3 py-1.5 rounded-lg bg-cyan-500/30 backdrop-blur-md border border-cyan-400/50 text-xs font-mono text-cyan-200 font-semibold shadow-md">
                {activeSample.afterLabel}
              </span>
            </div>

            {/* Bottom Interaction Hint */}
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 pointer-events-none hidden sm:block">
              <span className="px-3 py-1 rounded-full bg-black/70 backdrop-blur-md border border-white/10 text-[11px] font-mono text-neutral-300">
                Drag slider left / right to compare
              </span>
            </div>
          </div>

          {/* Sample Description & Technical Specs */}
          <div className="mt-4 p-4 rounded-xl bg-white/[0.02] border border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-left">
            <div>
              <h4 className="text-sm font-display font-bold text-white mb-1">
                {activeSample.category}
              </h4>
              <p className="text-xs text-neutral-400 font-light max-w-xl">
                {activeSample.description}
              </p>
            </div>

            <div className="sm:text-right flex-shrink-0">
              <span className="text-[11px] font-mono px-3 py-1 rounded-md bg-white/[0.05] border border-white/10 text-cyan-300">
                {activeSample.specs}
              </span>
            </div>
          </div>

        </motion.div>

      </div>
    </section>
  );
};
