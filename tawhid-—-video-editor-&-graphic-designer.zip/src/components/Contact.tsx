import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Mail, 
  Phone, 
  MessageSquare, 
  MapPin, 
  Copy, 
  Check, 
  Send, 
  Sparkles, 
  ArrowRight,
  Clock,
  ShieldCheck
} from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

interface ContactProps {
  onShowToast: (message: string) => void;
  preselectedService?: string;
}

export const Contact: React.FC<ContactProps> = ({ onShowToast, preselectedService }) => {
  const { data, addInquiry } = usePortfolio();
  const { personal, socials } = data;

  const [copiedEmail, setCopiedEmail] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    projectType: preselectedService || 'Video Editing',
    budget: '$500 - $1,500',
    timeline: 'Within 2 Weeks',
    message: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(personal.email);
    setCopiedEmail(true);
    onShowToast(`Copied ${personal.email} to clipboard!`);
    setTimeout(() => setCopiedEmail(false), 3000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      onShowToast("Please fill in your name, email, and project message.");
      return;
    }

    setIsSubmitting(true);

    // Record inquiry into Admin Context & LocalStorage
    addInquiry({
      name: formData.name,
      email: formData.email,
      projectType: formData.projectType,
      budget: formData.budget,
      timeline: formData.timeline,
      message: formData.message,
    });
    
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      onShowToast("Inquiry sent successfully! Tawhid will get back to you within 24 hours.");
    }, 600);
  };

  return (
    <section id="contact" className="relative py-24 lg:py-32 bg-[#090b10] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 sm:mb-20">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-mono uppercase tracking-widest mb-4">
            <Mail className="w-3.5 h-3.5" />
            <span>LET'S WORK TOGETHER</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-extrabold text-white tracking-tight mb-4">
            Start Your Next Project
          </h2>
          <p className="text-sm sm:text-base text-neutral-300 font-light max-w-xl mx-auto">
            Have a video, design campaign, or branding project in mind? Reach out and let's craft something memorable.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Left Column: Direct Info & Quick Actions */}
          <div className="lg:col-span-5 space-y-8">
            
            {/* Quick Contact Card */}
            <div className="p-7 rounded-2xl bg-[#0e111a] border border-white/10 space-y-6">
              <div>
                <h3 className="font-display font-bold text-xl text-white mb-2">
                  Direct Inquiries
                </h3>
                <p className="text-xs sm:text-sm text-neutral-300 font-light leading-relaxed">
                  I typically respond within 12–24 hours on business days.
                </p>
              </div>

              {/* Email 1-Click Copy Box */}
              <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 space-y-2">
                <span className="text-[11px] font-mono uppercase tracking-wider text-neutral-400">
                  Direct Email
                </span>
                <div className="flex items-center justify-between gap-2">
                  <span className="font-mono text-sm text-cyan-300 truncate">
                    {personal.email}
                  </span>
                  <button
                    id="contact-copy-email-btn"
                    onClick={handleCopyEmail}
                    className="p-2 rounded-lg bg-cyan-500/10 hover:bg-cyan-500 text-cyan-300 hover:text-black transition-colors cursor-pointer flex-shrink-0"
                    title="Copy email address"
                  >
                    {copiedEmail ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* WhatsApp Direct Chat Button */}
              <a
                id="contact-whatsapp-btn"
                href={`https://wa.me/${personal.whatsapp.replace(/[^0-9]/g, '')}?text=Hi%20Tawhid,%20I%20have%20a%20project%20inquiry.`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3.5 px-4 rounded-xl bg-emerald-500/15 hover:bg-emerald-500 text-emerald-300 hover:text-black border border-emerald-500/30 font-semibold text-xs tracking-wider uppercase flex items-center justify-center gap-2 transition-all cursor-pointer whitespace-nowrap"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Instant WhatsApp Chat</span>
              </a>

              {/* Location & Status */}
              <div className="pt-4 border-t border-white/5 space-y-2 text-xs font-mono text-neutral-300">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-cyan-400" />
                  <span>{personal.location}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-cyan-400" />
                  <span>GMT+6 (Flexible with US/EU time zones)</span>
                </div>
              </div>
            </div>

            {/* Social Channels Strip */}
            <div>
              <p className="text-xs font-mono uppercase tracking-wider text-neutral-400 mb-3">
                Follow & Connect:
              </p>
              <div className="flex flex-wrap gap-2">
                {socials.map((s) => (
                  <a
                    key={s.platform}
                    href={s.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-2 rounded-xl bg-[#0e111a] hover:bg-[#191d2c] border border-white/10 text-xs font-mono text-neutral-300 hover:text-white transition-colors flex items-center gap-1.5"
                  >
                    <span>{s.platform}</span>
                    <ArrowRight className="w-3 h-3 text-cyan-400" />
                  </a>
                ))}
              </div>
            </div>

          </div>

          {/* Right Column: Project Brief Inquiry Form */}
          <div className="lg:col-span-7">
            <div className="p-7 sm:p-9 rounded-2xl bg-[#0e111a] border border-white/10 shadow-2xl relative">
              
              {isSubmitted ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="py-12 text-center space-y-5"
                >
                  <div className="w-16 h-16 rounded-full bg-cyan-500/20 text-cyan-300 flex items-center justify-center mx-auto border border-cyan-400/40">
                    <Check className="w-8 h-8" />
                  </div>
                  <h3 className="text-2xl font-display font-bold text-white">
                    Inquiry Received!
                  </h3>
                  <p className="text-sm text-neutral-300 font-light max-w-md mx-auto leading-relaxed">
                    Thank you for reaching out, {formData.name}. I've received your project details and will review the specifications and email you back within 24 hours.
                  </p>
                  <button
                    onClick={() => {
                      setIsSubmitted(false);
                      setFormData({
                        name: '',
                        email: '',
                        projectType: 'Video Editing',
                        budget: '$500 - $1,500',
                        timeline: 'Within 2 Weeks',
                        message: ''
                      });
                    }}
                    className="px-6 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-mono text-white transition-colors cursor-pointer"
                  >
                    Send Another Inquiry
                  </button>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    {/* Name */}
                    <div className="space-y-2">
                      <label className="block text-xs font-mono uppercase tracking-wider text-neutral-300">
                        Your Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="e.g. Alex Rivera"
                        className="w-full px-4 py-3 rounded-xl bg-[#07080b] border border-white/10 text-white placeholder-neutral-500 text-sm focus:border-cyan-400 focus:bg-[#0c0e14] transition-all outline-none"
                      />
                    </div>

                    {/* Email */}
                    <div className="space-y-2">
                      <label className="block text-xs font-mono uppercase tracking-wider text-neutral-300">
                        Your Email *
                      </label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="e.g. alex@company.com"
                        className="w-full px-4 py-3 rounded-xl bg-[#07080b] border border-white/10 text-white placeholder-neutral-500 text-sm focus:border-cyan-400 focus:bg-[#0c0e14] transition-all outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                    {/* Project Type */}
                    <div className="space-y-2">
                      <label className="block text-xs font-mono uppercase tracking-wider text-neutral-300">
                        Service
                      </label>
                      <select
                        value={formData.projectType}
                        onChange={(e) => setFormData({ ...formData, projectType: e.target.value })}
                        className="w-full px-3.5 py-3 rounded-xl bg-[#07080b] border border-white/10 text-white text-sm focus:border-cyan-400 outline-none cursor-pointer"
                      >
                        <option value="Video Editing">Video Editing</option>
                        <option value="Graphic Design">Graphic Design</option>
                        <option value="Thumbnail Design">Thumbnail Design</option>
                        <option value="Social Media Content">Social Media Content</option>
                        <option value="Motion Graphics">Motion Graphics</option>
                        <option value="Brand Visuals">Brand Visuals</option>
                      </select>
                    </div>

                    {/* Budget Bracket */}
                    <div className="space-y-2">
                      <label className="block text-xs font-mono uppercase tracking-wider text-neutral-300">
                        Estimated Budget
                      </label>
                      <select
                        value={formData.budget}
                        onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                        className="w-full px-3.5 py-3 rounded-xl bg-[#07080b] border border-white/10 text-white text-sm focus:border-cyan-400 outline-none cursor-pointer"
                      >
                        <option value="< $300">&lt; $300</option>
                        <option value="$300 - $600">$300 - $600</option>
                        <option value="$600 - $1,500">$600 - $1,500</option>
                        <option value="$1,500+">$1,500+</option>
                      </select>
                    </div>

                    {/* Timeline */}
                    <div className="space-y-2">
                      <label className="block text-xs font-mono uppercase tracking-wider text-neutral-300">
                        Timeline
                      </label>
                      <select
                        value={formData.timeline}
                        onChange={(e) => setFormData({ ...formData, timeline: e.target.value })}
                        className="w-full px-3.5 py-3 rounded-xl bg-[#07080b] border border-white/10 text-white text-sm focus:border-cyan-400 outline-none cursor-pointer"
                      >
                        <option value="Urgent (< 3 Days)">Urgent (&lt; 3 Days)</option>
                        <option value="Within 1 Week">Within 1 Week</option>
                        <option value="Within 2 Weeks">Within 2 Weeks</option>
                        <option value="Flexible">Flexible</option>
                      </select>
                    </div>
                  </div>

                  {/* Project Message */}
                  <div className="space-y-2">
                    <label className="block text-xs font-mono uppercase tracking-wider text-neutral-300">
                      Project Details & Vision *
                    </label>
                    <textarea
                      required
                      rows={4}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Tell me about your footage, reference styles, channel link, deliverables needed, or any specific requests..."
                      className="w-full px-4 py-3 rounded-xl bg-[#07080b] border border-white/10 text-white placeholder-neutral-500 text-sm focus:border-cyan-400 focus:bg-[#0c0e14] transition-all outline-none resize-none"
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    id="contact-submit-btn"
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-4 rounded-xl bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 text-black font-bold text-xs tracking-wider uppercase flex items-center justify-center gap-2 shadow-xl shadow-cyan-500/25 hover:shadow-cyan-400/40 hover:scale-[1.01] active:scale-[0.99] transition-all duration-300 cursor-pointer disabled:opacity-50 whitespace-nowrap"
                  >
                    {isSubmitting ? (
                      <span>Sending Brief...</span>
                    ) : (
                      <>
                        <span>Submit Project Brief</span>
                        <Send className="w-4 h-4" />
                      </>
                    )}
                  </button>

                  <div className="flex items-center justify-center gap-2 text-[11px] font-mono text-neutral-400">
                    <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Your information is kept 100% confidential.</span>
                  </div>

                </form>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
