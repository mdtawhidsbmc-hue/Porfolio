import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, Film } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

export const BrandWall: React.FC = () => {
  const { data } = usePortfolio();
  const { brands } = data;

  return (
    <section className="py-12 bg-[#06070a] border-t border-white/5 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          
          <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-neutral-400">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>TRUSTED BY CREATORS & STUDIOS WORLDWIDE</span>
          </div>

          <div className="flex flex-wrap items-center gap-6 sm:gap-10">
            {brands.map((b) => (
              <div
                key={b.id}
                className="flex items-center gap-2 group cursor-default"
              >
                <div className="w-2 h-2 rounded-full bg-cyan-500/40 group-hover:bg-cyan-400 transition-colors" />
                <span className="font-display font-bold text-sm sm:text-base text-neutral-400 group-hover:text-white transition-colors tracking-wide">
                  {b.name}
                </span>
                <span className="text-[11px] font-mono text-neutral-400 hidden sm:inline">
                  [{b.tagline}]
                </span>
              </div>
            ))}
          </div>

        </div>
      </div>
    </section>
  );
};
