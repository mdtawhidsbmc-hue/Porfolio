import React from 'react';
import { motion } from 'motion/react';
import { Play, ArrowRight, Sparkles, Film, Palette, ShieldCheck, Video, Sliders } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

interface HeroProps {
  onOpenShowreel: () => void;
  onNavigate: (sectionId: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenShowreel, onNavigate }) => {
  const { data } = usePortfolio();
  const { personal, showreel } = data;

  return (
    <section
      id="home"
      className="relative min-h-[92vh] pt-28 pb-16 lg:pt-36 lg:pb-24 flex items-center justify-center overflow-hidden cinematic-bg"
    >
      {/* Background cinematic grid and lighting */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[850px] h-[550px] bg-cyan-500/10 rounded-full blur-[150px]" />
        <div className="absolute top-1/3 -right-20 w-[450px] h-[450px] bg-blue-600/10 rounded-full blur-[130px]" />
        <div className="absolute bottom-10 left-10 w-[350px] h-[350px] bg-sky-500/5 rounded-full blur-[100px]" />
        
        {/* Subtle grid pattern overlay */}
        <div 
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)`,
            backgroundSize: '4rem 4rem'
          }}
        />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-10 items-center">
          
          {/* Left Column: Heading & CTAs */}
          <div className="lg:col-span-7 flex flex-col items-start text-left">
            
            {/* Small Label Badge */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/[0.04] border border-white/10 backdrop-blur-md mb-6"
            >
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              <span className="text-xs font-mono tracking-widest text-cyan-300 font-semibold uppercase whitespace-nowrap">
                {personal.heroBadge || personal.role.toUpperCase()}
              </span>
            </motion.div>

            {/* Main Heading */}
            <motion.h1
              initial={{ opacity: 0, y: 25 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-4xl sm:text-5xl md:text-6xl lg:text-6xl font-display font-extrabold tracking-tight text-white leading-[1.08] mb-6 whitespace-pre-line"
            >
              {personal.heroHeading}
            </motion.h1>

            {/* Supporting Text */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-base sm:text-lg text-neutral-300 max-w-2xl font-light leading-relaxed mb-8 sm:mb-10"
            >
              {personal.heroSubtext}
            </motion.p>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-wrap items-center gap-4 w-full sm:w-auto"
            >
              {/* Primary CTA */}
              <button
                id="hero-view-work-btn"
                onClick={() => onNavigate('portfolio')}
                className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 text-black font-bold text-xs tracking-wider uppercase flex items-center justify-center gap-2.5 shadow-lg shadow-cyan-500/25 hover:shadow-cyan-400/40 hover:scale-[1.02] active:scale-[0.98] transition-all duration-300 cursor-pointer whitespace-nowrap"
              >
                <span>View My Work</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              {/* Secondary CTA */}
              <button
                id="hero-contact-btn"
                onClick={() => onNavigate('contact')}
                className="w-full sm:w-auto px-8 py-4 rounded-xl bg-[#121520] hover:bg-[#1b2030] text-white border border-white/10 hover:border-cyan-400/40 font-semibold text-xs tracking-wider uppercase flex items-center justify-center gap-2 transition-all duration-300 cursor-pointer whitespace-nowrap"
              >
                <span>Let's Work Together</span>
              </button>
            </motion.div>

            {/* Quick Skills Strip */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.7, delay: 0.45 }}
              className="mt-10 pt-8 border-t border-white/10 flex flex-wrap items-center gap-y-3 gap-x-6 text-xs text-neutral-400 font-mono"
            >
              <div className="flex items-center gap-2 whitespace-nowrap">
                <Film className="w-4 h-4 text-cyan-400" />
                <span>Premiere Pro • After Effects • DaVinci</span>
              </div>
              <div className="hidden sm:block text-neutral-600">•</div>
              <div className="flex items-center gap-2 whitespace-nowrap">
                <Palette className="w-4 h-4 text-cyan-400" />
                <span>Photoshop • Illustrator • Motion Design</span>
              </div>
            </motion.div>
          </div>

          {/* Right Column: Premium Visual Showcase Area */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.25 }}
            className="lg:col-span-5 relative"
          >
            {/* Cinematic Container Box */}
            <div className="relative rounded-2xl p-2 sm:p-2.5 bg-gradient-to-b from-white/15 via-white/5 to-white/5 border border-white/15 backdrop-blur-xl shadow-2xl shadow-cyan-950/40 group">
              
              {/* Visual Preview Media */}
              <div className="relative rounded-xl overflow-hidden aspect-[4/3] bg-neutral-900">
                <img
                  src="https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?q=80&w=1200&auto=format&fit=crop"
                  alt="Tawhid Video Editing and Graphic Design Showcase"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 brightness-90 group-hover:brightness-100"
                  loading="eager"
                />

                {/* Dark Vignette Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#07080b] via-transparent to-black/40" />

                {/* Top Status Tags */}
                <div className="absolute top-3.5 left-3.5 right-3.5 flex items-center justify-between pointer-events-none">
                  <span className="px-2.5 py-1 rounded-md bg-black/60 backdrop-blur-md border border-white/10 text-[11px] font-mono text-cyan-300 font-medium">
                    REC [4K 60FPS]
                  </span>
                  <span className="px-2.5 py-1 rounded-md bg-cyan-500/20 backdrop-blur-md border border-cyan-400/40 text-[11px] font-mono text-white flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                    SHOWREEL 2026
                  </span>
                </div>

                {/* Center Play Button Overlay */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <button
                    id="hero-play-showreel-btn"
                    onClick={onOpenShowreel}
                    className="relative group/play flex items-center justify-center w-20 h-20 rounded-full bg-cyan-400 text-black shadow-2xl shadow-cyan-400/60 hover:bg-cyan-300 hover:scale-110 active:scale-95 transition-all duration-300 cursor-pointer"
                    aria-label="Play Tawhid's Cinematic Showreel"
                  >
                    <span className="absolute -inset-2 rounded-full border border-cyan-400/40 animate-ping opacity-60 pointer-events-none" />
                    <Play className="w-8 h-8 ml-1 fill-black text-black transition-transform group-hover/play:scale-110" />
                  </button>
                </div>

                {/* Bottom Media Card Info */}
                <div className="absolute bottom-3.5 left-3.5 right-3.5 p-3 rounded-lg bg-black/75 backdrop-blur-md border border-white/10 flex items-center justify-between">
                  <div>
                    <p className="text-xs font-display font-bold text-white">Cinematic Reel & Visuals</p>
                    <p className="text-[11px] text-neutral-400 font-mono">01:45 • Commercial & Social Media</p>
                  </div>
                  <button
                    onClick={onOpenShowreel}
                    className="text-xs font-mono text-cyan-300 hover:text-white underline flex items-center gap-1 cursor-pointer"
                  >
                    Watch Reel
                  </button>
                </div>
              </div>

              {/* Floating Badges */}
              <motion.div
                animate={{ y: [-4, 4, -4] }}
                transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                className="absolute -top-5 -left-5 hidden sm:flex items-center gap-2.5 px-4 py-2.5 rounded-xl bg-[#11131c]/95 border border-cyan-500/30 backdrop-blur-xl shadow-xl shadow-black/60"
              >
                <div className="w-8 h-8 rounded-lg bg-cyan-500/20 text-cyan-300 flex items-center justify-center">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div className="text-left">
                  <p className="text-xs font-bold text-white">Color Grading & VFX</p>
                  <p className="text-[10px] text-neutral-400 font-mono">DaVinci • After Effects</p>
                </div>
              </motion.div>

              <motion.div
                animate={{ y: [4, -4, 4] }}
                transition={{ duration: 4.5, repeat: Infinity, ease: 'easeInOut', delay: 0.5 }}
                className="absolute -bottom-5 -right-4 hidden sm:flex items-center gap-2.5 px-4 py-2.5 rounded-xl bg-[#11131c]/95 border border-white/10 backdrop-blur-xl shadow-xl shadow-black/60"
              >
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div className="text-left">
                  <p className="text-xs font-bold text-white">High CTR Impact</p>
                  <p className="text-[10px] text-neutral-400 font-mono">50+ Completed Works</p>
                </div>
              </motion.div>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};
