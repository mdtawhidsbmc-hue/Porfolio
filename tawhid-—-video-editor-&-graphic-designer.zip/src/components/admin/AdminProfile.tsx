import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Save, User, Mail, Phone, MapPin, Sparkles, Award, CheckCircle2, RotateCcw } from 'lucide-react';
import { usePortfolio } from '../../context/PortfolioContext';

interface AdminProfileProps {
  onShowToast: (msg: string) => void;
}

export const AdminProfile: React.FC<AdminProfileProps> = ({ onShowToast }) => {
  const { data, updatePersonal, updateStats } = usePortfolio();

  const [personalForm, setPersonalForm] = useState({
    name: data.personal.name,
    role: data.personal.role,
    tagline: data.personal.tagline,
    heroHeading: data.personal.heroHeading,
    heroSubtext: data.personal.heroSubtext,
    aboutHeading: data.personal.aboutHeading,
    aboutBio1: data.personal.aboutBio1,
    aboutBio2: data.personal.aboutBio2,
    location: data.personal.location,
    status: data.personal.status,
    email: data.personal.email,
    phone: data.personal.phone,
    whatsapp: data.personal.whatsapp,
    experienceYears: data.personal.experienceYears,
    heroBadge: data.personal.heroBadge || "4K CINEMATOGRAPHY • VIRAL EDITS • VISUAL IDENTITY",
    ctaHeading: data.personal.ctaHeading || "Ready To Create Visuals That Get Noticed?",
    ctaSubtext: data.personal.ctaSubtext || "Let's collaborate on your next YouTube video, brand commercial, social media campaign, or graphic design package.",
    aboutHighlights: data.personal.aboutHighlights || [
      {
        title: "Visual Storyteller",
        description: "Crafting narratives through pacing, rhythm, soundscapes, and color grading that evoke emotion and hold attention."
      },
      {
        title: "Conversion-Focused",
        description: "Designing graphic assets, thumbnails, and video hooks specifically tailored to optimize click-throughs and retention."
      },
      {
        title: "Fast & Reliable",
        description: "Consistent on-time project deliveries with transparent communication and rapid iterative polish."
      }
    ]
  });

  const [statsForm, setStatsForm] = useState(
    data.stats.map(s => ({ ...s }))
  );

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updatePersonal(personalForm);
    updateStats(statsForm);
    onShowToast('Profile & Hero details saved successfully!');
  };

  return (
    <form onSubmit={handleSave} className="space-y-8 max-w-4xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/5">
        <div>
          <h2 className="text-xl sm:text-2xl font-display font-bold text-white">
            Personal Profile & Hero Section
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 font-light mt-1">
            Update your name, title, contact details, hero presentation, bio, and experience numbers.
          </p>
        </div>

        <button
          type="submit"
          className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-cyan-500/25 transition-all cursor-pointer whitespace-nowrap self-start sm:self-auto"
        >
          <Save className="w-4 h-4" />
          <span>Save Changes</span>
        </button>
      </div>

      {/* 1. Core Identity */}
      <div className="p-6 rounded-2xl bg-[#0b0e17] border border-white/5 space-y-5">
        <h3 className="font-display font-bold text-base text-white flex items-center gap-2 border-b border-white/5 pb-3">
          <User className="w-4 h-4 text-cyan-400" />
          <span>General Identity</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              Your Name
            </label>
            <input
              type="text"
              value={personalForm.name}
              onChange={e => setPersonalForm({ ...personalForm, name: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              Professional Role / Title
            </label>
            <input
              type="text"
              value={personalForm.role}
              onChange={e => setPersonalForm({ ...personalForm, role: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              Tagline (Short Slogan)
            </label>
            <input
              type="text"
              value={personalForm.tagline}
              onChange={e => setPersonalForm({ ...personalForm, tagline: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all"
            />
          </div>

          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              Availability Status
            </label>
            <input
              type="text"
              value={personalForm.status}
              onChange={e => setPersonalForm({ ...personalForm, status: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all"
              placeholder="e.g. Available for New Projects"
            />
          </div>
        </div>
      </div>

      {/* 2. Contact Details */}
      <div className="p-6 rounded-2xl bg-[#0b0e17] border border-white/5 space-y-5">
        <h3 className="font-display font-bold text-base text-white flex items-center gap-2 border-b border-white/5 pb-3">
          <Mail className="w-4 h-4 text-cyan-400" />
          <span>Contact Channels & Location</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              Email Address
            </label>
            <input
              type="email"
              value={personalForm.email}
              onChange={e => setPersonalForm({ ...personalForm, email: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              WhatsApp Number (with country code)
            </label>
            <input
              type="text"
              value={personalForm.whatsapp}
              onChange={e => setPersonalForm({ ...personalForm, whatsapp: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all"
              placeholder="+8801700000000"
            />
          </div>

          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              Phone Number
            </label>
            <input
              type="text"
              value={personalForm.phone}
              onChange={e => setPersonalForm({ ...personalForm, phone: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all"
            />
          </div>

          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              Location
            </label>
            <input
              type="text"
              value={personalForm.location}
              onChange={e => setPersonalForm({ ...personalForm, location: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all"
            />
          </div>
        </div>
      </div>

      {/* 3. Hero & About Presentation */}
      <div className="p-6 rounded-2xl bg-[#0b0e17] border border-white/5 space-y-5">
        <h3 className="font-display font-bold text-base text-white flex items-center gap-2 border-b border-white/5 pb-3">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          <span>Hero & About Copy</span>
        </h3>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              Hero Top Badge Tagline
            </label>
            <input
              type="text"
              value={personalForm.heroBadge}
              onChange={e => setPersonalForm({ ...personalForm, heroBadge: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-cyan-300 font-mono outline-none transition-all"
              placeholder="e.g. 4K CINEMATOGRAPHY • VIRAL EDITS • VISUAL IDENTITY"
            />
          </div>

          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              Hero Big Headline
            </label>
            <textarea
              rows={2}
              value={personalForm.heroHeading}
              onChange={e => setPersonalForm({ ...personalForm, heroHeading: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all font-display"
            />
            <span className="text-[11px] font-mono text-neutral-500">
              Use newline if you want line breaks on the homepage.
            </span>
          </div>

          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              Hero Subtext / Introduction
            </label>
            <textarea
              rows={3}
              value={personalForm.heroSubtext}
              onChange={e => setPersonalForm({ ...personalForm, heroSubtext: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div>
              <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                About Section Heading
              </label>
              <input
                type="text"
                value={personalForm.aboutHeading}
                onChange={e => setPersonalForm({ ...personalForm, aboutHeading: e.target.value })}
                className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                Experience Years (e.g. 2+)
              </label>
              <input
                type="text"
                value={personalForm.experienceYears}
                onChange={e => setPersonalForm({ ...personalForm, experienceYears: e.target.value })}
                className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              About Bio Paragraph 1
            </label>
            <textarea
              rows={3}
              value={personalForm.aboutBio1}
              onChange={e => setPersonalForm({ ...personalForm, aboutBio1: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all"
            />
          </div>

          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              About Bio Paragraph 2
            </label>
            <textarea
              rows={3}
              value={personalForm.aboutBio2}
              onChange={e => setPersonalForm({ ...personalForm, aboutBio2: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all"
            />
          </div>

          {/* 3 Core Highlights */}
          <div className="pt-4 border-t border-white/5 space-y-3">
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400">
              About Section 3 Core Skill Highlights
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {(personalForm.aboutHighlights || []).map((hl, hIdx) => (
                <div key={hIdx} className="p-3.5 rounded-xl bg-[#07090e] border border-white/5 space-y-2">
                  <input
                    type="text"
                    value={hl.title}
                    onChange={e => {
                      const updated = [...(personalForm.aboutHighlights || [])];
                      updated[hIdx].title = e.target.value;
                      setPersonalForm({ ...personalForm, aboutHighlights: updated });
                    }}
                    placeholder={`Highlight #${hIdx + 1} Title`}
                    className="w-full bg-[#0b0e17] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white font-bold"
                  />
                  <textarea
                    rows={2}
                    value={hl.description}
                    onChange={e => {
                      const updated = [...(personalForm.aboutHighlights || [])];
                      updated[hIdx].description = e.target.value;
                      setPersonalForm({ ...personalForm, aboutHighlights: updated });
                    }}
                    placeholder="Short description..."
                    className="w-full bg-[#0b0e17] border border-white/10 rounded-lg px-2.5 py-1.5 text-[11px] text-neutral-300"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Closing CTA Banner Section */}
      <div className="p-6 rounded-2xl bg-[#0b0e17] border border-white/5 space-y-5">
        <h3 className="font-display font-bold text-base text-white flex items-center gap-2 border-b border-white/5 pb-3">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          <span>Bottom Closing CTA Banner</span>
        </h3>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              CTA Banner Headline
            </label>
            <input
              type="text"
              value={personalForm.ctaHeading}
              onChange={e => setPersonalForm({ ...personalForm, ctaHeading: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white font-display outline-none transition-all"
              placeholder="e.g. Ready To Create Visuals That Get Noticed?"
            />
          </div>

          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              CTA Banner Subtext
            </label>
            <textarea
              rows={2}
              value={personalForm.ctaSubtext}
              onChange={e => setPersonalForm({ ...personalForm, ctaSubtext: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all"
              placeholder="e.g. Let's collaborate on your next YouTube video, brand commercial..."
            />
          </div>
        </div>
      </div>

      {/* 4. Numerical Stats */}
      <div className="p-6 rounded-2xl bg-[#0b0e17] border border-white/5 space-y-5">
        <h3 className="font-display font-bold text-base text-white flex items-center gap-2 border-b border-white/5 pb-3">
          <Award className="w-4 h-4 text-cyan-400" />
          <span>Animated Stats Counters</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {statsForm.map((st, idx) => (
            <div key={idx} className="p-4 rounded-xl bg-[#07090e] border border-white/10 space-y-2">
              <label className="block text-xs font-mono text-cyan-400">
                {st.label}
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  value={st.value}
                  onChange={e => {
                    const val = parseInt(e.target.value) || 0;
                    const updated = [...statsForm];
                    updated[idx].value = val;
                    setStatsForm(updated);
                  }}
                  className="w-20 bg-[#0b0e17] border border-white/10 rounded-lg px-2.5 py-1.5 text-sm text-white font-bold"
                />
                <input
                  type="text"
                  value={st.suffix}
                  onChange={e => {
                    const updated = [...statsForm];
                    updated[idx].suffix = e.target.value;
                    setStatsForm(updated);
                  }}
                  className="w-12 bg-[#0b0e17] border border-white/10 rounded-lg px-2 py-1.5 text-sm text-cyan-300 font-bold"
                />
              </div>
              <input
                type="text"
                value={st.sublabel}
                onChange={e => {
                  const updated = [...statsForm];
                  updated[idx].sublabel = e.target.value;
                  setStatsForm(updated);
                }}
                className="w-full bg-[#0b0e17] border border-white/5 rounded-lg px-2 py-1 text-[11px] text-neutral-400"
                placeholder="Sublabel"
              />
            </div>
          ))}
        </div>
      </div>

      <div className="flex justify-end pt-4">
        <button
          type="submit"
          className="px-8 py-3.5 rounded-xl bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-xl shadow-cyan-500/25 transition-all cursor-pointer"
        >
          <Save className="w-4 h-4" />
          <span>Save All Changes</span>
        </button>
      </div>
    </form>
  );
};
