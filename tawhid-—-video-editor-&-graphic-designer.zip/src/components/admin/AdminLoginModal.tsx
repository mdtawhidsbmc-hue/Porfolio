import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, Lock, Key, ArrowRight, X, AlertCircle } from 'lucide-react';
import { usePortfolio } from '../../context/PortfolioContext';

interface AdminLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({
  isOpen,
  onClose,
  onSuccess
}) => {
  const { loginAdmin } = usePortfolio();
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pin.trim()) {
      setError('Please enter your admin PIN');
      return;
    }

    setIsVerifying(true);
    setError('');

    setTimeout(() => {
      const ok = loginAdmin(pin);
      setIsVerifying(false);
      if (ok) {
        setPin('');
        setError('');
        onSuccess();
      } else {
        setError('Incorrect PIN. (Default is: 1234)');
      }
    }, 400);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="relative w-full max-w-md bg-[#0e111a] border border-cyan-500/30 rounded-2xl p-6 sm:p-8 shadow-2xl shadow-cyan-950/40 text-white"
        >
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-neutral-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Header */}
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center text-black shadow-lg shadow-cyan-500/30">
              <Lock className="w-6 h-6 stroke-[2.5]" />
            </div>
            <div>
              <h3 className="font-display font-bold text-xl text-white">
                Admin Control Portal
              </h3>
              <p className="text-xs text-neutral-400 font-mono">
                Site Management & CMS
              </p>
            </div>
          </div>

          <p className="text-xs sm:text-sm text-neutral-300 font-light mb-6">
            Enter your security PIN to access the full site control dashboard, edit projects, change texts, and view client inquiries.
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                Security PIN Code
              </label>
              <div className="relative">
                <input
                  type="password"
                  value={pin}
                  onChange={(e) => {
                    setPin(e.target.value);
                    setError('');
                  }}
                  placeholder="Enter PIN (Default: 1234)"
                  autoFocus
                  className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-3.5 pl-11 text-base text-white tracking-widest outline-none transition-all placeholder:text-neutral-600 placeholder:tracking-normal"
                />
                <Key className="w-5 h-5 text-cyan-400/70 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
              <div className="flex items-center justify-between mt-2">
                <span className="text-[11px] font-mono text-cyan-400/80">
                  Default PIN: <strong>1234</strong>
                </span>
                <span className="text-[11px] font-mono text-neutral-500">
                  (You can change it in settings)
                </span>
              </div>
            </div>

            {error && (
              <motion.div
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-300 text-xs font-mono"
              >
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{error}</span>
              </motion.div>
            )}

            <button
              type="submit"
              disabled={isVerifying}
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/25 transition-all cursor-pointer disabled:opacity-50"
            >
              <span>{isVerifying ? 'Verifying...' : 'Unlock Dashboard'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-center gap-2 text-[11px] font-mono text-neutral-500">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Encrypted local session management</span>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
