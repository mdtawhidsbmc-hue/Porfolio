import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mail, 
  MailOpen, 
  Trash2, 
  MessageSquare, 
  Clock, 
  DollarSign, 
  Send, 
  Check, 
  Search, 
  Filter, 
  Archive,
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { InquiryMessage } from '../../types/portfolio';
import { usePortfolio } from '../../context/PortfolioContext';

interface AdminInquiriesProps {
  onShowToast: (msg: string) => void;
}

export const AdminInquiries: React.FC<AdminInquiriesProps> = ({ onShowToast }) => {
  const { inquiries, markInquiryRead, updateInquiryStatus, deleteInquiry } = usePortfolio();
  const [selectedInquiry, setSelectedInquiry] = useState<InquiryMessage | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredInquiries = inquiries.filter(inq => {
    const matchesStatus = filterStatus === 'all' || inq.status === filterStatus;
    const matchesSearch = inq.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inq.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inq.projectType.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inq.message.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const unreadCount = inquiries.filter(i => !i.read).length;

  const handleSelectInquiry = (inq: InquiryMessage) => {
    setSelectedInquiry(inq);
    if (!inq.read) {
      markInquiryRead(inq.id, true);
    }
  };

  const handleDelete = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (window.confirm('Are you sure you want to delete this inquiry?')) {
      deleteInquiry(id);
      if (selectedInquiry?.id === id) {
        setSelectedInquiry(null);
      }
      onShowToast('Inquiry removed from inbox.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/5">
        <div>
          <h2 className="text-xl sm:text-2xl font-display font-bold text-white flex items-center gap-2.5">
            <Mail className="w-5 h-5 text-cyan-400" />
            <span>Client Inquiries & Project Briefs</span>
            {unreadCount > 0 && (
              <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-cyan-500 text-black font-bold">
                {unreadCount} NEW
              </span>
            )}
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 font-light mt-1">
            Real-time messages sent by visitors through your contact and quote request form.
          </p>
        </div>

        <div className="text-xs font-mono text-neutral-400">
          Total Leads: <strong className="text-white">{inquiries.length}</strong>
        </div>
      </div>

      {/* Filter & Search */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 text-neutral-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search leads by name, email, brief..."
            className="w-full bg-[#0b0e17] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 pl-10 text-xs text-white outline-none"
          />
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          {['all', 'new', 'contacted', 'archived'].map(st => (
            <button
              key={st}
              onClick={() => setFilterStatus(st)}
              className={`px-3 py-1.5 rounded-lg uppercase tracking-wider transition-all cursor-pointer ${
                filterStatus === st
                  ? 'bg-cyan-500 text-black font-bold'
                  : 'bg-white/5 hover:bg-white/10 text-neutral-300'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Grid: List on Left, Detail on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left: Inquiries List */}
        <div className="lg:col-span-5 space-y-3">
          {filteredInquiries.length === 0 ? (
            <div className="p-8 text-center rounded-2xl bg-[#0b0e17] border border-white/5 text-xs font-mono text-neutral-500">
              No inquiries found in this filter.
            </div>
          ) : (
            filteredInquiries.map(inq => (
              <div
                key={inq.id}
                onClick={() => handleSelectInquiry(inq)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between gap-2 ${
                  selectedInquiry?.id === inq.id
                    ? 'bg-cyan-950/30 border-cyan-500/60 shadow-lg shadow-cyan-950/50'
                    : !inq.read
                      ? 'bg-[#0f1422] border-cyan-500/30 hover:border-cyan-400/50'
                      : 'bg-[#0b0e17] border-white/5 hover:border-white/15'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-white">
                      {inq.name}
                    </span>
                    {!inq.read && (
                      <span className="w-2 h-2 rounded-full bg-cyan-400" />
                    )}
                  </div>
                  <span className="text-[10px] font-mono text-neutral-500">
                    {inq.date}
                  </span>
                </div>

                <p className="text-xs text-neutral-300 font-light line-clamp-2">
                  {inq.message}
                </p>

                <div className="flex items-center justify-between pt-2 border-t border-white/5 text-[11px] font-mono">
                  <span className="text-cyan-300">
                    {inq.projectType}
                  </span>
                  <span className="text-emerald-400 font-medium">
                    {inq.budget}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Right: Selected Inquiry Detail View */}
        <div className="lg:col-span-7">
          {selectedInquiry ? (
            <div className="p-6 sm:p-8 rounded-2xl bg-[#0b0e17] border border-white/10 space-y-6">
              
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/5">
                <div>
                  <h3 className="font-display font-bold text-xl text-white">
                    {selectedInquiry.name}
                  </h3>
                  <a
                    href={`mailto:${selectedInquiry.email}`}
                    className="text-xs font-mono text-cyan-400 hover:underline flex items-center gap-1 mt-0.5"
                  >
                    <Mail className="w-3 h-3" />
                    <span>{selectedInquiry.email}</span>
                  </a>
                </div>

                <div className="flex items-center gap-2">
                  <select
                    value={selectedInquiry.status}
                    onChange={e => {
                      const newSt = e.target.value as any;
                      updateInquiryStatus(selectedInquiry.id, newSt);
                      setSelectedInquiry({ ...selectedInquiry, status: newSt });
                      onShowToast(`Status updated to ${newSt}`);
                    }}
                    className="bg-[#07090e] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono"
                  >
                    <option value="new">Status: New</option>
                    <option value="contacted">Status: Contacted</option>
                    <option value="archived">Status: Archived</option>
                  </select>

                  <button
                    onClick={() => handleDelete(selectedInquiry.id)}
                    className="p-2 rounded-lg bg-white/5 hover:bg-red-500/20 text-neutral-400 hover:text-red-400 transition-colors cursor-pointer"
                    title="Delete message"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Brief Metadata Chips */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs font-mono">
                <div className="p-3 rounded-xl bg-[#07090e] border border-white/5">
                  <span className="text-neutral-500 block mb-1 text-[10px] uppercase">Service Type</span>
                  <span className="text-cyan-300 font-bold">{selectedInquiry.projectType}</span>
                </div>
                <div className="p-3 rounded-xl bg-[#07090e] border border-white/5">
                  <span className="text-neutral-500 block mb-1 text-[10px] uppercase">Estimated Budget</span>
                  <span className="text-emerald-400 font-bold">{selectedInquiry.budget}</span>
                </div>
                <div className="p-3 rounded-xl bg-[#07090e] border border-white/5 col-span-2 sm:col-span-1">
                  <span className="text-neutral-500 block mb-1 text-[10px] uppercase">Timeline</span>
                  <span className="text-white font-bold">{selectedInquiry.timeline}</span>
                </div>
              </div>

              {/* Message Content */}
              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                  Project Description & Requirements:
                </label>
                <div className="p-5 rounded-xl bg-[#07090e] border border-white/5 text-sm text-neutral-200 font-light leading-relaxed whitespace-pre-wrap">
                  {selectedInquiry.message}
                </div>
              </div>

              {/* Quick Actions */}
              <div className="pt-4 border-t border-white/5 flex flex-wrap items-center gap-3">
                <a
                  href={`mailto:${selectedInquiry.email}?subject=Regarding%20Your%20Project%20Inquiry%20-%20Tawhid%20Creative&body=Hi%20${encodeURIComponent(selectedInquiry.name)},%0A%0AThank%20you%20for%20reaching%20out!%20I%20reviewed%20your%20brief%20for%20${encodeURIComponent(selectedInquiry.projectType)}...`}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-cyan-500/20"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Reply via Email</span>
                </a>

                <button
                  onClick={() => {
                    markInquiryRead(selectedInquiry.id, !selectedInquiry.read);
                    setSelectedInquiry({ ...selectedInquiry, read: !selectedInquiry.read });
                  }}
                  className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-300 text-xs font-mono flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  {selectedInquiry.read ? <Mail className="w-3.5 h-3.5" /> : <MailOpen className="w-3.5 h-3.5" />}
                  <span>{selectedInquiry.read ? 'Mark as Unread' : 'Mark as Read'}</span>
                </button>
              </div>

            </div>
          ) : (
            <div className="p-12 text-center rounded-2xl bg-[#0b0e17] border border-white/5 flex flex-col items-center justify-center min-h-[350px]">
              <Mail className="w-10 h-10 text-neutral-600 mb-3" />
              <p className="font-display font-bold text-base text-white mb-1">
                Select an inquiry to view details
              </p>
              <p className="text-xs text-neutral-400 font-light max-w-sm">
                Click on any message from the left list to read the full project brief and reply directly to the client.
              </p>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
