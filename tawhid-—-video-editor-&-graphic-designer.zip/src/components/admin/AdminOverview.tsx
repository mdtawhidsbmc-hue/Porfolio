import React from 'react';
import { 
  FolderGit2, 
  Layers, 
  MessageSquareQuote, 
  Mail, 
  Sparkles, 
  ExternalLink, 
  Plus, 
  UserCheck, 
  CheckCircle2, 
  TrendingUp,
  Sliders,
  ShieldCheck,
  Video,
  Building2,
  Workflow,
  Award,
  Share2
} from 'lucide-react';
import { usePortfolio } from '../../context/PortfolioContext';

interface AdminOverviewProps {
  onSelectTab: (tab: string) => void;
  onOpenNewProject: () => void;
  onViewSite: () => void;
}

export const AdminOverview: React.FC<AdminOverviewProps> = ({
  onSelectTab,
  onOpenNewProject,
  onViewSite
}) => {
  const { data, inquiries } = usePortfolio();
  const unreadInquiries = inquiries.filter(i => !i.read).length;

  return (
    <div className="space-y-8">
      {/* Welcome Banner */}
      <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#0f1422] via-[#0d121c] to-[#0a0d14] border border-cyan-500/20 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-mono uppercase tracking-wider mb-3">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Full Control Center</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-display font-extrabold text-white tracking-tight">
              Welcome Back, {data.personal.name}!
            </h2>
            <p className="text-sm text-neutral-300 font-light mt-1 max-w-xl">
              From this dashboard you can update your personal bio, add new video & design projects, manage services, edit testimonials, and view client inquiries.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={onOpenNewProject}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-cyan-500/20 transition-all cursor-pointer whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Project</span>
            </button>
            <button
              onClick={onViewSite}
              className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white font-mono text-xs uppercase tracking-wider flex items-center gap-2 transition-colors cursor-pointer whitespace-nowrap"
            >
              <span>Preview Live Site</span>
              <ExternalLink className="w-3.5 h-3.5 text-cyan-400" />
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        <div 
          onClick={() => onSelectTab('projects')}
          className="p-5 rounded-xl bg-[#0b0e17] border border-white/5 hover:border-cyan-500/30 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-mono text-neutral-400 uppercase tracking-wider">Portfolio Projects</span>
            <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 group-hover:scale-110 transition-transform">
              <FolderGit2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-display font-bold text-white mb-1">
            {data.projects.length}
          </div>
          <p className="text-[11px] font-mono text-neutral-500">
            {data.projects.filter(p => p.featured).length} featured projects
          </p>
        </div>

        <div 
          onClick={() => onSelectTab('inquiries')}
          className="p-5 rounded-xl bg-[#0b0e17] border border-white/5 hover:border-cyan-500/30 transition-all cursor-pointer group relative"
        >
          {unreadInquiries > 0 && (
            <span className="absolute top-3 right-3 px-2 py-0.5 rounded-full bg-cyan-500 text-black font-mono font-bold text-[10px] animate-pulse">
              {unreadInquiries} NEW
            </span>
          )}
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-mono text-neutral-400 uppercase tracking-wider">Client Inquiries</span>
            <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400 group-hover:scale-110 transition-transform">
              <Mail className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-display font-bold text-white mb-1">
            {inquiries.length}
          </div>
          <p className="text-[11px] font-mono text-neutral-500">
            {unreadInquiries} unread messages
          </p>
        </div>

        <div 
          onClick={() => onSelectTab('services')}
          className="p-5 rounded-xl bg-[#0b0e17] border border-white/5 hover:border-cyan-500/30 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-mono text-neutral-400 uppercase tracking-wider">Active Services</span>
            <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400 group-hover:scale-110 transition-transform">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-display font-bold text-white mb-1">
            {data.services.length}
          </div>
          <p className="text-[11px] font-mono text-neutral-500">
            Video, Design & Branding
          </p>
        </div>

        <div 
          onClick={() => onSelectTab('testimonials')}
          className="p-5 rounded-xl bg-[#0b0e17] border border-white/5 hover:border-cyan-500/30 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-mono text-neutral-400 uppercase tracking-wider">Client Reviews</span>
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 group-hover:scale-110 transition-transform">
              <MessageSquareQuote className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-display font-bold text-white mb-1">
            {data.testimonials.length}
          </div>
          <p className="text-[11px] font-mono text-neutral-500">
            100% 5-Star feedback
          </p>
        </div>
      </div>

      {/* Quick Website Sections & Content Editor Cards */}
      <div className="p-5 rounded-2xl bg-[#0b0e17] border border-white/5 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-white/5">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <h3 className="font-display font-bold text-sm text-white uppercase tracking-wider">
              Entire Website Content Control
            </h3>
          </div>
          <span className="text-[11px] font-mono text-neutral-500">
            Click any section below to customize
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <button
            onClick={() => onSelectTab('brands')}
            className="p-3.5 rounded-xl bg-[#07090e] border border-white/5 hover:border-cyan-500/40 text-left transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between mb-2">
              <Building2 className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition-transform" />
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-white/5 text-neutral-400">
                {data.brands?.length || 0} Brands
              </span>
            </div>
            <div className="font-bold text-xs text-white group-hover:text-cyan-300 transition-colors">
              Brand Wall
            </div>
            <div className="text-[10px] text-neutral-500 truncate">
              Clients & creator logos
            </div>
          </button>

          <button
            onClick={() => onSelectTab('process')}
            className="p-3.5 rounded-xl bg-[#07090e] border border-white/5 hover:border-cyan-500/40 text-left transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between mb-2">
              <Workflow className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition-transform" />
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-white/5 text-neutral-400">
                {data.process?.length || 0} Phases
              </span>
            </div>
            <div className="font-bold text-xs text-white group-hover:text-cyan-300 transition-colors">
              Workflow Process
            </div>
            <div className="text-[10px] text-neutral-500 truncate">
              Step-by-step methodology
            </div>
          </button>

          <button
            onClick={() => onSelectTab('whyme')}
            className="p-3.5 rounded-xl bg-[#07090e] border border-white/5 hover:border-cyan-500/40 text-left transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between mb-2">
              <Award className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition-transform" />
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-white/5 text-neutral-400">
                {data.whyMe?.length || 0} Pillars
              </span>
            </div>
            <div className="font-bold text-xs text-white group-hover:text-cyan-300 transition-colors">
              Why Choose Me
            </div>
            <div className="text-[10px] text-neutral-500 truncate">
              Core value differentiators
            </div>
          </button>

          <button
            onClick={() => onSelectTab('socials')}
            className="p-3.5 rounded-xl bg-[#07090e] border border-white/5 hover:border-cyan-500/40 text-left transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between mb-2">
              <Share2 className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition-transform" />
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-white/5 text-neutral-400">
                {data.socials?.length || 0} Channels
              </span>
            </div>
            <div className="font-bold text-xs text-white group-hover:text-cyan-300 transition-colors">
              Social Links
            </div>
            <div className="text-[10px] text-neutral-500 truncate">
              YouTube, IG, Behance, etc.
            </div>
          </button>
        </div>
      </div>

      {/* Two-column layout: Current Profile Card + Recent Inquiries */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Profile status */}
        <div className="lg:col-span-5 p-6 rounded-2xl bg-[#0b0e17] border border-white/5 space-y-5">
          <div className="flex items-center justify-between pb-4 border-b border-white/5">
            <h3 className="font-display font-bold text-base text-white flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-cyan-400" />
              <span>Active Site Identity</span>
            </h3>
            <button
              onClick={() => onSelectTab('profile')}
              className="text-xs font-mono text-cyan-400 hover:text-cyan-300 transition-colors cursor-pointer"
            >
              Edit Profile →
            </button>
          </div>

          <div className="space-y-3 text-xs font-mono">
            <div className="flex justify-between py-1.5 border-b border-white/[0.03]">
              <span className="text-neutral-500">Name:</span>
              <span className="text-white font-medium">{data.personal.name}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-white/[0.03]">
              <span className="text-neutral-500">Designation:</span>
              <span className="text-cyan-300">{data.personal.role}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-white/[0.03]">
              <span className="text-neutral-500">Availability:</span>
              <span className="text-emerald-400 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                {data.personal.status}
              </span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-white/[0.03]">
              <span className="text-neutral-500">Location:</span>
              <span className="text-neutral-300">{data.personal.location}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-white/[0.03]">
              <span className="text-neutral-500">Contact Email:</span>
              <span className="text-neutral-300">{data.personal.email}</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-neutral-500">WhatsApp:</span>
              <span className="text-neutral-300">{data.personal.whatsapp}</span>
            </div>
          </div>

          <div className="pt-2">
            <button
              onClick={() => onSelectTab('showreel')}
              className="w-full py-2.5 px-4 rounded-xl bg-white/[0.03] hover:bg-white/[0.06] border border-white/5 text-xs font-mono text-neutral-300 hover:text-white flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <Video className="w-3.5 h-3.5 text-cyan-400" />
              <span>Configure Showreel & Grading Slider</span>
            </button>
          </div>
        </div>

        {/* Recent Client Messages */}
        <div className="lg:col-span-7 p-6 rounded-2xl bg-[#0b0e17] border border-white/5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-white/5">
            <h3 className="font-display font-bold text-base text-white flex items-center gap-2">
              <Mail className="w-4 h-4 text-cyan-400" />
              <span>Latest Inquiries</span>
            </h3>
            <button
              onClick={() => onSelectTab('inquiries')}
              className="text-xs font-mono text-cyan-400 hover:text-cyan-300 transition-colors cursor-pointer"
            >
              View All ({inquiries.length}) →
            </button>
          </div>

          {inquiries.length === 0 ? (
            <div className="py-8 text-center text-xs font-mono text-neutral-500">
              No inquiries received yet. When visitors fill out the contact form, they will appear here!
            </div>
          ) : (
            <div className="space-y-3">
              {inquiries.slice(0, 3).map((inq) => (
                <div
                  key={inq.id}
                  onClick={() => onSelectTab('inquiries')}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                    !inq.read 
                      ? 'bg-cyan-500/[0.04] border-cyan-500/30' 
                      : 'bg-white/[0.02] border-white/5 hover:border-white/10'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs text-white">{inq.name}</span>
                      {!inq.read && (
                        <span className="w-2 h-2 rounded-full bg-cyan-400" />
                      )}
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/5 text-neutral-400">
                        {inq.projectType}
                      </span>
                    </div>
                    <span className="text-[10px] font-mono text-neutral-500">{inq.date}</span>
                  </div>
                  <p className="text-xs text-neutral-300 font-light line-clamp-1">
                    {inq.message}
                  </p>
                </div>
              ))}
            </div>
          )}

          <div className="p-3 rounded-xl bg-cyan-500/5 border border-cyan-500/10 flex items-center gap-3 text-xs text-cyan-300/90 font-mono">
            <CheckCircle2 className="w-4 h-4 text-cyan-400 flex-shrink-0" />
            <span>Automatic Instant Sync: Any edits made in this dashboard apply to the live portfolio instantly.</span>
          </div>
        </div>

      </div>
    </div>
  );
};
