import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Save, Plus, Trash2, Edit2, Sparkles, Building2, Check, X, Tag } from 'lucide-react';
import { usePortfolio } from '../../context/PortfolioContext';
import { BrandClient } from '../../types/portfolio';

interface AdminBrandsProps {
  onShowToast: (msg: string) => void;
}

export const AdminBrands: React.FC<AdminBrandsProps> = ({ onShowToast }) => {
  const { data, updateBrands } = usePortfolio();
  const [brands, setBrands] = useState<BrandClient[]>(() => 
    data.brands ? data.brands.map(b => ({ ...b })) : []
  );

  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState({
    name: '',
    tagline: ''
  });

  const handleOpenAdd = () => {
    setEditingId('new');
    setForm({ name: '', tagline: '' });
  };

  const handleOpenEdit = (brand: BrandClient) => {
    setEditingId(brand.id);
    setForm({ name: brand.name, tagline: brand.tagline });
  };

  const handleCancel = () => {
    setEditingId(null);
    setForm({ name: '', tagline: '' });
  };

  const handleSaveItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) return;

    let updated: BrandClient[];
    if (editingId === 'new') {
      const newBrand: BrandClient = {
        id: `brand-${Date.now()}`,
        name: form.name.trim(),
        tagline: form.tagline.trim() || 'Client Partner'
      };
      updated = [...brands, newBrand];
    } else {
      updated = brands.map(b => 
        b.id === editingId ? { ...b, name: form.name.trim(), tagline: form.tagline.trim() } : b
      );
    }

    setBrands(updated);
    updateBrands(updated);
    setEditingId(null);
    onShowToast('Brand Wall updated successfully!');
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Remove this client/brand from the Brand Wall strip?')) {
      const updated = brands.filter(b => b.id !== id);
      setBrands(updated);
      updateBrands(updated);
      onShowToast('Brand removed.');
    }
  };

  return (
    <div className="space-y-8 max-w-4xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/5">
        <div>
          <h2 className="text-xl sm:text-2xl font-display font-bold text-white flex items-center gap-2">
            <Building2 className="w-6 h-6 text-cyan-400" />
            <span>Brand Wall & Trusted Clients</span>
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 font-light mt-1">
            Manage the client logos, creators, and brand names shown in the trust ticker under the hero section.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-cyan-500/25 transition-all cursor-pointer whitespace-nowrap self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Client / Brand</span>
        </button>
      </div>

      {/* Inline Form Modal/Card */}
      <AnimatePresence>
        {editingId && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="p-6 rounded-2xl bg-[#0e111a] border border-cyan-500/30 shadow-2xl shadow-cyan-950/40"
          >
            <h3 className="font-display font-bold text-white text-base mb-4 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>{editingId === 'new' ? 'Add New Client / Brand' : 'Edit Client / Brand'}</span>
            </h3>

            <form onSubmit={handleSaveItem} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                    Brand / Channel Name *
                  </label>
                  <input
                    type="text"
                    value={form.name}
                    onChange={e => setForm({ ...form, name: e.target.value })}
                    placeholder="e.g. Apex Media, RedBull Gaming, Aura Studios"
                    className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                    Category / Niche Tagline
                  </label>
                  <input
                    type="text"
                    value={form.tagline}
                    onChange={e => setForm({ ...form, tagline: e.target.value })}
                    placeholder="e.g. Creative Studio, Tech Ventures, 1M+ Creators"
                    className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleCancel}
                  className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-300 text-xs font-mono transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Brand</span>
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Brands List */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {brands.map((b, idx) => (
          <div
            key={b.id}
            className="p-5 rounded-2xl bg-[#0b0e17] border border-white/5 hover:border-cyan-500/30 transition-all flex items-center justify-between group"
          >
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 rounded-full bg-cyan-400/50 group-hover:bg-cyan-400 transition-colors" />
              <div>
                <h4 className="font-display font-bold text-white text-base">
                  {b.name}
                </h4>
                <p className="text-xs font-mono text-neutral-400">
                  [{b.tagline}]
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 opacity-80 group-hover:opacity-100 transition-opacity">
              <button
                onClick={() => handleOpenEdit(b)}
                className="p-2 rounded-lg bg-white/5 hover:bg-cyan-500/20 text-neutral-400 hover:text-cyan-300 transition-colors cursor-pointer"
                title="Edit Brand"
              >
                <Edit2 className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => handleDelete(b.id)}
                className="p-2 rounded-lg bg-white/5 hover:bg-red-500/20 text-neutral-400 hover:text-red-400 transition-colors cursor-pointer"
                title="Delete Brand"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {brands.length === 0 && (
        <div className="p-8 text-center rounded-2xl bg-[#0b0e17] border border-dashed border-white/10 text-neutral-500 font-mono text-xs">
          No brands configured yet. Click "Add Client / Brand" to showcase creator studios you have worked with.
        </div>
      )}
    </div>
  );
};
