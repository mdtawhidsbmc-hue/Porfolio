import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Save, 
  Plus, 
  Trash2, 
  Edit2, 
  Award, 
  Lightbulb, 
  Target, 
  TrendingUp, 
  HeartHandshake, 
  Zap, 
  ShieldCheck, 
  Sparkles,
  Check,
  X
} from 'lucide-react';
import { usePortfolio } from '../../context/PortfolioContext';
import { WhyMePillar } from '../../types/portfolio';

interface AdminWhyMeProps {
  onShowToast: (msg: string) => void;
}

const AVAILABLE_ICONS = [
  { name: 'Lightbulb', label: 'Idea / Innovation', icon: Lightbulb },
  { name: 'Target', label: 'Precision / Focus', icon: Target },
  { name: 'TrendingUp', label: 'Growth / Analytics', icon: TrendingUp },
  { name: 'HeartHandshake', label: 'Partnership / Trust', icon: HeartHandshake },
  { name: 'Zap', label: 'Speed / Energy', icon: Zap },
  { name: 'ShieldCheck', label: 'Reliability / Quality', icon: ShieldCheck },
  { name: 'Sparkles', label: 'Creativity / Magic', icon: Sparkles },
  { name: 'Award', label: 'Excellence', icon: Award }
];

export const AdminWhyMe: React.FC<AdminWhyMeProps> = ({ onShowToast }) => {
  const { data, updateWhyMe } = usePortfolio();
  const [pillars, setPillars] = useState<WhyMePillar[]>(() =>
    data.whyMe ? data.whyMe.map(p => ({ ...p })) : []
  );

  const [editingIndex, setEditingIndex] = useState<number | 'new' | null>(null);
  const [form, setForm] = useState<WhyMePillar>({
    title: '',
    description: '',
    iconName: 'Lightbulb'
  });

  const handleOpenAdd = () => {
    setEditingIndex('new');
    setForm({
      title: '',
      description: '',
      iconName: 'Lightbulb'
    });
  };

  const handleOpenEdit = (index: number) => {
    setEditingIndex(index);
    setForm({
      title: pillars[index].title,
      description: pillars[index].description,
      iconName: pillars[index].iconName || 'Lightbulb'
    });
  };

  const handleSavePillar = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim()) return;

    let updated: WhyMePillar[];
    if (editingIndex === 'new') {
      updated = [...pillars, form];
    } else if (typeof editingIndex === 'number') {
      updated = pillars.map((p, i) => (i === editingIndex ? form : p));
    } else {
      return;
    }

    setPillars(updated);
    updateWhyMe(updated);
    setEditingIndex(null);
    onShowToast('Why Work With Me pillars updated successfully!');
  };

  const handleDeletePillar = (index: number) => {
    if (window.confirm('Remove this reason pillar from Why Work With Me?')) {
      const updated = pillars.filter((_, i) => i !== index);
      setPillars(updated);
      updateWhyMe(updated);
      onShowToast('Pillar removed.');
    }
  };

  const renderIcon = (iconName: string) => {
    switch (iconName) {
      case 'Lightbulb': return <Lightbulb className="w-5 h-5 text-cyan-400" />;
      case 'Target': return <Target className="w-5 h-5 text-cyan-400" />;
      case 'TrendingUp': return <TrendingUp className="w-5 h-5 text-cyan-400" />;
      case 'HeartHandshake': return <HeartHandshake className="w-5 h-5 text-cyan-400" />;
      case 'Zap': return <Zap className="w-5 h-5 text-cyan-400" />;
      case 'ShieldCheck': return <ShieldCheck className="w-5 h-5 text-cyan-400" />;
      case 'Award': return <Award className="w-5 h-5 text-cyan-400" />;
      default: return <Sparkles className="w-5 h-5 text-cyan-400" />;
    }
  };

  return (
    <div className="space-y-8 max-w-4xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/5">
        <div>
          <h2 className="text-xl sm:text-2xl font-display font-bold text-white flex items-center gap-2">
            <Award className="w-6 h-6 text-cyan-400" />
            <span>Why Work With Me (Core Value Pillars)</span>
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 font-light mt-1">
            Highlight the key differentiators that convince clients to hire you over other editors and designers.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-cyan-500/25 transition-all cursor-pointer whitespace-nowrap self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Value Pillar</span>
        </button>
      </div>

      {/* Editor Modal/Card */}
      <AnimatePresence>
        {editingIndex !== null && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="p-6 rounded-2xl bg-[#0e111a] border border-cyan-500/30 shadow-2xl shadow-cyan-950/40"
          >
            <h3 className="font-display font-bold text-white text-base mb-4 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>{editingIndex === 'new' ? 'Add New Value Pillar' : 'Edit Pillar'}</span>
            </h3>

            <form onSubmit={handleSavePillar} className="space-y-4">
              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                  Select Visual Icon
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {AVAILABLE_ICONS.map(ic => {
                    const IconComp = ic.icon;
                    const isSelected = form.iconName === ic.name;
                    return (
                      <button
                        type="button"
                        key={ic.name}
                        onClick={() => setForm({ ...form, iconName: ic.name })}
                        className={`p-3 rounded-xl border flex items-center gap-2.5 text-xs font-mono transition-all cursor-pointer ${
                          isSelected 
                            ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200 shadow-md shadow-cyan-500/20' 
                            : 'bg-[#07090e] border-white/10 text-neutral-400 hover:text-white hover:border-white/20'
                        }`}
                      >
                        <IconComp className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                        <span className="truncate">{ic.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                  Pillar Title *
                </label>
                <input
                  type="text"
                  value={form.title}
                  onChange={e => setForm({ ...form, title: e.target.value })}
                  placeholder="e.g. Creative Thinking, Frame Precision, High-Retention Pacing"
                  className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                  Pillar Description
                </label>
                <textarea
                  rows={3}
                  value={form.description}
                  onChange={e => setForm({ ...form, description: e.target.value })}
                  placeholder="Explain why this benefits the client..."
                  className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all leading-relaxed"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/5">
                <button
                  type="button"
                  onClick={() => setEditingIndex(null)}
                  className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-300 text-xs font-mono transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Pillar</span>
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Pillars List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {pillars.map((pillar, idx) => (
          <div
            key={idx}
            className="p-6 rounded-2xl bg-[#0b0e17] border border-white/5 hover:border-cyan-500/30 transition-all flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center">
                  {renderIcon(pillar.iconName)}
                </div>
                <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={() => handleOpenEdit(idx)}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-cyan-500/20 text-neutral-400 hover:text-cyan-300 transition-colors cursor-pointer"
                    title="Edit Pillar"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleDeletePillar(idx)}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-red-500/20 text-neutral-400 hover:text-red-400 transition-colors cursor-pointer"
                    title="Delete Pillar"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <h4 className="font-display font-bold text-white text-lg mb-2">
                {pillar.title}
              </h4>
              <p className="text-xs text-neutral-300 font-light leading-relaxed">
                {pillar.description}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
