import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Download, 
  Upload, 
  Key, 
  RotateCcw, 
  Copy, 
  Check, 
  ShieldCheck, 
  FileCode, 
  AlertTriangle,
  HardDrive
} from 'lucide-react';
import { usePortfolio } from '../../context/PortfolioContext';

interface AdminSettingsProps {
  onShowToast: (msg: string) => void;
}

export const AdminSettings: React.FC<AdminSettingsProps> = ({ onShowToast }) => {
  const { 
    data, 
    exportJSON, 
    importJSON, 
    resetToDefaults, 
    adminPin, 
    updateAdminPin 
  } = usePortfolio();

  const [copiedCode, setCopiedCode] = useState(false);
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [pinError, setPinError] = useState('');
  const [importJsonText, setImportJsonText] = useState('');

  const handleDownloadJSON = () => {
    const jsonString = exportJSON();
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `tawhid-portfolio-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    onShowToast('Portfolio JSON backup downloaded successfully!');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const success = importJSON(content);
        if (success) {
          onShowToast('Portfolio successfully restored from backup file!');
        } else {
          onShowToast('Failed to import backup: Invalid JSON schema.');
        }
      }
    };
    reader.readAsText(file);
  };

  const handleImportText = () => {
    if (!importJsonText.trim()) return;
    const ok = importJSON(importJsonText);
    if (ok) {
      setImportJsonText('');
      onShowToast('Backup JSON imported successfully!');
    } else {
      onShowToast('Import error: Please check that JSON format is valid.');
    }
  };

  const handleCopyTSCode = () => {
    const code = `import { PortfolioConfig } from '../types/portfolio';\n\nexport const portfolioData: PortfolioConfig = ${JSON.stringify(data, null, 2)};\n`;
    navigator.clipboard.writeText(code);
    setCopiedCode(true);
    onShowToast('Copied TypeScript code to clipboard! You can paste into src/data/portfolioData.ts');
    setTimeout(() => setCopiedCode(false), 3000);
  };

  const handleChangePin = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPin.length < 4) {
      setPinError('PIN must be at least 4 digits');
      return;
    }
    if (newPin !== confirmPin) {
      setPinError('PINs do not match');
      return;
    }
    updateAdminPin(newPin);
    setNewPin('');
    setConfirmPin('');
    setPinError('');
    onShowToast('Admin PIN updated successfully!');
  };

  const handleReset = () => {
    if (window.confirm('Are you sure you want to reset all portfolio data to factory defaults? All custom changes will be reverted.')) {
      resetToDefaults();
      onShowToast('All data reset to original defaults.');
    }
  };

  return (
    <div className="space-y-8 max-w-4xl">
      <div className="pb-4 border-b border-white/5">
        <h2 className="text-xl sm:text-2xl font-display font-bold text-white flex items-center gap-2.5">
          <HardDrive className="w-5 h-5 text-cyan-400" />
          <span>Data Backup, Export & Security</span>
        </h2>
        <p className="text-xs sm:text-sm text-neutral-400 font-light mt-1">
          Export your portfolio database, restore backups, generate code for deployment, and manage security credentials.
        </p>
      </div>

      {/* 1. Export & Download Backup */}
      <div className="p-6 rounded-2xl bg-[#0b0e17] border border-white/5 space-y-4">
        <h3 className="font-display font-bold text-base text-white flex items-center gap-2">
          <Download className="w-4 h-4 text-cyan-400" />
          <span>Export & Download Database</span>
        </h3>
        <p className="text-xs text-neutral-300 font-light leading-relaxed">
          Save an offline copy of all your projects, custom text, services, and testimonials as a standardized JSON file.
        </p>

        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            onClick={handleDownloadJSON}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-cyan-500/20 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Download JSON Backup</span>
          </button>

          <button
            onClick={handleCopyTSCode}
            className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-white border border-white/10 text-xs font-mono flex items-center gap-2 transition-colors cursor-pointer"
          >
            {copiedCode ? <Check className="w-4 h-4 text-emerald-400" /> : <FileCode className="w-4 h-4 text-cyan-400" />}
            <span>{copiedCode ? 'Code Copied!' : 'Copy Code for portfolioData.ts'}</span>
          </button>
        </div>
      </div>

      {/* 2. Restore / Import Backup */}
      <div className="p-6 rounded-2xl bg-[#0b0e17] border border-white/5 space-y-4">
        <h3 className="font-display font-bold text-base text-white flex items-center gap-2">
          <Upload className="w-4 h-4 text-cyan-400" />
          <span>Restore Portfolio from Backup</span>
        </h3>
        <p className="text-xs text-neutral-300 font-light leading-relaxed">
          Upload a previously exported JSON backup file or paste its contents below to immediately restore all your configurations.
        </p>

        <div className="pt-2 space-y-3">
          <label className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-cyan-300 cursor-pointer transition-colors">
            <Upload className="w-4 h-4" />
            <span>Upload .JSON File</span>
            <input
              type="file"
              accept=".json"
              onChange={handleFileUpload}
              className="hidden"
            />
          </label>

          <div>
            <textarea
              rows={3}
              value={importJsonText}
              onChange={e => setImportJsonText(e.target.value)}
              placeholder="Or paste backup JSON code directly here..."
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl p-3 text-xs font-mono text-white outline-none"
            />
            {importJsonText && (
              <button
                onClick={handleImportText}
                className="mt-2 px-4 py-2 rounded-xl bg-cyan-500 text-black font-bold text-xs font-mono uppercase cursor-pointer"
              >
                Apply Pasted JSON
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 3. Security Credentials (PIN) */}
      <div className="p-6 rounded-2xl bg-[#0b0e17] border border-white/5 space-y-4">
        <h3 className="font-display font-bold text-base text-white flex items-center gap-2">
          <Key className="w-4 h-4 text-cyan-400" />
          <span>Admin Security PIN</span>
        </h3>
        <p className="text-xs text-neutral-300 font-light">
          Current Security PIN is active: <strong className="text-cyan-300 font-mono">"{adminPin}"</strong>. You can change it below to protect your dashboard from unauthorized edits.
        </p>

        <form onSubmit={handleChangePin} className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          <input
            type="password"
            value={newPin}
            onChange={e => setNewPin(e.target.value)}
            placeholder="New 4-digit PIN"
            className="bg-[#07090e] border border-white/10 rounded-xl px-4 py-2 text-xs text-white"
          />
          <input
            type="password"
            value={confirmPin}
            onChange={e => setConfirmPin(e.target.value)}
            placeholder="Confirm New PIN"
            className="bg-[#07090e] border border-white/10 rounded-xl px-4 py-2 text-xs text-white"
          />
          <button
            type="submit"
            className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white text-xs font-mono uppercase cursor-pointer"
          >
            Update PIN
          </button>
        </form>
        {pinError && (
          <p className="text-xs text-red-400 font-mono">{pinError}</p>
        )}
      </div>

      {/* 4. Danger Zone: Factory Reset */}
      <div className="p-6 rounded-2xl bg-red-950/20 border border-red-500/20 space-y-4">
        <h3 className="font-display font-bold text-base text-red-300 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-red-400" />
          <span>Reset to Factory Defaults</span>
        </h3>
        <p className="text-xs text-neutral-400 font-light">
          If you ever want to discard all changes and restore the website to its original built-in state, click the button below.
        </p>

        <div>
          <button
            onClick={handleReset}
            className="px-4 py-2.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-300 text-xs font-mono uppercase tracking-wider flex items-center gap-2 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset All Content to Default</span>
          </button>
        </div>
      </div>
    </div>
  );
};
