import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Search, 
  Filter, 
  Edit3, 
  Trash2, 
  Star, 
  ExternalLink, 
  FolderGit2, 
  Check, 
  AlertTriangle,
  Play
} from 'lucide-react';
import { Project, ProjectCategory } from '../../types/portfolio';
import { usePortfolio } from '../../context/PortfolioContext';
import { AdminProjectModal } from './AdminProjectModal';

interface AdminProjectsProps {
  onShowToast: (msg: string) => void;
  openNewModalInitially?: boolean;
}

export const AdminProjects: React.FC<AdminProjectsProps> = ({
  onShowToast,
  openNewModalInitially = false
}) => {
  const { data, addProject, editProject, deleteProject } = usePortfolio();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [isModalOpen, setIsModalOpen] = useState(openNewModalInitially);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const categories = [
    'All',
    'Video Editing',
    'Graphic Design',
    'Social Media',
    'Branding',
    'Motion Graphics',
    'Thumbnail Design'
  ];

  const filteredProjects = data.projects.filter(project => {
    const matchesCategory = selectedCategory === 'All' || project.category === selectedCategory;
    const matchesSearch = project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.shortDescription.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (project.client && project.client.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const handleSaveProject = (project: Project) => {
    const exists = data.projects.some(p => p.id === project.id);
    if (exists) {
      editProject(project.id, project);
      onShowToast(`Updated "${project.title}" successfully!`);
    } else {
      addProject(project);
      onShowToast(`Added new project "${project.title}"!`);
    }
    setIsModalOpen(false);
    setEditingProject(null);
  };

  const handleToggleFeatured = (project: Project) => {
    const newVal = !project.featured;
    editProject(project.id, { featured: newVal });
    onShowToast(`Project "${project.title}" is now ${newVal ? 'Featured ★' : 'Standard'}`);
  };

  const handleDelete = (id: string) => {
    const p = data.projects.find(x => x.id === id);
    deleteProject(id);
    setDeleteConfirmId(null);
    onShowToast(`Deleted project "${p?.title || ''}"`);
  };

  return (
    <div className="space-y-6">
      {/* Top action bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/5">
        <div>
          <h2 className="text-xl sm:text-2xl font-display font-bold text-white flex items-center gap-2.5">
            <FolderGit2 className="w-5 h-5 text-cyan-400" />
            <span>Manage Portfolio Projects</span>
            <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
              {data.projects.length} Total
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 font-light mt-1">
            Add new video cuts or graphic artworks, update thumbnails, case study details, and reorder.
          </p>
        </div>

        <button
          onClick={() => {
            setEditingProject(null);
            setIsModalOpen(true);
          }}
          className="px-5 py-3 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-cyan-500/25 transition-all cursor-pointer whitespace-nowrap self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Project</span>
        </button>
      </div>

      {/* Search & Category Filter Toolbar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-neutral-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search projects by title, client, keyword..."
            className="w-full bg-[#0b0e17] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 pl-10 text-xs text-white outline-none"
          />
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full text-xs font-mono scrollbar-none">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-cyan-500 text-black font-bold'
                  : 'bg-white/5 hover:bg-white/10 text-neutral-300'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Projects Table / Grid */}
      {filteredProjects.length === 0 ? (
        <div className="p-12 text-center rounded-2xl bg-[#0b0e17] border border-white/5 space-y-3">
          <FolderGit2 className="w-8 h-8 text-neutral-600 mx-auto" />
          <p className="text-sm text-neutral-400 font-mono">No projects found matching your filter.</p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('All');
            }}
            className="text-xs font-mono text-cyan-400 underline cursor-pointer"
          >
            Clear filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredProjects.map(project => (
            <div
              key={project.id}
              className="rounded-2xl bg-[#0b0e17] border border-white/5 hover:border-cyan-500/30 transition-all flex flex-col overflow-hidden group relative"
            >
              {/* Thumbnail Container */}
              <div className="relative aspect-video w-full bg-neutral-900 overflow-hidden">
                <img
                  src={project.thumbnail}
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />

                {/* Badges on thumbnail */}
                <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                  <span className="px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-md text-[10px] font-mono text-cyan-300 border border-white/10">
                    {project.category}
                  </span>
                  {project.featured && (
                    <span className="px-2 py-0.5 rounded-md bg-amber-500/90 text-black text-[10px] font-mono font-bold flex items-center gap-1 shadow">
                      <Star className="w-2.5 h-2.5 fill-black" />
                      <span>FEATURED</span>
                    </span>
                  )}
                </div>

                {/* Quick Video Indicator */}
                {project.videoUrl && (
                  <div className="absolute bottom-2.5 left-2.5 px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-md text-[10px] font-mono text-white flex items-center gap-1">
                    <Play className="w-2.5 h-2.5 fill-white text-white" />
                    <span>Video Clip</span>
                  </div>
                )}

                {/* Quick action overlay */}
                <div className="absolute top-2.5 right-2.5 flex items-center gap-1">
                  <button
                    onClick={() => handleToggleFeatured(project)}
                    title={project.featured ? 'Unmark Featured' : 'Mark as Featured'}
                    className={`p-1.5 rounded-lg backdrop-blur-md transition-colors cursor-pointer ${
                      project.featured 
                        ? 'bg-amber-400 text-black' 
                        : 'bg-black/60 hover:bg-black/80 text-white/80 hover:text-white'
                    }`}
                  >
                    <Star className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Content Body */}
              <div className="p-4 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <h4 className="font-display font-bold text-sm text-white line-clamp-1">
                      {project.title}
                    </h4>
                  </div>
                  <p className="text-xs text-neutral-400 font-light line-clamp-2 mb-3">
                    {project.shortDescription}
                  </p>

                  <div className="flex flex-wrap gap-1 mb-4">
                    {project.toolsUsed.slice(0, 3).map((t, i) => (
                      <span key={i} className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/[0.03] text-neutral-400 border border-white/5">
                        {t}
                      </span>
                    ))}
                    {project.toolsUsed.length > 3 && (
                      <span className="text-[10px] font-mono text-neutral-500 self-center">
                        +{project.toolsUsed.length - 3}
                      </span>
                    )}
                  </div>
                </div>

                {/* Card Actions Footer */}
                <div className="pt-3 border-t border-white/5 flex items-center justify-between">
                  <span className="text-[11px] font-mono text-neutral-500">
                    {project.client || 'Client project'}
                  </span>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => {
                        setEditingProject(project);
                        setIsModalOpen(true);
                      }}
                      className="px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-cyan-300 hover:text-white text-xs font-mono flex items-center gap-1.5 transition-colors cursor-pointer"
                      title="Edit project"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Edit</span>
                    </button>

                    <button
                      onClick={() => setDeleteConfirmId(project.id)}
                      className="p-1.5 rounded-lg bg-white/5 hover:bg-red-500/20 text-neutral-400 hover:text-red-300 transition-colors cursor-pointer"
                      title="Delete project"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Delete confirmation overlay */}
              {deleteConfirmId === project.id && (
                <div className="absolute inset-0 z-20 bg-black/90 backdrop-blur-sm p-4 flex flex-col items-center justify-center text-center">
                  <AlertTriangle className="w-6 h-6 text-red-400 mb-2" />
                  <p className="text-xs text-white font-bold mb-1">Delete "{project.title}"?</p>
                  <p className="text-[11px] text-neutral-400 mb-4">This action cannot be undone.</p>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setDeleteConfirmId(null)}
                      className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-mono text-white transition-colors cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => handleDelete(project.id)}
                      className="px-3 py-1.5 rounded-lg bg-red-500 hover:bg-red-600 text-xs font-mono text-white font-bold transition-colors cursor-pointer"
                    >
                      Confirm Delete
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Add / Edit Project Modal */}
      <AdminProjectModal
        isOpen={isModalOpen}
        project={editingProject}
        onClose={() => {
          setIsModalOpen(false);
          setEditingProject(null);
        }}
        onSave={handleSaveProject}
      />
    </div>
  );
};
