import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  User, 
  FolderGit2, 
  Layers, 
  MessageSquareQuote, 
  Wrench, 
  Video, 
  Mail, 
  Settings, 
  ExternalLink, 
  LogOut, 
  ShieldCheck, 
  Sparkles,
  Menu,
  X,
  Building2,
  Workflow,
  Award,
  Share2
} from 'lucide-react';
import { usePortfolio } from '../../context/PortfolioContext';

// Subviews
import { AdminOverview } from './AdminOverview';
import { AdminProfile } from './AdminProfile';
import { AdminProjects } from './AdminProjects';
import { AdminServices } from './AdminServices';
import { AdminTestimonials } from './AdminTestimonials';
import { AdminSkills } from './AdminSkills';
import { AdminShowreel } from './AdminShowreel';
import { AdminBrands } from './AdminBrands';
import { AdminProcess } from './AdminProcess';
import { AdminWhyMe } from './AdminWhyMe';
import { AdminSocials } from './AdminSocials';
import { AdminInquiries } from './AdminInquiries';
import { AdminSettings } from './AdminSettings';

interface AdminDashboardProps {
  onShowToast: (msg: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onShowToast }) => {
  const { 
    data, 
    inquiries, 
    setIsAdminOpen, 
    logoutAdmin 
  } = usePortfolio();

  const [activeTab, setActiveTab] = useState<string>('overview');
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);
  const [openNewProjectInitially, setOpenNewProjectInitially] = useState(false);

  const unreadCount = inquiries.filter(i => !i.read).length;

  const navItems = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'profile', label: 'Profile & Hero', icon: User },
    { id: 'projects', label: 'Projects', icon: FolderGit2, badge: data.projects.length },
    { id: 'services', label: 'Services', icon: Layers, badge: data.services.length },
    { id: 'testimonials', label: 'Reviews', icon: MessageSquareQuote, badge: data.testimonials.length },
    { id: 'skills', label: 'Skills & Tools', icon: Wrench },
    { id: 'showreel', label: 'Showreel & Grade', icon: Video },
    { id: 'brands', label: 'Brand Wall', icon: Building2, badge: data.brands?.length },
    { id: 'process', label: 'Workflow Process', icon: Workflow, badge: data.process?.length },
    { id: 'whyme', label: 'Why Choose Me', icon: Award, badge: data.whyMe?.length },
    { id: 'socials', label: 'Social Channels', icon: Share2, badge: data.socials?.length },
    { id: 'inquiries', label: 'Client Inquiries', icon: Mail, highlightBadge: unreadCount > 0 ? unreadCount : undefined },
    { id: 'settings', label: 'Backup & Security', icon: Settings },
  ];

  const handleSelectTab = (tabId: string) => {
    setActiveTab(tabId);
    setIsMobileNavOpen(false);
  };

  const handleOpenNewProject = () => {
    setActiveTab('projects');
    setOpenNewProjectInitially(true);
  };

  return (
    <div className="min-h-screen bg-[#07080b] text-[#edf0f5] flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-40 bg-[#0a0d14]/90 backdrop-blur-xl border-b border-white/10 px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsMobileNavOpen(!isMobileNavOpen)}
            className="lg:hidden p-2 rounded-xl bg-white/5 text-neutral-300 hover:text-white transition-colors"
          >
            {isMobileNavOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-400 via-sky-500 to-blue-600 flex items-center justify-center font-display font-extrabold text-black text-lg shadow-lg shadow-cyan-500/20">
              T
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-display font-bold text-sm sm:text-base text-white">
                  Tawhid Studio CMS
                </span>
                <span className="hidden sm:inline-block text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  ADMIN PORTAL
                </span>
              </div>
              <p className="text-[11px] font-mono text-neutral-400 hidden sm:block">
                Controlling: {data.personal.name} • {data.personal.role}
              </p>
            </div>
          </div>
        </div>

        {/* Right side actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={() => setIsAdminOpen(false)}
            className="px-3.5 py-2 rounded-xl bg-cyan-400/10 hover:bg-cyan-400/20 text-cyan-300 border border-cyan-400/30 font-mono text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">View Live Portfolio</span>
            <span className="sm:hidden">Live Site</span>
          </button>

          <button
            onClick={() => {
              logoutAdmin();
              setIsAdminOpen(false);
              onShowToast('Logged out of Admin Portal.');
            }}
            className="p-2 rounded-xl bg-white/5 hover:bg-red-500/20 text-neutral-400 hover:text-red-400 transition-colors cursor-pointer"
            title="Log Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Layout: Sidebar + Viewport */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 gap-8">
        
        {/* Desktop Sidebar Navigation */}
        <aside className="hidden lg:block w-64 flex-shrink-0 space-y-1 sticky top-24 self-start">
          <div className="p-3 mb-2 rounded-xl bg-white/[0.02] border border-white/5 flex items-center justify-between text-xs font-mono text-neutral-400">
            <span>Status:</span>
            <span className="text-emerald-400 flex items-center gap-1.5 font-bold">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Live Synced
            </span>
          </div>

          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => handleSelectTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-mono text-xs transition-all cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-500/20 to-blue-500/10 text-cyan-300 border border-cyan-500/30 font-bold shadow-sm'
                    : 'text-neutral-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-neutral-500'}`} />
                  <span>{item.label}</span>
                </div>

                {item.highlightBadge ? (
                  <span className="px-2 py-0.5 rounded-full bg-cyan-500 text-black text-[10px] font-bold">
                    {item.highlightBadge}
                  </span>
                ) : item.badge !== undefined ? (
                  <span className="text-[10px] text-neutral-500">
                    {item.badge}
                  </span>
                ) : null}
              </button>
            );
          })}

          <div className="pt-6 mt-6 border-t border-white/5 text-[11px] font-mono text-neutral-500 px-3">
            <p className="flex items-center gap-1.5 text-neutral-400 mb-1">
              <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
              <span>Full Local Persistence</span>
            </p>
            <p className="font-light">
              All edits are active immediately and preserved across browser sessions.
            </p>
          </div>
        </aside>

        {/* Mobile Navigation Drawer */}
        <AnimatePresence>
          {isMobileNavOpen && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="lg:hidden fixed inset-x-4 top-20 z-50 p-4 rounded-2xl bg-[#0e111a] border border-cyan-500/30 shadow-2xl space-y-1.5"
            >
              {navItems.map(item => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;

                return (
                  <button
                    key={item.id}
                    onClick={() => handleSelectTab(item.id)}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-mono text-xs transition-colors ${
                      isActive
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold'
                        : 'text-neutral-300 hover:bg-white/5'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon className="w-4 h-4 text-cyan-400" />
                      <span>{item.label}</span>
                    </div>
                    {item.highlightBadge ? (
                      <span className="px-2 py-0.5 rounded-full bg-cyan-500 text-black text-[10px] font-bold">
                        {item.highlightBadge}
                      </span>
                    ) : item.badge !== undefined ? (
                      <span className="text-[10px] text-neutral-500">{item.badge}</span>
                    ) : null}
                  </button>
                );
              })}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Active Tab Viewport */}
        <main className="flex-1 min-w-0">
          {activeTab === 'overview' && (
            <AdminOverview
              onSelectTab={handleSelectTab}
              onOpenNewProject={handleOpenNewProject}
              onViewSite={() => setIsAdminOpen(false)}
            />
          )}

          {activeTab === 'profile' && (
            <AdminProfile onShowToast={onShowToast} />
          )}

          {activeTab === 'projects' && (
            <AdminProjects
              onShowToast={onShowToast}
              openNewModalInitially={openNewProjectInitially}
            />
          )}

          {activeTab === 'services' && (
            <AdminServices onShowToast={onShowToast} />
          )}

          {activeTab === 'testimonials' && (
            <AdminTestimonials onShowToast={onShowToast} />
          )}

          {activeTab === 'skills' && (
            <AdminSkills onShowToast={onShowToast} />
          )}

          {activeTab === 'showreel' && (
            <AdminShowreel onShowToast={onShowToast} />
          )}

          {activeTab === 'brands' && (
            <AdminBrands onShowToast={onShowToast} />
          )}

          {activeTab === 'process' && (
            <AdminProcess onShowToast={onShowToast} />
          )}

          {activeTab === 'whyme' && (
            <AdminWhyMe onShowToast={onShowToast} />
          )}

          {activeTab === 'socials' && (
            <AdminSocials onShowToast={onShowToast} />
          )}

          {activeTab === 'inquiries' && (
            <AdminInquiries onShowToast={onShowToast} />
          )}

          {activeTab === 'settings' && (
            <AdminSettings onShowToast={onShowToast} />
          )}
        </main>

      </div>
    </div>
  );
};
