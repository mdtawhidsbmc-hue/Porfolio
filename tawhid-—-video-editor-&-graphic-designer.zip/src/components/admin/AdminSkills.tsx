import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Sliders, Plus, Trash2, Save, Wrench, Sparkles, CheckCircle2 } from 'lucide-react';
import { SkillCategory, SkillItem } from '../../types/portfolio';
import { usePortfolio } from '../../context/PortfolioContext';

interface AdminSkillsProps {
  onShowToast: (msg: string) => void;
}

export const AdminSkills: React.FC<AdminSkillsProps> = ({ onShowToast }) => {
  const { data, updateSkills } = usePortfolio();
  const [skillCategories, setSkillCategories] = useState<SkillCategory[]>(
    data.skills.map(c => ({
      ...c,
      skills: c.skills.map(s => ({ ...s }))
    }))
  );

  const handleUpdatePercentage = (catIndex: number, skillIndex: number, val: number) => {
    const updated = [...skillCategories];
    updated[catIndex].skills[skillIndex].percentage = val;
    setSkillCategories(updated);
  };

  const handleUpdateLevel = (catIndex: number, skillIndex: number, level: any) => {
    const updated = [...skillCategories];
    updated[catIndex].skills[skillIndex].level = level;
    setSkillCategories(updated);
  };

  const handleAddSkill = (catIndex: number) => {
    const name = prompt('Enter new tool/skill name (e.g. "CapCut Desktop", "Figma", "Blender"):');
    if (!name) return;

    const updated = [...skillCategories];
    updated[catIndex].skills.push({
      name,
      level: 'Advanced',
      percentage: 85
    });
    setSkillCategories(updated);
  };

  const handleDeleteSkill = (catIndex: number, skillIndex: number) => {
    const updated = [...skillCategories];
    updated[catIndex].skills.splice(skillIndex, 1);
    setSkillCategories(updated);
  };

  const handleSaveAll = (e: React.FormEvent) => {
    e.preventDefault();
    updateSkills(skillCategories);
    onShowToast('Creative skills and toolsets saved successfully!');
  };

  return (
    <form onSubmit={handleSaveAll} className="space-y-8 max-w-4xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/5">
        <div>
          <h2 className="text-xl sm:text-2xl font-display font-bold text-white flex items-center gap-2.5">
            <Wrench className="w-5 h-5 text-cyan-400" />
            <span>Creative Software & Technical Skills</span>
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 font-light mt-1">
            Adjust proficiency percentages, levels, and toolsets displayed in the Skills section.
          </p>
        </div>

        <button
          type="submit"
          className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-cyan-500/25 transition-all cursor-pointer whitespace-nowrap self-start sm:self-auto"
        >
          <Save className="w-4 h-4" />
          <span>Save Skills</span>
        </button>
      </div>

      <div className="space-y-6">
        {skillCategories.map((cat, catIdx) => (
          <div
            key={catIdx}
            className="p-6 rounded-2xl bg-[#0b0e17] border border-white/5 space-y-4"
          >
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <div>
                <h3 className="font-display font-bold text-base text-white">
                  {cat.category}
                </h3>
                <p className="text-xs text-neutral-400 font-mono">
                  {cat.description}
                </p>
              </div>

              <button
                type="button"
                onClick={() => handleAddSkill(catIdx)}
                className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-cyan-300 hover:text-white text-xs font-mono flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Tool</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {cat.skills.map((sk, skIdx) => (
                <div
                  key={skIdx}
                  className="p-4 rounded-xl bg-[#07090e] border border-white/5 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-white">
                      {sk.name}
                    </span>
                    <div className="flex items-center gap-2">
                      <select
                        value={sk.level}
                        onChange={e => handleUpdateLevel(catIdx, skIdx, e.target.value)}
                        className="bg-[#0b0e17] border border-white/10 rounded-lg px-2 py-1 text-[11px] text-cyan-300 font-mono"
                      >
                        <option value="Advanced">Advanced</option>
                        <option value="Professional">Professional</option>
                        <option value="Intermediate">Intermediate</option>
                      </select>
                      <button
                        type="button"
                        onClick={() => handleDeleteSkill(catIdx, skIdx)}
                        className="p-1 text-neutral-500 hover:text-red-400 rounded"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex justify-between text-xs font-mono text-neutral-400">
                      <span>Proficiency</span>
                      <span className="text-cyan-400 font-bold">{sk.percentage}%</span>
                    </div>
                    <input
                      type="range"
                      min="50"
                      max="100"
                      value={sk.percentage}
                      onChange={e => handleUpdatePercentage(catIdx, skIdx, parseInt(e.target.value))}
                      className="w-full accent-cyan-400 bg-neutral-800 h-1.5 rounded-lg cursor-pointer"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="flex justify-end pt-2">
        <button
          type="submit"
          className="px-8 py-3.5 rounded-xl bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-xl shadow-cyan-500/25 cursor-pointer"
        >
          <Save className="w-4 h-4" />
          <span>Save Skills & Tools</span>
        </button>
      </div>
    </form>
  );
};
