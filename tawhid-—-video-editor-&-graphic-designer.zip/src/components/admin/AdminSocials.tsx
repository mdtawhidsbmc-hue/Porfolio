import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Save, 
  Plus, 
  Trash2, 
  Edit2, 
  Share2, 
  Globe, 
  ExternalLink, 
  Sparkles,
  Check,
  X
} from 'lucide-react';
import { usePortfolio } from '../../context/PortfolioContext';
import { SocialLink } from '../../types/portfolio';

interface AdminSocialsProps {
  onShowToast: (msg: string) => void;
}

const COMMON_PLATFORMS = [
  { name: 'YouTube', icon: 'Youtube', defaultUrl: 'https://youtube.com/@yourchannel' },
  { name: 'Instagram', icon: 'Instagram', defaultUrl: 'https://instagram.com/yourhandle' },
  { name: 'Behance', icon: 'Globe', defaultUrl: 'https://behance.net/yourprofile' },
  { name: 'Dribbble', icon: 'Dribbble', defaultUrl: 'https://dribbble.com/yourprofile' },
  { name: 'LinkedIn', icon: 'Linkedin', defaultUrl: 'https://linkedin.com/in/yourprofile' },
  { name: 'Facebook', icon: 'Facebook', defaultUrl: 'https://facebook.com/yourpage' },
  { name: 'X / Twitter', icon: 'Twitter', defaultUrl: 'https://x.com/yourhandle' },
  { name: 'Telegram', icon: 'Send', defaultUrl: 'https://t.me/yourusername' },
  { name: 'Discord', icon: 'MessageSquare', defaultUrl: 'https://discord.gg/yourinvite' },
  { name: 'Vimeo', icon: 'Video', defaultUrl: 'https://vimeo.com/yourprofile' },
];

export const AdminSocials: React.FC<AdminSocialsProps> = ({ onShowToast }) => {
  const { data, updateSocials } = usePortfolio();
  const [socials, setSocials] = useState<SocialLink[]>(() =>
    data.socials ? data.socials.map(s => ({ ...s })) : []
  );

  const [editingIndex, setEditingIndex] = useState<number | 'new' | null>(null);
  const [form, setForm] = useState<SocialLink>({
    platform: 'Instagram',
    url: '',
    iconName: 'Instagram',
    username: ''
  });

  const handleOpenAdd = () => {
    setEditingIndex('new');
    setForm({
      platform: 'YouTube',
      url: 'https://youtube.com',
      iconName: 'Youtube',
      username: '@tawhid'
    });
  };

  const handleOpenEdit = (index: number) => {
    setEditingIndex(index);
    setForm({ ...socials[index] });
  };

  const handleSelectPreset = (preset: typeof COMMON_PLATFORMS[0]) => {
    setForm({
      ...form,
      platform: preset.name,
      iconName: preset.icon,
      url: form.url || preset.defaultUrl
    });
  };

  const handleSaveSocial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.platform.trim() || !form.url.trim()) return;

    let updated: SocialLink[];
    if (editingIndex === 'new') {
      updated = [...socials, form];
    } else if (typeof editingIndex === 'number') {
      updated = socials.map((s, i) => (i === editingIndex ? form : s));
    } else {
      return;
    }

    setSocials(updated);
    updateSocials(updated);
    setEditingIndex(null);
    onShowToast('Social media links updated successfully!');
  };

  const handleDeleteSocial = (index: number) => {
    if (window.confirm('Delete this social media channel?')) {
      const updated = socials.filter((_, i) => i !== index);
      setSocials(updated);
      updateSocials(updated);
      onShowToast('Social link removed.');
    }
  };

  return (
    <div className="space-y-8 max-w-4xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/5">
        <div>
          <h2 className="text-xl sm:text-2xl font-display font-bold text-white flex items-center gap-2">
            <Share2 className="w-6 h-6 text-cyan-400" />
            <span>Social Media Channels & Profiles</span>
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 font-light mt-1">
            Manage the social channels displayed in the navbar, footer, contact section, and hero quick links.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-cyan-500/25 transition-all cursor-pointer whitespace-nowrap self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Social Channel</span>
        </button>
      </div>

      {/* Editor Modal/Card */}
      <AnimatePresence>
        {editingIndex !== null && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="p-6 rounded-2xl bg-[#0e111a] border border-cyan-500/30 shadow-2xl shadow-cyan-950/40"
          >
            <h3 className="font-display font-bold text-white text-base mb-4 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>{editingIndex === 'new' ? 'Add Social Profile' : `Edit ${form.platform}`}</span>
            </h3>

            {/* Quick Platform Presets */}
            <div className="mb-4">
              <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                Quick Platform Presets
              </label>
              <div className="flex flex-wrap gap-2">
                {COMMON_PLATFORMS.map(cp => (
                  <button
                    key={cp.name}
                    type="button"
                    onClick={() => handleSelectPreset(cp)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-mono border transition-all cursor-pointer ${
                      form.platform.toLowerCase() === cp.name.toLowerCase()
                        ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                        : 'bg-[#07090e] border-white/10 text-neutral-400 hover:text-white'
                    }`}
                  >
                    {cp.name}
                  </button>
                ))}
              </div>
            </div>

            <form onSubmit={handleSaveSocial} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                    Platform Name *
                  </label>
                  <input
                    type="text"
                    value={form.platform}
                    onChange={e => setForm({ ...form, platform: e.target.value })}
                    placeholder="e.g. YouTube, Instagram, Behance"
                    className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                    Display Username / Handle
                  </label>
                  <input
                    type="text"
                    value={form.username}
                    onChange={e => setForm({ ...form, username: e.target.value })}
                    placeholder="e.g. @tawhid.edits or Tawhid Visuals"
                    className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                  Target Profile URL *
                </label>
                <input
                  type="url"
                  value={form.url}
                  onChange={e => setForm({ ...form, url: e.target.value })}
                  placeholder="https://..."
                  className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all font-mono"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/5">
                <button
                  type="button"
                  onClick={() => setEditingIndex(null)}
                  className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-300 text-xs font-mono transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Channel</span>
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Social Links List */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {socials.map((social, idx) => (
          <div
            key={idx}
            className="p-5 rounded-2xl bg-[#0b0e17] border border-white/5 hover:border-cyan-500/30 transition-all flex items-center justify-between group"
          >
            <div className="space-y-1 overflow-hidden pr-3">
              <div className="flex items-center gap-2">
                <span className="font-display font-bold text-white text-base">
                  {social.platform}
                </span>
                <span className="text-xs font-mono text-cyan-400">
                  {social.username}
                </span>
              </div>
              <a
                href={social.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs font-mono text-neutral-400 hover:text-white flex items-center gap-1 truncate"
              >
                <span>{social.url}</span>
                <ExternalLink className="w-3 h-3 flex-shrink-0" />
              </a>
            </div>

            <div className="flex items-center gap-1.5 opacity-80 group-hover:opacity-100 transition-opacity flex-shrink-0">
              <button
                onClick={() => handleOpenEdit(idx)}
                className="p-2 rounded-lg bg-white/5 hover:bg-cyan-500/20 text-neutral-400 hover:text-cyan-300 transition-colors cursor-pointer"
                title="Edit Social"
              >
                <Edit2 className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => handleDeleteSocial(idx)}
                className="p-2 rounded-lg bg-white/5 hover:bg-red-500/20 text-neutral-400 hover:text-red-400 transition-colors cursor-pointer"
                title="Delete Social"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
