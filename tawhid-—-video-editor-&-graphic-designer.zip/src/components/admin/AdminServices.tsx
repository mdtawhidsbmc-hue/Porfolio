import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Layers, 
  Plus, 
  Edit3, 
  Trash2, 
  Save, 
  X, 
  Film, 
  Palette, 
  Sparkles, 
  Share2, 
  Tv, 
  Compass,
  CheckCircle2
} from 'lucide-react';
import { Service } from '../../types/portfolio';
import { usePortfolio } from '../../context/PortfolioContext';

interface AdminServicesProps {
  onShowToast: (msg: string) => void;
}

export const AdminServices: React.FC<AdminServicesProps> = ({ onShowToast }) => {
  const { data, addService, editService, deleteService } = usePortfolio();
  const [editingService, setEditingService] = useState<Service | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);

  // Form state
  const [formData, setFormData] = useState<Partial<Service>>({
    id: '',
    number: '07',
    title: '',
    description: '',
    iconName: 'Film',
    deliverables: []
  });
  const [deliverablesText, setDeliverablesText] = useState('');

  const handleOpenEdit = (s: Service) => {
    setEditingService(s);
    setIsAddingNew(false);
    setFormData(s);
    setDeliverablesText(s.deliverables.join('\n'));
  };

  const handleOpenNew = () => {
    const nextNum = (data.services.length + 1).toString().padStart(2, '0');
    setEditingService(null);
    setIsAddingNew(true);
    setFormData({
      id: `service-${Date.now()}`,
      number: nextNum,
      title: '',
      description: '',
      iconName: 'Film',
      deliverables: []
    });
    setDeliverablesText('Deliverable 1\nDeliverable 2\nDeliverable 3');
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.description) return;

    const deliverablesList = deliverablesText
      .split('\n')
      .map(d => d.trim())
      .filter(Boolean);

    const finalized: Service = {
      id: formData.id || `service-${Date.now()}`,
      number: formData.number || '01',
      title: formData.title || 'Untitled Service',
      description: formData.description || '',
      iconName: formData.iconName || 'Film',
      deliverables: deliverablesList.length > 0 ? deliverablesList : ['Standard High Quality Deliverables']
    };

    if (isAddingNew) {
      addService(finalized);
      onShowToast(`Added new service "${finalized.title}"!`);
    } else if (editingService) {
      editService(finalized.id, finalized);
      onShowToast(`Updated service "${finalized.title}"!`);
    }

    setEditingService(null);
    setIsAddingNew(false);
  };

  const handleDelete = (id: string, title: string) => {
    if (window.confirm(`Are you sure you want to remove "${title}"?`)) {
      deleteService(id);
      onShowToast(`Removed service "${title}"`);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/5">
        <div>
          <h2 className="text-xl sm:text-2xl font-display font-bold text-white flex items-center gap-2.5">
            <Layers className="w-5 h-5 text-cyan-400" />
            <span>Manage Core Services</span>
            <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
              {data.services.length} Active
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 font-light mt-1">
            Configure your professional video editing, graphic design, and branding offerings and their bullet point deliverables.
          </p>
        </div>

        <button
          onClick={handleOpenNew}
          className="px-5 py-3 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-cyan-500/25 transition-all cursor-pointer whitespace-nowrap self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Service</span>
        </button>
      </div>

      {/* Services List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {data.services.map(s => (
          <div
            key={s.id}
            className="p-5 rounded-2xl bg-[#0b0e17] border border-white/5 hover:border-cyan-500/30 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-mono text-cyan-400 font-bold">
                  SERVICE {s.number}
                </span>
                <span className="text-xs font-mono px-2 py-0.5 rounded bg-white/5 text-neutral-400">
                  Icon: {s.iconName}
                </span>
              </div>

              <h3 className="font-display font-bold text-base text-white mb-2">
                {s.title}
              </h3>
              <p className="text-xs text-neutral-400 font-light mb-4 line-clamp-3">
                {s.description}
              </p>

              <div className="space-y-1.5 mb-4">
                <p className="text-[11px] font-mono uppercase tracking-wider text-neutral-500">
                  Deliverables ({s.deliverables.length}):
                </p>
                {s.deliverables.slice(0, 4).map((d, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs text-neutral-300">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                    <span className="line-clamp-1">{d}</span>
                  </div>
                ))}
                {s.deliverables.length > 4 && (
                  <span className="text-[10px] font-mono text-neutral-500">
                    +{s.deliverables.length - 4} more
                  </span>
                )}
              </div>
            </div>

            <div className="pt-3 border-t border-white/5 flex items-center justify-end gap-2">
              <button
                onClick={() => handleOpenEdit(s)}
                className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-cyan-300 hover:text-white text-xs font-mono flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
              <button
                onClick={() => handleDelete(s.id, s.title)}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-red-500/20 text-neutral-400 hover:text-red-300 transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Edit / Add Modal */}
      {(editingService || isAddingNew) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-xl bg-[#0e111a] border border-cyan-500/30 rounded-2xl p-6 sm:p-8 shadow-2xl text-white max-h-[90vh] overflow-y-auto relative"
          >
            <button
              onClick={() => {
                setEditingService(null);
                setIsAddingNew(false);
              }}
              className="absolute top-4 right-4 p-2 text-neutral-400 hover:text-white rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="font-display font-bold text-lg text-white mb-4">
              {isAddingNew ? 'Add New Service Offering' : `Edit "${editingService?.title}"`}
            </h3>

            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-1.5">
                    Order Number
                  </label>
                  <input
                    type="text"
                    value={formData.number}
                    onChange={e => setFormData({ ...formData, number: e.target.value })}
                    className="w-full bg-[#07090e] border border-white/10 rounded-xl px-3 py-2 text-xs text-white"
                    placeholder="01"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-1.5">
                    Icon Style
                  </label>
                  <select
                    value={formData.iconName}
                    onChange={e => setFormData({ ...formData, iconName: e.target.value })}
                    className="w-full bg-[#07090e] border border-white/10 rounded-xl px-3 py-2 text-xs text-white"
                  >
                    <option value="Film">Film / Cinema</option>
                    <option value="Palette">Palette / Graphic</option>
                    <option value="Share2">Share / Social</option>
                    <option value="Tv">TV / YouTube</option>
                    <option value="Compass">Compass / Branding</option>
                    <option value="Sparkles">Sparkles / Motion</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-1.5">
                  Service Title *
                </label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={e => setFormData({ ...formData, title: e.target.value })}
                  className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white"
                  placeholder="e.g. YouTube Video Production"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-1.5">
                  Detailed Description *
                </label>
                <textarea
                  rows={3}
                  value={formData.description}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2 text-xs text-white"
                  placeholder="Explain what clients gain from this service..."
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-1.5">
                  Deliverables (1 per line)
                </label>
                <textarea
                  rows={4}
                  value={deliverablesText}
                  onChange={e => setDeliverablesText(e.target.value)}
                  className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2 text-xs text-white font-mono"
                  placeholder="Cinematic 4K Master&#10;Color Grading&#10;Sound Design"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => {
                    setEditingService(null);
                    setIsAddingNew(false);
                  }}
                  className="px-4 py-2 rounded-xl bg-white/5 text-xs font-mono text-neutral-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 text-black font-bold text-xs uppercase"
                >
                  Save Service
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
};
