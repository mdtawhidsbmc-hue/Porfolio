import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Save, Plus, Trash2, Edit2, Workflow, Sparkles, Check, X, ArrowUpDown } from 'lucide-react';
import { usePortfolio } from '../../context/PortfolioContext';
import { ProcessStep } from '../../types/portfolio';

interface AdminProcessProps {
  onShowToast: (msg: string) => void;
}

export const AdminProcess: React.FC<AdminProcessProps> = ({ onShowToast }) => {
  const { data, updateProcess } = usePortfolio();
  const [steps, setSteps] = useState<ProcessStep[]>(() =>
    data.process ? data.process.map(p => ({ ...p, deliverables: [...p.deliverables] })) : []
  );

  const [editingIndex, setEditingIndex] = useState<number | 'new' | null>(null);
  const [form, setForm] = useState<ProcessStep>({
    step: '01',
    title: '',
    description: '',
    deliverables: []
  });
  const [deliverableInput, setDeliverableInput] = useState('');

  const handleOpenAdd = () => {
    setEditingIndex('new');
    setForm({
      step: `0${steps.length + 1}`,
      title: '',
      description: '',
      deliverables: []
    });
    setDeliverableInput('');
  };

  const handleOpenEdit = (index: number) => {
    setEditingIndex(index);
    setForm({
      step: steps[index].step,
      title: steps[index].title,
      description: steps[index].description,
      deliverables: [...steps[index].deliverables]
    });
    setDeliverableInput('');
  };

  const handleAddDeliverable = () => {
    if (!deliverableInput.trim()) return;
    setForm({
      ...form,
      deliverables: [...form.deliverables, deliverableInput.trim()]
    });
    setDeliverableInput('');
  };

  const handleRemoveDeliverable = (idx: number) => {
    setForm({
      ...form,
      deliverables: form.deliverables.filter((_, i) => i !== idx)
    });
  };

  const handleSaveStep = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim()) return;

    let updated: ProcessStep[];
    if (editingIndex === 'new') {
      updated = [...steps, form];
    } else if (typeof editingIndex === 'number') {
      updated = steps.map((s, i) => (i === editingIndex ? form : s));
    } else {
      return;
    }

    setSteps(updated);
    updateProcess(updated);
    setEditingIndex(null);
    onShowToast('Production Process steps updated successfully!');
  };

  const handleDeleteStep = (index: number) => {
    if (window.confirm('Delete this production phase step?')) {
      const updated = steps.filter((_, i) => i !== index);
      setSteps(updated);
      updateProcess(updated);
      onShowToast('Process step removed.');
    }
  };

  return (
    <div className="space-y-8 max-w-4xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/5">
        <div>
          <h2 className="text-xl sm:text-2xl font-display font-bold text-white flex items-center gap-2">
            <Workflow className="w-6 h-6 text-cyan-400" />
            <span>Creative Production Process</span>
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 font-light mt-1">
            Customize the step-by-step workflow (Discover, Plan, Create, Deliver) that outlines how you collaborate with clients.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-cyan-500/25 transition-all cursor-pointer whitespace-nowrap self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Process Step</span>
        </button>
      </div>

      {/* Editor Modal/Card */}
      <AnimatePresence>
        {editingIndex !== null && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="p-6 rounded-2xl bg-[#0e111a] border border-cyan-500/30 shadow-2xl shadow-cyan-950/40"
          >
            <h3 className="font-display font-bold text-white text-base mb-4 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>{editingIndex === 'new' ? 'Add New Process Phase' : `Edit Step ${form.step}`}</span>
            </h3>

            <form onSubmit={handleSaveStep} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                    Step Number
                  </label>
                  <input
                    type="text"
                    value={form.step}
                    onChange={e => setForm({ ...form, step: e.target.value })}
                    placeholder="01"
                    className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-cyan-400 font-mono font-bold outline-none transition-all"
                    required
                  />
                </div>

                <div className="sm:col-span-3">
                  <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                    Step Title *
                  </label>
                  <input
                    type="text"
                    value={form.title}
                    onChange={e => setForm({ ...form, title: e.target.value })}
                    placeholder="e.g. Discovery & Creative Brief"
                    className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                  Step Description
                </label>
                <textarea
                  rows={3}
                  value={form.description}
                  onChange={e => setForm({ ...form, description: e.target.value })}
                  placeholder="Explain what happens in this stage..."
                  className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none transition-all leading-relaxed"
                  required
                />
              </div>

              {/* Deliverables tags */}
              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                  Phase Deliverables & Checkpoints
                </label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    value={deliverableInput}
                    onChange={e => setDeliverableInput(e.target.value)}
                    onKeyDown={e => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddDeliverable();
                      }
                    }}
                    placeholder="e.g. Moodboard, First Cut, 4K Export (Press Enter)"
                    className="flex-grow bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2 text-sm text-white outline-none transition-all"
                  />
                  <button
                    type="button"
                    onClick={handleAddDeliverable}
                    className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-cyan-400 text-xs font-mono transition-colors"
                  >
                    Add
                  </button>
                </div>

                <div className="flex flex-wrap gap-2 pt-1">
                  {form.deliverables.map((deliv, dIdx) => (
                    <span
                      key={dIdx}
                      className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-mono"
                    >
                      <span>{deliv}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveDeliverable(dIdx)}
                        className="hover:text-red-400 cursor-pointer"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/5">
                <button
                  type="button"
                  onClick={() => setEditingIndex(null)}
                  className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-300 text-xs font-mono transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Step</span>
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Steps List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {steps.map((step, idx) => (
          <div
            key={idx}
            className="p-6 rounded-2xl bg-[#0b0e17] border border-white/5 hover:border-cyan-500/30 transition-all flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center font-mono font-bold text-base text-cyan-300">
                  {step.step}
                </div>
                <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={() => handleOpenEdit(idx)}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-cyan-500/20 text-neutral-400 hover:text-cyan-300 transition-colors cursor-pointer"
                    title="Edit Step"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleDeleteStep(idx)}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-red-500/20 text-neutral-400 hover:text-red-400 transition-colors cursor-pointer"
                    title="Delete Step"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <h4 className="font-display font-bold text-white text-lg mb-2">
                {step.title}
              </h4>
              <p className="text-xs text-neutral-300 font-light leading-relaxed mb-4">
                {step.description}
              </p>
            </div>

            {step.deliverables && step.deliverables.length > 0 && (
              <div className="pt-3 border-t border-white/5 flex flex-wrap gap-1.5">
                {step.deliverables.map((d, dIdx) => (
                  <span
                    key={dIdx}
                    className="text-[10px] font-mono px-2.5 py-0.5 rounded-md bg-white/5 text-neutral-400"
                  >
                    • {d}
                  </span>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
