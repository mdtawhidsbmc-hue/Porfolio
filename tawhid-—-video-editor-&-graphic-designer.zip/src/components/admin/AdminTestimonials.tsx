import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  MessageSquareQuote, 
  Plus, 
  Edit3, 
  Trash2, 
  Star, 
  Save, 
  X, 
  User 
} from 'lucide-react';
import { Testimonial } from '../../types/portfolio';
import { usePortfolio } from '../../context/PortfolioContext';

interface AdminTestimonialsProps {
  onShowToast: (msg: string) => void;
}

export const AdminTestimonials: React.FC<AdminTestimonialsProps> = ({ onShowToast }) => {
  const { data, addTestimonial, editTestimonial, deleteTestimonial } = usePortfolio();
  const [editingTestimonial, setEditingTestimonial] = useState<Testimonial | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);

  const [formData, setFormData] = useState<Partial<Testimonial>>({
    id: '',
    clientName: '',
    role: '',
    companyOrChannel: '',
    quote: '',
    projectType: 'Video Editing',
    rating: 5,
    avatar: ''
  });

  const handleOpenEdit = (t: Testimonial) => {
    setEditingTestimonial(t);
    setIsAddingNew(false);
    setFormData(t);
  };

  const handleOpenNew = () => {
    setEditingTestimonial(null);
    setIsAddingNew(true);
    setFormData({
      id: `testimonial-${Date.now()}`,
      clientName: '',
      role: 'Content Creator',
      companyOrChannel: 'YouTube Creator (500K Subs)',
      quote: '',
      projectType: 'Video Editing & Thumbnail',
      rating: 5,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'
    });
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.clientName || !formData.quote) return;

    const finalized: Testimonial = {
      id: formData.id || `testimonial-${Date.now()}`,
      clientName: formData.clientName || 'Anonymous Client',
      role: formData.role || 'Creator',
      companyOrChannel: formData.companyOrChannel || 'Client',
      quote: formData.quote || '',
      projectType: formData.projectType || 'Creative Production',
      rating: formData.rating || 5,
      avatar: formData.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'
    };

    if (isAddingNew) {
      addTestimonial(finalized);
      onShowToast(`Added review from "${finalized.clientName}"!`);
    } else if (editingTestimonial) {
      editTestimonial(finalized.id, finalized);
      onShowToast(`Updated review from "${finalized.clientName}"!`);
    }

    setEditingTestimonial(null);
    setIsAddingNew(false);
  };

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(`Delete review from "${name}"?`)) {
      deleteTestimonial(id);
      onShowToast(`Deleted review from "${name}"`);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/5">
        <div>
          <h2 className="text-xl sm:text-2xl font-display font-bold text-white flex items-center gap-2.5">
            <MessageSquareQuote className="w-5 h-5 text-cyan-400" />
            <span>Client Reviews & Testimonials</span>
            <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
              {data.testimonials.length} Reviews
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 font-light mt-1">
            Highlight recommendations, ratings, and quotes from YouTubers, agencies, and brand managers.
          </p>
        </div>

        <button
          onClick={handleOpenNew}
          className="px-5 py-3 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-cyan-500/25 transition-all cursor-pointer whitespace-nowrap self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Review</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {data.testimonials.map(t => (
          <div
            key={t.id}
            className="p-5 rounded-2xl bg-[#0b0e17] border border-white/5 hover:border-cyan-500/30 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-1 text-amber-400">
                  {[...Array(t.rating || 5)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                  ))}
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 text-cyan-300">
                  {t.projectType}
                </span>
              </div>

              <p className="text-xs text-neutral-300 italic font-light mb-4 line-clamp-3">
                "{t.quote}"
              </p>

              <div className="flex items-center gap-3">
                <img
                  src={t.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'}
                  alt={t.clientName}
                  className="w-10 h-10 rounded-full object-cover border border-cyan-500/30"
                />
                <div>
                  <h4 className="font-display font-bold text-xs text-white">
                    {t.clientName}
                  </h4>
                  <p className="text-[11px] text-neutral-400 font-mono">
                    {t.role} • {t.companyOrChannel}
                  </p>
                </div>
              </div>
            </div>

            <div className="pt-3 mt-4 border-t border-white/5 flex items-center justify-end gap-2">
              <button
                onClick={() => handleOpenEdit(t)}
                className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-cyan-300 hover:text-white text-xs font-mono flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
              <button
                onClick={() => handleDelete(t.id, t.clientName)}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-red-500/20 text-neutral-400 hover:text-red-300 transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Edit / Add Modal */}
      {(editingTestimonial || isAddingNew) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-lg bg-[#0e111a] border border-cyan-500/30 rounded-2xl p-6 sm:p-8 shadow-2xl text-white relative"
          >
            <button
              onClick={() => {
                setEditingTestimonial(null);
                setIsAddingNew(false);
              }}
              className="absolute top-4 right-4 p-2 text-neutral-400 hover:text-white rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="font-display font-bold text-lg text-white mb-4">
              {isAddingNew ? 'Add Client Review' : `Edit Review by "${editingTestimonial?.clientName}"`}
            </h3>

            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-1.5">
                    Client Name *
                  </label>
                  <input
                    type="text"
                    value={formData.clientName}
                    onChange={e => setFormData({ ...formData, clientName: e.target.value })}
                    className="w-full bg-[#07090e] border border-white/10 rounded-xl px-3 py-2 text-xs text-white"
                    placeholder="Alex Morgan"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-1.5">
                    Role / Channel
                  </label>
                  <input
                    type="text"
                    value={formData.role}
                    onChange={e => setFormData({ ...formData, role: e.target.value })}
                    className="w-full bg-[#07090e] border border-white/10 rounded-xl px-3 py-2 text-xs text-white"
                    placeholder="Founder / Creator"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-1.5">
                    Company / Channel Name
                  </label>
                  <input
                    type="text"
                    value={formData.companyOrChannel}
                    onChange={e => setFormData({ ...formData, companyOrChannel: e.target.value })}
                    className="w-full bg-[#07090e] border border-white/10 rounded-xl px-3 py-2 text-xs text-white"
                    placeholder="TechByte Media"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-1.5">
                    Rating (Stars)
                  </label>
                  <select
                    value={formData.rating}
                    onChange={e => setFormData({ ...formData, rating: parseInt(e.target.value) })}
                    className="w-full bg-[#07090e] border border-white/10 rounded-xl px-3 py-2 text-xs text-white"
                  >
                    <option value={5}>★★★★★ (5 Stars)</option>
                    <option value={4}>★★★★☆ (4 Stars)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-1.5">
                  Project Type
                </label>
                <input
                  type="text"
                  value={formData.projectType}
                  onChange={e => setFormData({ ...formData, projectType: e.target.value })}
                  className="w-full bg-[#07090e] border border-white/10 rounded-xl px-3 py-2 text-xs text-white"
                  placeholder="e.g. YouTube Video Editing"
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-1.5">
                  Client Avatar Photo URL
                </label>
                <input
                  type="url"
                  value={formData.avatar}
                  onChange={e => setFormData({ ...formData, avatar: e.target.value })}
                  className="w-full bg-[#07090e] border border-white/10 rounded-xl px-3 py-2 text-xs text-white"
                  placeholder="https://images.unsplash.com/..."
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-1.5">
                  Testimonial Quote *
                </label>
                <textarea
                  rows={4}
                  value={formData.quote}
                  onChange={e => setFormData({ ...formData, quote: e.target.value })}
                  className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2 text-xs text-white"
                  placeholder="What did the client say about working with Tawhid?"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => {
                    setEditingTestimonial(null);
                    setIsAddingNew(false);
                  }}
                  className="px-4 py-2 rounded-xl bg-white/5 text-xs font-mono text-neutral-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 text-black font-bold text-xs uppercase"
                >
                  Save Review
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
};
