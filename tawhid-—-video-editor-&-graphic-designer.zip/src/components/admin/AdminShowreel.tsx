import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Video, Sliders, Save, Plus, Trash2, Image, Sparkles } from 'lucide-react';
import { ShowreelConfig, BeforeAfterSample } from '../../types/portfolio';
import { usePortfolio } from '../../context/PortfolioContext';

interface AdminShowreelProps {
  onShowToast: (msg: string) => void;
}

export const AdminShowreel: React.FC<AdminShowreelProps> = ({ onShowToast }) => {
  const { data, updateShowreel, updateBeforeAfterSamples } = usePortfolio();

  const [showreelForm, setShowreelForm] = useState<ShowreelConfig>({
    ...data.showreel,
    chapters: data.showreel.chapters.map(c => ({ ...c }))
  });

  const [samplesForm, setSamplesForm] = useState<BeforeAfterSample[]>(
    data.beforeAfterSamples.map(s => ({ ...s }))
  );

  const handleAddChapter = () => {
    setShowreelForm(prev => ({
      ...prev,
      chapters: [...prev.chapters, { time: '01:00', title: 'New Highlight Segment' }]
    }));
  };

  const handleRemoveChapter = (index: number) => {
    setShowreelForm(prev => ({
      ...prev,
      chapters: prev.chapters.filter((_, i) => i !== index)
    }));
  };

  const handleUpdateChapter = (index: number, field: 'time' | 'title', value: string) => {
    const updated = [...showreelForm.chapters];
    updated[index] = { ...updated[index], [field]: value };
    setShowreelForm(prev => ({ ...prev, chapters: updated }));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateShowreel(showreelForm);
    updateBeforeAfterSamples(samplesForm);
    onShowToast('Showreel & Color Grading settings saved successfully!');
  };

  return (
    <form onSubmit={handleSave} className="space-y-8 max-w-4xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/5">
        <div>
          <h2 className="text-xl sm:text-2xl font-display font-bold text-white flex items-center gap-2.5">
            <Video className="w-5 h-5 text-cyan-400" />
            <span>Showreel & Color Grading Controls</span>
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 font-light mt-1">
            Configure your video showcase, embedded video playback link, time chapters, and interactive before/after grading comparisons.
          </p>
        </div>

        <button
          type="submit"
          className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-cyan-500/25 transition-all cursor-pointer whitespace-nowrap self-start sm:self-auto"
        >
          <Save className="w-4 h-4" />
          <span>Save Changes</span>
        </button>
      </div>

      {/* 1. Showreel Video & Theater Settings */}
      <div className="p-6 rounded-2xl bg-[#0b0e17] border border-white/5 space-y-5">
        <h3 className="font-display font-bold text-base text-white flex items-center gap-2 border-b border-white/5 pb-3">
          <Video className="w-4 h-4 text-cyan-400" />
          <span>Showreel Player Settings</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              Showreel Headline
            </label>
            <input
              type="text"
              value={showreelForm.title}
              onChange={e => setShowreelForm({ ...showreelForm, title: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              Total Duration (e.g. 02:14)
            </label>
            <input
              type="text"
              value={showreelForm.videoDuration}
              onChange={e => setShowreelForm({ ...showreelForm, videoDuration: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              Video / Embed URL (YouTube, Vimeo, or Direct MP4 link)
            </label>
            <input
              type="text"
              value={showreelForm.embedOrVideoUrl}
              onChange={e => setShowreelForm({ ...showreelForm, embedOrVideoUrl: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none"
              placeholder="https://www.youtube.com/watch?v=... or MP4 url"
              required
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              Showreel Poster Preview Image URL
            </label>
            <input
              type="url"
              value={showreelForm.previewImage}
              onChange={e => setShowreelForm({ ...showreelForm, previewImage: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              Description
            </label>
            <textarea
              rows={2}
              value={showreelForm.description}
              onChange={e => setShowreelForm({ ...showreelForm, description: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2 text-sm text-white outline-none"
            />
          </div>
        </div>

        {/* Chapters */}
        <div className="pt-4 border-t border-white/5 space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs font-mono uppercase tracking-wider text-neutral-400">
              Interactive Showreel Chapters ({showreelForm.chapters.length})
            </label>
            <button
              type="button"
              onClick={handleAddChapter}
              className="text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Chapter</span>
            </button>
          </div>

          <div className="space-y-2">
            {showreelForm.chapters.map((ch, idx) => (
              <div key={idx} className="flex items-center gap-3">
                <input
                  type="text"
                  value={ch.time}
                  onChange={e => handleUpdateChapter(idx, 'time', e.target.value)}
                  className="w-24 bg-[#07090e] border border-white/10 rounded-lg px-3 py-1.5 text-xs text-cyan-300 font-mono"
                  placeholder="00:30"
                />
                <input
                  type="text"
                  value={ch.title}
                  onChange={e => handleUpdateChapter(idx, 'title', e.target.value)}
                  className="flex-1 bg-[#07090e] border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white"
                  placeholder="Chapter Title"
                />
                <button
                  type="button"
                  onClick={() => handleRemoveChapter(idx)}
                  className="p-1.5 text-neutral-500 hover:text-red-400 rounded"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 2. Before / After Color Grading Slider Samples */}
      <div className="p-6 rounded-2xl bg-[#0b0e17] border border-white/5 space-y-5">
        <h3 className="font-display font-bold text-base text-white flex items-center gap-2 border-b border-white/5 pb-3">
          <Sliders className="w-4 h-4 text-cyan-400" />
          <span>Before & After Grading Slider Samples</span>
        </h3>

        <div className="space-y-6">
          {samplesForm.map((sample, sIdx) => (
            <div key={sample.id} className="p-4 rounded-xl bg-[#07090e] border border-white/5 space-y-4">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-cyan-300">
                  Comparison Sample #{sIdx + 1}: {sample.title}
                </span>
                <span className="text-xs font-mono text-neutral-500">
                  {sample.category}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-mono uppercase text-neutral-400 mb-1">
                    Before Image URL (Flat / RAW)
                  </label>
                  <input
                    type="url"
                    value={sample.beforeImage}
                    onChange={e => {
                      const updated = [...samplesForm];
                      updated[sIdx].beforeImage = e.target.value;
                      setSamplesForm(updated);
                    }}
                    className="w-full bg-[#0b0e17] border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-mono uppercase text-neutral-400 mb-1">
                    After Image URL (Color Mastered)
                  </label>
                  <input
                    type="url"
                    value={sample.afterImage}
                    onChange={e => {
                      const updated = [...samplesForm];
                      updated[sIdx].afterImage = e.target.value;
                      setSamplesForm(updated);
                    }}
                    className="w-full bg-[#0b0e17] border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-mono uppercase text-neutral-400 mb-1">
                    Before Label
                  </label>
                  <input
                    type="text"
                    value={sample.beforeLabel}
                    onChange={e => {
                      const updated = [...samplesForm];
                      updated[sIdx].beforeLabel = e.target.value;
                      setSamplesForm(updated);
                    }}
                    className="w-full bg-[#0b0e17] border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-mono uppercase text-neutral-400 mb-1">
                    After Label
                  </label>
                  <input
                    type="text"
                    value={sample.afterLabel}
                    onChange={e => {
                      const updated = [...samplesForm];
                      updated[sIdx].afterLabel = e.target.value;
                      setSamplesForm(updated);
                    }}
                    className="w-full bg-[#0b0e17] border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-mono uppercase text-neutral-400 mb-1">
                    Technical Grading Specs
                  </label>
                  <input
                    type="text"
                    value={sample.specs}
                    onChange={e => {
                      const updated = [...samplesForm];
                      updated[sIdx].specs = e.target.value;
                      setSamplesForm(updated);
                    }}
                    className="w-full bg-[#0b0e17] border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="flex justify-end pt-2">
        <button
          type="submit"
          className="px-8 py-3.5 rounded-xl bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-xl shadow-cyan-500/25 cursor-pointer"
        >
          <Save className="w-4 h-4" />
          <span>Save Showreel & Grading</span>
        </button>
      </div>
    </form>
  );
};
