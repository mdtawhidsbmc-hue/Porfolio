import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Save, Sparkles, Image, Video, Star, Layers, Plus, Trash2 } from 'lucide-react';
import { Project, ProjectCategory } from '../../types/portfolio';

interface AdminProjectModalProps {
  isOpen: boolean;
  project: Project | null;
  onClose: () => void;
  onSave: (project: Project) => void;
}

const categories: ProjectCategory[] = [
  'Video Editing',
  'Graphic Design',
  'Social Media',
  'Branding',
  'Motion Graphics',
  'Thumbnail Design'
];

export const AdminProjectModal: React.FC<AdminProjectModalProps> = ({
  isOpen,
  project,
  onClose,
  onSave
}) => {
  const [formData, setFormData] = useState<Partial<Project>>({
    id: '',
    title: '',
    category: 'Video Editing',
    shortDescription: '',
    thumbnail: '',
    videoUrl: '',
    featured: false,
    aspectRatio: 'video',
    fullDescription: '',
    toolsUsed: ['Premiere Pro', 'After Effects'],
    challenge: '',
    solution: '',
    finalResult: '',
    client: '',
    deliverables: ['Final 4K Master Cut', 'Short-form Social Cuts'],
    stats: [
      { label: 'View Count', value: '1.2M+' },
      { label: 'Retention', value: '68%' }
    ]
  });

  const [toolsInput, setToolsInput] = useState('');
  const [deliverablesInput, setDeliverablesInput] = useState('');

  useEffect(() => {
    if (project) {
      setFormData(project);
      setToolsInput((project.toolsUsed || []).join(', '));
      setDeliverablesInput((project.deliverables || []).join(', '));
    } else {
      setFormData({
        id: `project-${Date.now()}`,
        title: '',
        category: 'Video Editing',
        shortDescription: '',
        thumbnail: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=1200&q=80',
        videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        featured: false,
        aspectRatio: 'video',
        fullDescription: '',
        toolsUsed: ['Premiere Pro', 'DaVinci Resolve'],
        challenge: '',
        solution: '',
        finalResult: '',
        client: '',
        deliverables: ['4K Final Master Cut', 'Color Graded XML'],
        stats: [{ label: 'Retention', value: '72%' }]
      });
      setToolsInput('Premiere Pro, DaVinci Resolve');
      setDeliverablesInput('4K Final Master Cut, Color Graded XML');
    }
  }, [project, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.thumbnail) return;

    const parsedTools = toolsInput
      .split(',')
      .map(t => t.trim())
      .filter(Boolean);

    const parsedDeliverables = deliverablesInput
      .split(',')
      .map(d => d.trim())
      .filter(Boolean);

    const finalizedProject: Project = {
      id: formData.id || `project-${Date.now()}`,
      title: formData.title || 'Untitled Project',
      category: (formData.category as ProjectCategory) || 'Video Editing',
      shortDescription: formData.shortDescription || '',
      thumbnail: formData.thumbnail || '',
      videoUrl: formData.videoUrl || '',
      featured: Boolean(formData.featured),
      aspectRatio: formData.aspectRatio || 'video',
      fullDescription: formData.fullDescription || formData.shortDescription || '',
      toolsUsed: parsedTools.length > 0 ? parsedTools : ['Adobe Creative Cloud'],
      challenge: formData.challenge || '',
      solution: formData.solution || '',
      finalResult: formData.finalResult || '',
      client: formData.client || 'Confidential Client',
      deliverables: parsedDeliverables.length > 0 ? parsedDeliverables : ['Final Master Files'],
      stats: formData.stats || []
    };

    onSave(finalizedProject);
  };

  const addStatRow = () => {
    setFormData(prev => ({
      ...prev,
      stats: [...(prev.stats || []), { label: 'Metric', value: '+100%' }]
    }));
  };

  const removeStatRow = (index: number) => {
    setFormData(prev => ({
      ...prev,
      stats: (prev.stats || []).filter((_, i) => i !== index)
    }));
  };

  const updateStatRow = (index: number, field: 'label' | 'value', val: string) => {
    setFormData(prev => {
      const stats = [...(prev.stats || [])];
      stats[index] = { ...stats[index], [field]: val };
      return { ...prev, stats };
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative w-full max-w-3xl bg-[#0e111a] border border-cyan-500/30 rounded-2xl p-6 sm:p-8 shadow-2xl text-white my-8 max-h-[90vh] overflow-y-auto"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-neutral-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6 pb-4 border-b border-white/5">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-display font-bold text-xl text-white">
              {project ? 'Edit Portfolio Project' : 'Add New Portfolio Project'}
            </h3>
            <p className="text-xs font-mono text-neutral-400">
              Configure thumbnail, case study details, video link, and metrics
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Row 1: Title & Category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                Project Title *
              </label>
              <input
                type="text"
                value={formData.title}
                onChange={e => setFormData({ ...formData, title: e.target.value })}
                className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none"
                placeholder="e.g. Cinematic Tech Product Launch"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                Category
              </label>
              <select
                value={formData.category}
                onChange={e => setFormData({ ...formData, category: e.target.value as ProjectCategory })}
                className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none"
              >
                {categories.map(c => (
                  <option key={c} value={c} className="bg-[#0e111a] text-white">
                    {c}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Row 2: Thumbnail URL & Aspect Ratio */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                Cover Image URL (Direct Link) *
              </label>
              <input
                type="url"
                value={formData.thumbnail}
                onChange={e => setFormData({ ...formData, thumbnail: e.target.value })}
                className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none"
                placeholder="https://images.unsplash.com/..."
                required
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                Aspect Ratio
              </label>
              <select
                value={formData.aspectRatio}
                onChange={e => setFormData({ ...formData, aspectRatio: e.target.value as any })}
                className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none"
              >
                <option value="video" className="bg-[#0e111a]">16:9 Landscape</option>
                <option value="square" className="bg-[#0e111a]">1:1 Square</option>
                <option value="portrait" className="bg-[#0e111a]">9:16 Portrait / Reel</option>
              </select>
            </div>
          </div>

          {/* Thumbnail preview */}
          {formData.thumbnail && (
            <div className="p-3 rounded-xl bg-[#07090e] border border-white/5 flex items-center gap-4">
              <img
                src={formData.thumbnail}
                alt="Preview"
                className="w-24 h-14 object-cover rounded-lg border border-white/10"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              <div className="text-xs font-mono text-neutral-400">
                <span className="text-cyan-400">Image Preview:</span> Make sure this URL loads properly in a browser.
              </div>
            </div>
          )}

          {/* Row 3: Video URL & Client Name */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                Video Preview URL (YouTube / Vimeo / MP4)
              </label>
              <input
                type="text"
                value={formData.videoUrl}
                onChange={e => setFormData({ ...formData, videoUrl: e.target.value })}
                className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none"
                placeholder="https://www.youtube.com/watch?v=..."
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                Client / Channel Name
              </label>
              <input
                type="text"
                value={formData.client}
                onChange={e => setFormData({ ...formData, client: e.target.value })}
                className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none"
                placeholder="e.g. Apex Tech Media"
              />
            </div>
          </div>

          {/* Featured checkbox */}
          <div className="flex items-center gap-3 p-3 rounded-xl bg-[#07090e] border border-white/10">
            <input
              type="checkbox"
              id="featured-checkbox"
              checked={formData.featured}
              onChange={e => setFormData({ ...formData, featured: e.target.checked })}
              className="w-4 h-4 rounded text-cyan-500 focus:ring-cyan-400 accent-cyan-400 cursor-pointer"
            />
            <label htmlFor="featured-checkbox" className="text-xs font-mono text-neutral-300 cursor-pointer flex items-center gap-1.5">
              <Star className="w-3.5 h-3.5 text-amber-400" />
              <span>Mark as Featured Project (Displays featured badge and top placement)</span>
            </label>
          </div>

          {/* Descriptions */}
          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              Short Description (Card summary) *
            </label>
            <textarea
              rows={2}
              value={formData.shortDescription}
              onChange={e => setFormData({ ...formData, shortDescription: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2 text-sm text-white outline-none"
              placeholder="Brief 1-2 sentence description shown in portfolio cards..."
              required
            />
          </div>

          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              Full Case Study Narrative
            </label>
            <textarea
              rows={3}
              value={formData.fullDescription}
              onChange={e => setFormData({ ...formData, fullDescription: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2 text-sm text-white outline-none"
              placeholder="In-depth breakdown displayed when modal is opened..."
            />
          </div>

          {/* Tools & Deliverables */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                Tools Used (comma separated)
              </label>
              <input
                type="text"
                value={toolsInput}
                onChange={e => setToolsInput(e.target.value)}
                className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none"
                placeholder="Premiere Pro, DaVinci Resolve, After Effects"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                Deliverables (comma separated)
              </label>
              <input
                type="text"
                value={deliverablesInput}
                onChange={e => setDeliverablesInput(e.target.value)}
                className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none"
                placeholder="4K Master Cut, Vertical Cutdowns, Thumbnail"
              />
            </div>
          </div>

          {/* Challenge & Solution */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                The Challenge
              </label>
              <textarea
                rows={2}
                value={formData.challenge}
                onChange={e => setFormData({ ...formData, challenge: e.target.value })}
                className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2 text-xs text-white outline-none"
                placeholder="What was the creative problem to solve?"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
                The Solution & Execution
              </label>
              <textarea
                rows={2}
                value={formData.solution}
                onChange={e => setFormData({ ...formData, solution: e.target.value })}
                className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2 text-xs text-white outline-none"
                placeholder="How did you solve it technically and visually?"
              />
            </div>
          </div>

          {/* Final Result */}
          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-neutral-400 mb-2">
              Final Result & Impact
            </label>
            <input
              type="text"
              value={formData.finalResult}
              onChange={e => setFormData({ ...formData, finalResult: e.target.value })}
              className="w-full bg-[#07090e] border border-white/10 focus:border-cyan-400 rounded-xl px-4 py-2.5 text-sm text-white outline-none"
              placeholder="e.g. Achieved 1.4M views and +45% average view duration increase."
            />
          </div>

          {/* Stats Rows */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-mono uppercase tracking-wider text-neutral-400">
                Key Metrics / Stats Badges
              </label>
              <button
                type="button"
                onClick={addStatRow}
                className="text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Metric</span>
              </button>
            </div>

            <div className="space-y-2">
              {(formData.stats || []).map((st, i) => (
                <div key={i} className="flex items-center gap-3">
                  <input
                    type="text"
                    value={st.label}
                    onChange={e => updateStatRow(i, 'label', e.target.value)}
                    className="flex-1 bg-[#07090e] border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white"
                    placeholder="Metric Label (e.g. Retention Rate)"
                  />
                  <input
                    type="text"
                    value={st.value}
                    onChange={e => updateStatRow(i, 'value', e.target.value)}
                    className="w-32 bg-[#07090e] border border-white/10 rounded-lg px-3 py-1.5 text-xs text-cyan-300 font-bold"
                    placeholder="Value (e.g. +78%)"
                  />
                  <button
                    type="button"
                    onClick={() => removeStatRow(i)}
                    className="p-1.5 text-neutral-500 hover:text-red-400 rounded transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Submit buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-300 text-xs font-mono uppercase tracking-wider transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-cyan-500/25 transition-all cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Save Project</span>
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};
