import React from 'react';
import { motion } from 'motion/react';
import { Workflow, CheckCircle, ArrowRight, Sparkles } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

export const Process: React.FC = () => {
  const { data } = usePortfolio();
  const { process } = data;

  return (
    <section id="process" className="relative py-24 lg:py-32 bg-[#07080b] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 sm:mb-20">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-mono uppercase tracking-widest mb-4">
            <Workflow className="w-3.5 h-3.5" />
            <span>HOW WE WORK</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-extrabold text-white tracking-tight mb-4">
            Creative Production Process
          </h2>
          <p className="text-sm sm:text-base text-neutral-300 font-light max-w-xl mx-auto">
            A battle-tested 4-step workflow that ensures seamless collaboration, frame-accurate precision, and on-time project completion.
          </p>
        </div>

        {/* Process Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 relative">
          {process.map((step, idx) => (
            <motion.div
              key={step.step}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className="relative p-6 rounded-2xl bg-[#0e111a] border border-white/10 flex flex-col justify-between hover:border-cyan-500/40 transition-colors group"
            >
              <div>
                {/* Step Header */}
                <div className="flex items-center justify-between mb-6">
                  <div className="w-12 h-12 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center font-mono font-bold text-lg text-cyan-300 group-hover:scale-105 group-hover:bg-cyan-500/20 transition-all">
                    {step.step}
                  </div>
                  <span className="text-[11px] font-mono uppercase tracking-wider text-neutral-400">
                    PHASE 0{idx + 1}
                  </span>
                </div>

                <h3 className="text-xl font-display font-bold text-white mb-3 group-hover:text-cyan-300 transition-colors">
                  {step.title}
                </h3>

                <p className="text-xs sm:text-sm text-neutral-300 font-light leading-relaxed mb-6">
                  {step.description}
                </p>
              </div>

              {/* Deliverables List */}
              <div className="pt-4 border-t border-white/5">
                <p className="text-[10px] font-mono uppercase tracking-wider text-neutral-400 mb-2">
                  Phase Outputs:
                </p>
                <div className="space-y-1.5">
                  {step.deliverables.map((deliv, dIdx) => (
                    <div key={dIdx} className="flex items-center gap-1.5 text-[11px] text-neutral-300">
                      <span className="w-1 h-1 rounded-full bg-cyan-400" />
                      <span>{deliv}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
};
