import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, CheckCircle2, Cpu, Wrench, Flame, Film, Palette, Layers } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

export const Skills: React.FC = () => {
  const { data } = usePortfolio();
  const { skills } = data;

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Video Editing':
        return <Film className="w-5 h-5 text-cyan-400" />;
      case 'Graphic Design':
        return <Palette className="w-5 h-5 text-cyan-400" />;
      default:
        return <Sparkles className="w-5 h-5 text-cyan-400" />;
    }
  };

  return (
    <section id="skills" className="relative py-24 lg:py-32 bg-[#090b10] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 sm:mb-20">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-mono uppercase tracking-widest mb-4">
            <Cpu className="w-3.5 h-3.5" />
            <span>TECHNICAL CAPABILITIES</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-extrabold text-white tracking-tight mb-4">
            Skills & Software
          </h2>
          <p className="text-sm sm:text-base text-neutral-300 font-light max-w-xl mx-auto">
            A comprehensive overview of production software, post-processing pipelines, and creative design tools.
          </p>
        </div>

        {/* Skills Categories Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {skills.map((categoryGroup, idx) => (
            <motion.div
              key={categoryGroup.category}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className="p-7 rounded-2xl bg-[#0e111a] border border-white/10 flex flex-col justify-between hover:border-cyan-500/30 transition-colors"
            >
              <div>
                {/* Category Header */}
                <div className="flex items-center gap-3 pb-4 mb-4 border-b border-white/10">
                  <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center">
                    {getCategoryIcon(categoryGroup.category)}
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-white text-lg">
                      {categoryGroup.category}
                    </h3>
                    <p className="text-xs text-neutral-400 font-light">
                      {categoryGroup.description}
                    </p>
                  </div>
                </div>

                {/* Skills Progress List */}
                <div className="space-y-4">
                  {categoryGroup.skills.map((skill, sIdx) => (
                    <div key={sIdx} className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs font-mono">
                        <span className="text-white font-medium">{skill.name}</span>
                        <span className="text-cyan-400">{skill.level}</span>
                      </div>
                      <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          whileInView={{ width: `${skill.percentage}%` }}
                          viewport={{ once: true }}
                          transition={{ duration: 0.8, delay: 0.2 + sIdx * 0.05 }}
                          className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Bottom Tag */}
              <div className="mt-8 pt-4 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-neutral-400">
                <span>PRODUCTION-READY</span>
                <span className="text-cyan-300">CERTIFIED WORKFLOW</span>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
};
